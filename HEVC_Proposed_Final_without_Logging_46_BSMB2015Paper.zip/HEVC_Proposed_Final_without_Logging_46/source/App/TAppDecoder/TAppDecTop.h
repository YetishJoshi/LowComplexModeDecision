/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2014, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TAppDecTop.h
    \brief    Decoder application class (header)
*/

#ifndef __TAPPDECTOP__
#define __TAPPDECTOP__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TLibVideoIO/TVideoIOYuv.h"
#include "TLibCommon/TComList.h"
#include "TLibCommon/TComPicYuv.h"
#include "TLibDecoder/TDecTop.h"
#include "TAppDecCfg.h"

//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Class definition
// ====================================================================================================================

/// decoder application class
class TAppDecTop : public TAppDecCfg
{
private:
  // class interface
  TDecTop                         m_cTDecTop;                     ///< decoder class
  TVideoIOYuv                     m_cTVideoIOYuvReconFile;        ///< reconstruction YUV class

  TVideoIOYuv                     m_cTVideoIOYuvRefFile;        ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
  
  // for output control
  Int                             m_iPOCLastDisplay;              ///< last POC in display order
  std::ofstream                   m_seiMessageFileStream;         ///< Used for outputing SEI messages.

  TComPicYuv*                     m_pcPicYuvOrg; //YGJ 29th July 2014 -  Input Reference/Original YUV file to compare against

//  TComPicYuv                     m_cPicYuvTrueOrg;  // YGJ 1st Sept 2014 - Req. in HEVC for reading of YUV file
  TComPicYuv                     cPicYuvTrueOrg;  // YGJ 1st Sept 2014 - Req. in HEVC for reading of YUV file

public:
  TAppDecTop();
  virtual ~TAppDecTop() {}

  Void  create            (); ///< create internal members
  Void  destroy           (); ///< destroy internal members
  Void  decode            (); ///< main decoding function

protected:
  Void  xCreateDecLib     (); ///< create internal classes
  Void  xDestroyDecLib    (); ///< destroy internal classes
  Void  xInitDecLib       (); ///< initialize decoder class

  Void  xWriteOutput      ( TComList<TComPic*>* pcListPic , UInt tId); ///< write YUV to file
  Void  xFlushOutput      ( TComList<TComPic*>* pcListPic ); ///< flush all remaining decoded pictures to file
  Bool  isNaluWithinTargetDecLayerIdSet ( InputNALUnit* nalu ); ///< check whether given Nalu is within targetDecLayerIdSet

  //Void  saveFrameAsPNGAPC(TComPic* pcPic); // YGJ 8th September 2014

  Void  saveFrameAsPNGPartition(TComPic* pcPic); //  YGJ 27th July 2014 - Moved from TDecTop.cpp
  Void  saveFrameAsPNGPartwQP(TComPic* pcPic); //  YGJ 5th Oct 2014 Partition with QP Heatmap
  Void  saveFrameAsPNGPartwBitUsage(TComPic* pcPic); //  YGJ 5th Oct 2014 Partition with QP Heatmap

  // Proposed Methods shown as Heatmaps

  // YGJ 22nd Sept 2014 - Different block sizes for SAD
//  Void  saveFrameAsPNG_SAD16_APC(TComPic* pcPic); // YGJ 18th September 2014 - 8x8 Blk of SAD and APC together
  Void  saveFrameAsPNG_SAD4wAPC(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD and APC together
//  Void  saveFrameAsPNG_SADx_PreAssessSAD_APC(TComPic* pcPic); // YGJ 26th November 2014 - 8x8 Blk of SAD Preassess and then APC - to show where triggering occurs
//  Void  saveFrameAsPNG_SADx_PreAssess_APC(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD and APC together
  Void  saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(TComPic* pcPic); // YGJ 4th December 2014 - 8x8 Blk of SAD, Pre Assess with APC and Corner Test together
  Void  saveFrameAsPNG_SADx_PreAssess_Asym_Only(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD and APC together

  // YGJ 23rd Sept 2014 - Non-Square blocks - Does Threshold of 16 still hold true?
//  Void  saveFrameAsPNG_SAD16NonSq_APC(TComPic* pcPic); // YGJ 18th September 2014 - 8x8 Blk of SAD and APC together
//  Void  saveFrameAsPNG_SADx_NonSq_PreAssess_APC(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD and APC together
  Void  saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(TComPic* pcPic);// YGJ 4th December 2014 - 8x8 Blk of SAD, Pre Assess with APC and Corner Test together

  // YGJ 27th Sept 2014 - Forgotten SSE
//  Void  saveFrameAsPNG_SSEwSASD(TComPic* pcPic);
  //Void  saveFrameAsPNG_SSEx_wSASD(TComPic* pcPic); // YGJ 28th Sept 2014 - can the same threshold in 8x8 be used in larger blks (16x16)?
  Void  saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(TComPic* pcPic); // YGJ 28th Sept 2014 - can the same threshold in 8x8 be used in larger blks (16x16)?

//  Void  saveFrameAsPNG_SAD_APC(TComPic* pcPic); // YGJ 18th September 2014 - 8x8 Blk of SAD and APC together
//  Void  saveFrameAsPNG_SAD_PreAssess_APC(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD and APC together
//  Void  saveFrameAsPNG_RCHadw_MS_APC(TComPic* pcPic); // YGJ 17th Sept 2014 - Activity Map using RC Had and Multiscale APC
//  Void  saveFrameAsPNG_Hadw_MS_APC(TComPic* pcPic); // YGJ 17th Sept 2014 - Distoation Assessment Heat Map using Had and Multiscale APC
//  Void  saveFrameAsPNG_Hadw_APC(TComPic* pcPic); // YGJ 18th Sept 2014 - Distoation Assessment Heat Map using Had and APC

  Void  saveFrameAsPNG_HadPreAssess_wCornerTest_APC(TComPic* pcPic); //  YGJ 3rd December 2014 - 8x8 Blk of SAD, Pre Assess with APC and Corner Test together
//  Void  saveFrameAsPNG_HadPreAssess_APC(TComPic* pcPic); // YGJ 18th Sept 2014 - Distoation Assessment Heat Map using Had and Asymmetry Pre-Assessment for APC

//  Void  saveFrameAsPNG_HadPreAssess_APCms(TComPic* pcPic); // YGJ 18th Sept 2014 - Distoation Assessment Heat Map using Had and Asymmetry Pre-Assessment for APC
//  Void  saveFrameAsPNG_Had4x4PreAssess_APC(TComPic* pcPic); // YGJ 18th Sept 2014 - Distoation Assessment Heat Map using Had and Asymmetry Pre-Assessment for APC
  Void  saveFrameAsPNG_Had4x4wAPC(TComPic* pcPic); // YGJ 18th Sept 2014 - Distoation Assessment Heat Map using Had and Asymmetry Pre-Assessment for APC

  //Void  saveFrameAsPNG_RCHadPreAssess_MS_APC(TComPic* pcPic); // YGJ 18th Sept 2014 - Activity Heat Map using Had and Asymmetry Pre-Assessment for MS-APC
  //Void  saveFrameAsPNG_RCHadPreAssess_wCornerTest_MS_APC(TComPic* pcPic);// YGJ 4th December 2014 - 8x8 Blk of SAD, Pre Assess with APC and Corner Test together
  Void saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(TComPic* pcPic); // YGJ 4th Jan 2015 - EdgeScaling of Score

  //=========================================
  //=========================================
  // Existing Methods shown as Heatmaps
  //=========================================
  //=========================================

   // YGJ 22nd Sept 2014 - Different block sizes for SAD
  Void  saveFrameAsPNG_SAD4_Only(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD only
  Void  saveFrameAsPNG_SADx_Only(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD only

  // YGJ 23rd Sept 2014 - Non-Square blocks - Does Threshold of 16 still hold true? (N/A here, but used as reference)
  Void  saveFrameAsPNG_SADx_NonSq_Only(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD only

//  Void  saveFrameAsPNG_SAD_Only(TComPic* pcPic); // YGJ 20th September 2014 - 8x8 Blk of SAD only

  // YGJ 27th Sept 2014 - Forgotten SSE
//  Void  saveFrameAsPNG_SSE_Only(TComPic* pcPic);
  Void  saveFrameAsPNG_SSEx_Only(TComPic* pcPic); //28th Sept 2014

  Void  saveFrameAsSSIMLog(TComPic* pcPic); // YGJ SSIM Log- 2nd Dec 2014
  Void  saveFrameAsPNGSSIM(TComPic* pcPic); // YGJ Diff of Orig and Recon - YGJ 21st July 2014
  Void  saveFrameAsPNG_Hadamard(TComPic* pcPic); // YGJ 17th Sept 2014 - Distoation Assessment Heat Map using Had
  Void  saveFrameAsPNG_Hadamard4x4(TComPic* pcPic); // YGJ 17th Sept 2014 - Distoation Assessment Heat Map using Had
  Void  saveFrameAsPNG_RateControlHad(TComPic* pcPic); // YGJ 17th Sept 2014 - Activity Map using RC Had
  Void  saveFrameAsPNG_RateControlJND(TComPic* pcPic); // YGJ 15th March 2015 - Activity Map using JND

  // YGJ 3rd Oct 2014

  int DistWidthSize(int blkwidth);
  // YGJ 2nd Oct 2014 - Set the distortion Width size from config file
  //const
  //#define width8 8
  //static int m_Lrgblkwidth = (m_distWidthSize == 8? width8 : width8); //DistWidthSize(m_distWidthSize);
  //const static int m_Lrgblkwidth =  (m_distWidthSize == 8? width8 : width8);


};

//! \}

#endif

