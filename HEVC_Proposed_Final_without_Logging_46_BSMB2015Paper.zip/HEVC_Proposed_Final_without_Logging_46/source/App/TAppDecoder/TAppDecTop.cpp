/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2014, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TAppDecTop.cpp
	\brief    Decoder application class
*/

#include <list>
#include <vector>
#include <stdio.h>
#include <fcntl.h>
#include <assert.h>

#include "TAppDecTop.h"
#include "TLibDecoder/AnnexBread.h"
#include "lodepng.h" // Ensure this is added to the project file, else expect linker errors and obj to the make file
#include "TLibDecoder/NALread.h"
#if RExt__DECODER_DEBUG_BIT_STATISTICS
#include "TLibCommon/TComCodingStatistics.h"
#endif

#include <math.h>       /* log */
//#include <cmath.h>       /* log */
//#include <tgmath.h>


// http://stackoverflow.com/questions/5781597/incomplete-type-is-not-allowed
#include <sstream>

// http://www.cplusplus.com/doc/tutorial/files/
// Need to create separate log files
#include <iostream>
#include <fstream>


// No real difference, about the same amount of time. Nevermind. Leave it for now.
const unsigned short LumaSq_LUT[256] =
	{0,1,4,9,16,25,36,49,64,81,100,121,144,169,196,225,
	256,289,324,361,400,441,484,529,576,625,676,729,784,841,900,961,
	1024,1089,1156,1225,1296,1369,1444,1521,1600,1681,1764,1849,1936,2025,2116,2209,
	2304,2401,2500,2601,2704,2809,2916,3025,3136,3249,3364,3481,3600,3721,3844,3969,
	4096,4225,4356,4489,4624,4761,4900,5041,5184,5329,5476,5625,5776,5929,6084,6241,
	6400,6561,6724,6889,7056,7225,7396,7569,7744,7921,8100,8281,8464,8649,8836,9025,
	9216,9409,9604,9801,10000,10201,10404,10609,10816,11025,11236,11449,11664,11881,12100,12321,
	12544,12769,12996,13225,13456,13689,13924,14161,14400,14641,14884,15129,15376,15625,15876,16129,
	16384,16641,16900,17161,17424,17689,17956,18225,18496,18769,19044,19321,19600,19881,20164,20449,
	20736,21025,21316,21609,21904,22201,22500,22801,23104,23409,23716,24025,24336,24649,24964,25281,
	25600,25921,26244,26569,26896,27225,27556,27889,28224,28561,28900,29241,29584,29929,30276,30625,
	30976,31329,31684,32041,32400,32761,33124,33489,33856,34225,34596,34969,35344,35721,36100,36481,
	36864,37249,37636,38025,38416,38809,39204,39601,40000,40401,40804,41209,41616,42025,42436,42849,
	43264,43681,44100,44521,44944,45369,45796,46225,46656,47089,47524,47961,48400,48841,49284,49729,
	50176,50625,51076,51529,51984,52441,52900,53361,53824,54289,54756,55225,55696,56169,56644,57121,
	57600,58081,58564,59049,59536,60025,60516,61009,61504,62001,62500,63001,63504,64009,64516,65025
};

//const static int m_Lrgblkwidth = DistWidthSize(m_distWidthSize);

// quartMaxLimit = 2^x + 2^(x-1)
// For x from 12 to 18
// Starting from 2^12 + 2^11 = 6144
// Adds headroom to cover range of scores for SAD/Had with and without APC
// However, the values calculated are too high for 64x64 and 64x32 (and 64x32), so they must be lowered
//
////        8   16  32  64
////     + ----------------
////  8  |  3    6   0   0
////  16 |  6   12  12   0
////  32 |  0   12  24  49
////  64 |  0    0  49  98
////
//long quartMaxLimit[4][4] = {
//    {3072, 6144,0, 0}, // {6144, 6144,0, 0},
//    {6144, 12288, 12288, 0}, // {12288, 24576, 49152, 0},
//    {0, 12288, 24576, 49152}, //    {0, 49152, 98304, 196608},
//    {0,0, 49152, 98304},   // {0,0, 196608, 393216},
//};

// As SSE is always sq, it will be 1D array
// 8x8, 16x16, 32x32, 64x64
//long quartMaxLimitSAD[4] = {3072, 12288, 49152, 98304};
//int  maxLimitSAD_k[4] = {3, 12, 24, 98};
int  maxLimitSAD_k[4] = {16, 64, 256, 1024};


// Now for SSE
// As SSE is always sq, it will be 1D array
// 8x8, 16x16, 32x32, 64x64
//long quartMaxLimitSSE[4] = {16384, 65536, 262144, 1048576};
//int maxLimitSSE_k[4] = {16, 64, 256, 1024};
int maxLimitSSE_k[4] = {64, 256, 1024, 4096};

// Using NormDistribution (1 minus [0.0 to 2.0].
//  This means that the range of max score is less as element in array increases
// e.g. while last element would be 1 - 97% , in order to save memory the values have been scaled up by 10,000 to get 228.
int NormDist_OneMin10k [21] = {5000,4602,4207,3821,3446,3085,2743,2420,2119,1841,1587,1357,1151,968,808,668,548,446,359,287,228};

// threshold max  = (a x b) x (a_scale x b_scale x c_scale) 
// where a = maxLimitSAD_k, or SSE version  and a_scale is times 1,024
// a is user defined by block size
// b is NormDist_OneMin10k and b_scale is divide by 10,000, (1/10000)
// b is selected  to represented the range of max via a setting of 0 to 20. (non-linear)
// Note a_scale * b_scale is fixed at 0.1024
// c_scale is linear scaling of 1/(2^n), where n is setting by the user ranging from 0 to 16.

// For rate-control, activity maps the max is different, since the differences of pixel intensities are used not the differences vs the original.
// This means scores are particularly high.
// For that the activity must be scaled to show greater contrast




// Applicable to MSVC (Microsoft Visual C++ compiler)
// http://stackoverflow.com/questions/70013/how-to-detect-if-im-compiling-code-with-visual-studio-2008
// and elsewhere in this codebase
#if _MSC_VER //> 1000
#pragma once


// Calculates log2 of number.  
// http://stackoverflow.com/questions/994593/how-to-do-an-integer-log2-in-c
//static unsigned int log2 (unsigned int val) {
static double log2 (double n) {

	// log(n)/log(2) is log2.  
	return log( n ) / log( 2.0 );

	//unsigned int ret = -1;
	//while (val != 0) {
	//    val >>= 1;
	//    ret++;
	//}
	//return ret;
}
#endif // _MSC_VER > 1000

// YGJ 2nd Oct 2014 - Set the distortion Width size from config file
//const int m_Lrgblkwidth = DistWidthSize(m_distWidthSize);


//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Constructor / destructor / initialization / destroy
// ====================================================================================================================

TAppDecTop::TAppDecTop()
: m_iPOCLastDisplay(-MAX_INT)
{
}

Void TAppDecTop::create()
{
	m_pcPicYuvOrg = new TComPicYuv;
//    cPicYuvTrueOrg = new TComPicYuv;
//    m_cPicYuvTrueOrg.create(m_iSourceWidth, m_iSourceHeight, m_inputChromaFormat, 64, 64, 4);
//    m_cPicYuvTrueOrg->create(m_iSourceWidth, m_iSourceHeight, m_inputChromaFormat, 64, 64, 4);

}

Void TAppDecTop::destroy()
{
  if (m_pchBitstreamFile)
  {
	free (m_pchBitstreamFile);
	m_pchBitstreamFile = NULL;
  }
  if (m_pchReconFile)
  {
	free (m_pchReconFile);
	m_pchReconFile = NULL;
  }
  if (m_pchRefFile) ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
  {
	free (m_pchRefFile);
	m_pchRefFile = NULL;
  }

  delete m_pcPicYuvOrg;
}

// ====================================================================================================================
// Public member functions
// ====================================================================================================================

/**
 - create internal class
 - initialize internal class
 - until the end of the bitstream, call decoding function in TDecTop class
 - delete allocated buffers
 - destroy internal class
 .
 */
Void TAppDecTop::decode()
{
  Int                 poc;
  TComList<TComPic*>* pcListPic = NULL;

  ifstream bitstreamFile(m_pchBitstreamFile, ifstream::in | ifstream::binary);
  if (!bitstreamFile)
  {
	fprintf(stderr, "\nfailed to open bitstream file `%s' for reading\n", m_pchBitstreamFile);
	exit(EXIT_FAILURE);
  }

  InputByteStream bytestream(bitstreamFile);

  if (!m_outputDecodedSEIMessagesFilename.empty() && m_outputDecodedSEIMessagesFilename!="-")
  {
	m_seiMessageFileStream.open(m_outputDecodedSEIMessagesFilename.c_str(), std::ios::out);
	if (!m_seiMessageFileStream.is_open() || !m_seiMessageFileStream.good())
	{
	  fprintf(stderr, "\nUnable to open file `%s' for writing decoded SEI messages\n", m_outputDecodedSEIMessagesFilename.c_str());
	  exit(EXIT_FAILURE);
	}
  }

  // create & initialize internal classes
  xCreateDecLib();
  xInitDecLib  ();
  m_iPOCLastDisplay += m_iSkipFrame;      // set the last displayed POC correctly for skip forward.

  // main decoder loop
  Bool openedReconFile = false; // reconstruction file not yet opened. (must be performed after SPS is seen)
  Bool loopFiltered = false;

  
		
  ChromaFormat chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
					   m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

  printf("m_iSourceWidth, %d, m_iSourceHeight, %d, m_inputChromaFormat, %d, chrfmt, %d \n", m_iSourceWidth, m_iSourceHeight, m_inputChromaFormat, chrfmt);

  cPicYuvTrueOrg.create(m_iSourceWidth, m_iSourceHeight, chrfmt, 64, 64, 4);

  m_pcPicYuvOrg->create(m_iSourceWidth, m_iSourceHeight, chrfmt, 64, 64, 4);

  if (m_pchRefFile != NULL)
  {
      printf("About to open YUV Ref File, m_outputBitDepth %d \n", m_outputBitDepth[0]);

      m_cTVideoIOYuvRefFile.open(m_pchRefFile, false, m_outputBitDepth, m_outputBitDepth, m_internalBitDepth);  // read mode
      //  m_cTVideoIOYuvReconFile.open(m_pchReconFile, true, m_outputBitDepth, m_outputBitDepth, m_internalBitDepth);  // write mode

      printf("Opened YUV Ref File \n");
  }

  while (!!bitstreamFile)
  {
	/* location serves to work around a design fault in the decoder, whereby
	 * the process of reading a new slice that is the first slice of a new frame
	 * requires the TDecTop::decode() method to be called again with the same
	 * nal unit. */
#if RExt__DECODER_DEBUG_BIT_STATISTICS
	TComCodingStatistics::TComCodingStatisticsData backupStats(TComCodingStatistics::GetStatistics());
	streampos location = bitstreamFile.tellg() - streampos(bytestream.GetNumBufferedBytes());
#else
	streampos location = bitstreamFile.tellg();
#endif
	AnnexBStats stats = AnnexBStats();

	vector<uint8_t> nalUnit;
	InputNALUnit nalu;
	byteStreamNALUnit(bytestream, nalUnit, stats);

	// call actual decoding function
	Bool bNewPicture = false;
	if (nalUnit.empty())
	{
	  /* this can happen if the following occur:
	   *  - empty input file
	   *  - two back-to-back start_code_prefixes
	   *  - start_code_prefix immediately followed by EOF
	   */
	  fprintf(stderr, "Warning: Attempt to decode an empty NAL unit\n");
	}
	else
	{
	  read(nalu, nalUnit);
	  if( (m_iMaxTemporalLayer >= 0 && nalu.m_temporalId > m_iMaxTemporalLayer) || !isNaluWithinTargetDecLayerIdSet(&nalu)  )
	  {
		bNewPicture = false;
	  }
	  else
	  {
		bNewPicture = m_cTDecTop.decode(nalu, m_iSkipFrame, m_iPOCLastDisplay);
		if (bNewPicture)
		{
		  bitstreamFile.clear();
		  /* location points to the current nalunit payload[1] due to the
		   * need for the annexB parser to read three extra bytes.
		   * [1] except for the first NAL unit in the file
		   *     (but bNewPicture doesn't happen then) */
#if RExt__DECODER_DEBUG_BIT_STATISTICS
		  bitstreamFile.seekg(location);
		  bytestream.reset();
		  TComCodingStatistics::SetStatistics(backupStats);
#else
		  bitstreamFile.seekg(location-streamoff(3));
		  bytestream.reset();
#endif
		}
	  }
	}

#if FIX_OUTPUT_ORDER_BEHAVIOR
	if ( (bNewPicture || !bitstreamFile || nalu.m_nalUnitType == NAL_UNIT_EOS) &&
		!m_cTDecTop.getFirstSliceInSequence () )
#else
	if (bNewPicture || !bitstreamFile || nalu.m_nalUnitType == NAL_UNIT_EOS)
#endif
	{
	  if (!loopFiltered || bitstreamFile)
	  {
		m_cTDecTop.executeLoopFilters(poc, pcListPic);
	  }
	  loopFiltered = (nalu.m_nalUnitType == NAL_UNIT_EOS);
#if FIX_OUTPUT_ORDER_BEHAVIOR
	  if (nalu.m_nalUnitType == NAL_UNIT_EOS)
	  {
		m_cTDecTop.setFirstSliceInSequence(true);
	  }
#endif
	}
#if FIX_OUTPUT_ORDER_BEHAVIOR
	else if ( (bNewPicture || !bitstreamFile || nalu.m_nalUnitType == NAL_UNIT_EOS ) &&
			  m_cTDecTop.getFirstSliceInSequence () ) 
	{
	  m_cTDecTop.setFirstSliceInPicture (true);
	}
#endif
#if !FIX_WRITING_OUTPUT
#if SETTING_NO_OUT_PIC_PRIOR
	if (bNewPicture && m_cTDecTop.getIsNoOutputPriorPics())
	{
	  m_cTDecTop.checkNoOutputPriorPics( pcListPic );
	}
#endif
#endif

	if( pcListPic )
	{
	  if ( m_pchReconFile && !openedReconFile )
	  {
		for (UInt channelType = 0; channelType < MAX_NUM_CHANNEL_TYPE; channelType++)
		{
		  if (m_outputBitDepth[channelType] == 0) m_outputBitDepth[channelType] = g_bitDepth[channelType];
		}

		m_cTVideoIOYuvReconFile.open( m_pchReconFile, true, m_outputBitDepth, m_outputBitDepth, g_bitDepth ); // write mode
		openedReconFile = true;
	  }
#if FIX_WRITING_OUTPUT
	  // write reconstruction to file
	  if( bNewPicture )
	  {
		xWriteOutput( pcListPic, nalu.m_temporalId );
	  }
#if SETTING_NO_OUT_PIC_PRIOR
	  if ( (bNewPicture || nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_CRA) && m_cTDecTop.getNoOutputPriorPicsFlag() )
	  {
		m_cTDecTop.checkNoOutputPriorPics( pcListPic );
		m_cTDecTop.setNoOutputPriorPicsFlag (false);
	  }
#endif
#endif
	  if ( bNewPicture &&
		   (   nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_IDR_W_RADL
			|| nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_IDR_N_LP
			|| nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_BLA_N_LP
			|| nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_BLA_W_RADL
			|| nalu.m_nalUnitType == NAL_UNIT_CODED_SLICE_BLA_W_LP ) )
	  {
		xFlushOutput( pcListPic );
	  }
	  if (nalu.m_nalUnitType == NAL_UNIT_EOS)
	  {
#if FIX_OUTPUT_EOS
		xWriteOutput( pcListPic, nalu.m_temporalId );
#if FIX_OUTPUT_ORDER_BEHAVIOR
		m_cTDecTop.setFirstSliceInPicture (false);
#endif
#else
		xFlushOutput( pcListPic );
#endif
	  }
	  // write reconstruction to file -- for additional bumping as defined in C.5.2.3
#if FIX_WRITING_OUTPUT
	  if(!bNewPicture && nalu.m_nalUnitType >= NAL_UNIT_CODED_SLICE_TRAIL_N && nalu.m_nalUnitType <= NAL_UNIT_RESERVED_VCL31)
#else
	  if(bNewPicture)
#endif
	  {
		xWriteOutput( pcListPic, nalu.m_temporalId );
	  }
	}
  }

  xFlushOutput( pcListPic );
  // delete buffers
  m_cTDecTop.deletePicBuffer();

  // destroy internal classes
  xDestroyDecLib();
}

// ====================================================================================================================
// Protected member functions
// ====================================================================================================================

Void TAppDecTop::xCreateDecLib()
{
  // Video I/O
  //m_cTVideoIOYuvInputFile.open( m_pchInputFile,     false, m_inputBitDepth, m_MSBExtendedBitDepth, m_internalBitDepth );  // read  mode
  //m_cTVideoIOYuvInputFile.skipFrames(m_FrameSkip, m_iSourceWidth - m_aiPad[0], m_iSourceHeight - m_aiPad[1], m_InputChromaFormatIDC);

  //if (m_pchReconFile)
  //{
  //  m_cTVideoIOYuvReconFile.open(m_pchReconFile, true, m_outputBitDepth, m_outputBitDepth, m_internalBitDepth);  // write mode
  //  //m_cTVideoIOYuvRefFile.open(m_pchRefFile, false, m_outputBitDepth, m_outputBitDepth, m_internalBitDepth);  // read mode
  //}
 
  // create decoder class
  m_cTDecTop.create();
}

Void TAppDecTop::xDestroyDecLib()
{
	  // Video I/O
  //m_cTVideoIOYuvInputFile.close();
  //m_cTVideoIOYuvReconFile.close();

  if ( m_pchReconFile )
  {
	m_cTVideoIOYuvReconFile.close();
  }
  if ( m_pchRefFile )
  {
	m_cTVideoIOYuvRefFile.close();  ///< Reference  file to compare Difference and SSIM Heat-maps from -  YGJ 17th July 2013
  }
  
  // destroy decoder class
  m_cTDecTop.destroy();
}

Void TAppDecTop::xInitDecLib()
{
  // initialize decoder class
  m_cTDecTop.init();
  m_cTDecTop.setDecodedPictureHashSEIEnabled(m_decodedPictureHashSEIEnabled);
#if RExt__O0043_BEST_EFFORT_DECODING
  m_cTDecTop.setForceDecodeBitDepth(m_forceDecodeBitDepth);
#endif
  if (!m_outputDecodedSEIMessagesFilename.empty())
  {
	std::ostream &os=m_seiMessageFileStream.is_open() ? m_seiMessageFileStream : std::cout;
	m_cTDecTop.setDecodedSEIMessageOutputStream(&os);
  }
}

/** \param pcListPic list of pictures to be written to file
	\todo            DYN_REF_FREE should be revised
 */
Void TAppDecTop::xWriteOutput( TComList<TComPic*>* pcListPic, UInt tId )
{
  if (pcListPic->empty())
  {
	return;
  }

  // YGJ 29th July 2014 - Used to read YUV file
  int m_aiPad[2];
  m_aiPad[1] = m_aiPad[0] = 0;
  ChromaFormat                   chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
										  m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;



  TComList<TComPic*>::iterator iterPic   = pcListPic->begin();
  Int numPicsNotYetDisplayed = 0;
  Int dpbFullness = 0;
  TComSPS* activeSPS = m_cTDecTop.getActiveSPS();
  UInt numReorderPicsHighestTid;
  UInt maxDecPicBufferingHighestTid;
  UInt maxNrSublayers = activeSPS->getMaxTLayers();

  if(m_iMaxTemporalLayer == -1 || m_iMaxTemporalLayer >= maxNrSublayers)
  {
	numReorderPicsHighestTid = activeSPS->getNumReorderPics(maxNrSublayers-1);
	maxDecPicBufferingHighestTid =  activeSPS->getMaxDecPicBuffering(maxNrSublayers-1); 
  }
  else
  {
	numReorderPicsHighestTid = activeSPS->getNumReorderPics(m_iMaxTemporalLayer);
	maxDecPicBufferingHighestTid = activeSPS->getMaxDecPicBuffering(m_iMaxTemporalLayer); 
  }

  while (iterPic != pcListPic->end())
  {
	TComPic* pcPic = *(iterPic);
	if(pcPic->getOutputMark() && pcPic->getPOC() > m_iPOCLastDisplay)
	{
	   numPicsNotYetDisplayed++;
	  dpbFullness++;
	}
	else if(pcPic->getSlice( 0 )->isReferenced())
	{
	  dpbFullness++;
	}
	iterPic++;
  }

  iterPic = pcListPic->begin();

  if (numPicsNotYetDisplayed>2)
  {
	iterPic++;
  }

  TComPic* pcPic = *(iterPic);
  if (numPicsNotYetDisplayed>2 && pcPic->isField()) //Field Decoding
  {
	TComList<TComPic*>::iterator endPic   = pcListPic->end();
	endPic--;
	iterPic   = pcListPic->begin();
	while (iterPic != endPic)
	{
	  TComPic* pcPicTop = *(iterPic);
	  iterPic++;
	  TComPic* pcPicBottom = *(iterPic);

	  if ( pcPicTop->getOutputMark() && pcPicBottom->getOutputMark() &&
		  (numPicsNotYetDisplayed >  numReorderPicsHighestTid || dpbFullness > maxDecPicBufferingHighestTid) &&
		  (!(pcPicTop->getPOC()%2) && pcPicBottom->getPOC() == pcPicTop->getPOC()+1) &&
		  (pcPicTop->getPOC() == m_iPOCLastDisplay+1 || m_iPOCLastDisplay < 0))
	  {
		// write to file
		numPicsNotYetDisplayed = numPicsNotYetDisplayed-2;
		if ( m_pchReconFile )
		{
		  const Window &conf = pcPicTop->getConformanceWindow();
		  const Window &defDisp = m_respectDefDispWindow ? pcPicTop->getDefDisplayWindow() : Window();
		  const Bool isTff = pcPicTop->isTopField();

		  Bool display = true;
		  if( m_decodedNoDisplaySEIEnabled )
		  {
			SEIMessages noDisplay = getSeisByType(pcPic->getSEIs(), SEI::NO_DISPLAY );
			const SEINoDisplay *nd = ( noDisplay.size() > 0 ) ? (SEINoDisplay*) *(noDisplay.begin()) : NULL;
			if( (nd != NULL) && nd->m_noDisplay )
			{
			  display = false;
			}
		  }

		  if (display)
		  {
			m_cTVideoIOYuvReconFile.write( pcPicTop->getPicYuvRec(), pcPicBottom->getPicYuvRec(),
										   m_outputColourSpaceConvert,
										   conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
										   conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
										   conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
										   conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset(), NUM_CHROMA_FORMAT, isTff );
		  }
		}

		//m_cTVideoIOYuvRefFile.read(m_pcPicYuvOrg,m_aiPad); // YGJ 29th July 2014 - Read YUV file -- Working here
		// From TAppEncTop
		// read input YUV file
		//m_cTVideoIOYuvInputFile.read( pcPicYuvOrg, &cPicYuvTrueOrg, ipCSC, m_aiPad, m_InputChromaFormatIDC );

//       From TypeDef.h
//        enum InputColourSpaceConversion // defined in terms of conversion prior to input of encoder.
//        {
//          IPCOLOURSPACE_UNCHANGED               = 0,

//        /// chroma formats (according to semantics of chroma_format_idc)
//        enum ChromaFormat
//        {
//          CHROMA_400        = 0,
//          CHROMA_420        = 1,
//          CHROMA_422        = 2,
//          CHROMA_444        = 3,

          
        if (m_pchRefFile != NULL)
        {
		    // read input YUV file
		    m_cTVideoIOYuvRefFile.read( m_pcPicYuvOrg, &cPicYuvTrueOrg, m_outputColourSpaceConvert, m_aiPad, chrfmt );
        }
		
		// update POC of display order
		m_iPOCLastDisplay = pcPicBottom->getPOC();

		// erase non-referenced picture in the reference picture list after display
		if ( !pcPicTop->getSlice(0)->isReferenced() && pcPicTop->getReconMark() == true )
		{
#if !DYN_REF_FREE
		  pcPicTop->setReconMark(false);

		  // mark it should be extended later
		  pcPicTop->getPicYuvRec()->setBorderExtension( false );

#else
		  pcPicTop->destroy();
		  pcListPic->erase( iterPic );
		  iterPic = pcListPic->begin(); // to the beginning, non-efficient way, have to be revised!
		  continue;
#endif
		}
		if ( !pcPicBottom->getSlice(0)->isReferenced() && pcPicBottom->getReconMark() == true )
		{
#if !DYN_REF_FREE
		  pcPicBottom->setReconMark(false);

		  // mark it should be extended later
		  pcPicBottom->getPicYuvRec()->setBorderExtension( false );

#else
		  pcPicBottom->destroy();
		  pcListPic->erase( iterPic );
		  iterPic = pcListPic->begin(); // to the beginning, non-efficient way, have to be revised!
		  continue;
#endif
		}
		pcPicTop->setOutputMark(false);
		pcPicBottom->setOutputMark(false);
	  }
	}
  }
  else if (!pcPic->isField()) //Frame Decoding
  {
	iterPic = pcListPic->begin();

	while (iterPic != pcListPic->end())
	{
	  pcPic = *(iterPic);

	  if(pcPic->getOutputMark() && pcPic->getPOC() > m_iPOCLastDisplay &&
		(numPicsNotYetDisplayed >  numReorderPicsHighestTid || dpbFullness > maxDecPicBufferingHighestTid))
	  {
		// write to file
		 numPicsNotYetDisplayed--;
		if(pcPic->getSlice(0)->isReferenced() == false)
		{
		  dpbFullness--;
		}

		if ( m_pchReconFile )
		{
		  const Window &conf    = pcPic->getConformanceWindow();
		  const Window &defDisp = m_respectDefDispWindow ? pcPic->getDefDisplayWindow() : Window();

		  m_cTVideoIOYuvReconFile.write( pcPic->getPicYuvRec(),
										 m_outputColourSpaceConvert,
										 conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
										 conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
										 conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
										 conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset() );
		}

		//m_cTVideoIOYuvRefFile.read(m_pcPicYuvOrg,m_aiPad); // YGJ 29th July 2014 - Read YUV file -- Working here

  
        if (m_pchRefFile != NULL)
        {
		    // read input YUV file
		    m_cTVideoIOYuvRefFile.read( m_pcPicYuvOrg, &cPicYuvTrueOrg, m_outputColourSpaceConvert, m_aiPad, chrfmt );
        }

		#if RExt__DECODER_DEBUG_BIT_STATISTICS

		  TComCodingStatistics::CurrentBitUsage();

		#endif

  
        if (m_pchRefFile != NULL)  
        {

		    // Save Output as PNGs
		    if (m_outputFrmPartition && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
			    saveFrameAsPNGPartition(pcPic);
			    saveFrameAsPNGPartwQP(pcPic);
			    saveFrameAsPNGPartwBitUsage(pcPic);
		    }

			if (m_outputSSIMAndSSELog) saveFrameAsSSIMLog(pcPic);
		
		    if (m_outputSSIMHeatmaps && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
			    saveFrameAsPNGSSIM(pcPic);
//			    saveFrameAsPNG_HadPreAssess_APC(pcPic);
                saveFrameAsPNG_HadPreAssess_wCornerTest_APC(pcPic);
                //saveFrameAsPNG_HadPreAssess_APCms(pcPic);
//			    saveFrameAsPNG_Had4x4PreAssess_APC(pcPic);
//			    saveFrameAsPNG_Had4x4wAPC(pcPic);
                //saveFrameAsPNG_RCHadPreAssess_MS_APC(pcPic);
                //saveFrameAsPNG_RCHadPreAssess_wCornerTest_MS_APC(pcPic);
                saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(pcPic);
//                saveFrameAsPNG_SAD4wAPC(pcPic);
//                saveFrameAsPNG_SADx_PreAssessSAD_APC(pcPic);
//                saveFrameAsPNG_SADx_PreAssess_APC(pcPic);
                saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(pcPic);
//                saveFrameAsPNG_SADx_PreAssess_Asym_Only(pcPic);
//			    saveFrameAsPNG_SADx_NonSq_PreAssess_APC(pcPic);
                saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(pcPic);
                //saveFrameAsPNG_SSEx_wSASD(pcPic);
				saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(pcPic);
			    // Existing
			    saveFrameAsPNG_Hadamard(pcPic);
//                saveFrameAsPNG_Hadamard4x4(pcPic);
                saveFrameAsPNG_RateControlHad(pcPic);
                saveFrameAsPNG_RateControlJND(pcPic);
			    saveFrameAsPNG_SSEx_Only(pcPic);
//			    saveFrameAsPNG_SAD4_Only(pcPic);
			    saveFrameAsPNG_SADx_Only(pcPic);
			    saveFrameAsPNG_SADx_NonSq_Only(pcPic);
		    }
		
        }

		// update POC of display order
		m_iPOCLastDisplay = pcPic->getPOC();

		// erase non-referenced picture in the reference picture list after display
		if ( !pcPic->getSlice(0)->isReferenced() && pcPic->getReconMark() == true )
		{
#if !DYN_REF_FREE
		  pcPic->setReconMark(false);

		  // mark it should be extended later
		  pcPic->getPicYuvRec()->setBorderExtension( false );

#else
		  pcPic->destroy();
		  pcListPic->erase( iterPic );
		  iterPic = pcListPic->begin(); // to the beginning, non-efficient way, have to be revised!
		  continue;
#endif
		}
		pcPic->setOutputMark(false);
	  }

	  iterPic++;
	}
  }
}

/** \param pcListPic list of pictures to be written to file
	\todo            DYN_REF_FREE should be revised
 */
Void TAppDecTop::xFlushOutput( TComList<TComPic*>* pcListPic )
{
  if(!pcListPic || pcListPic->empty())
  {
	return;
  }

  // YGJ 29th July 2014 - Used to read YUV file
  int m_aiPad[2];
  m_aiPad[1] = m_aiPad[0] = 0;
  ChromaFormat                   chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
										  m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;


  TComList<TComPic*>::iterator iterPic   = pcListPic->begin();

  iterPic   = pcListPic->begin();
  TComPic* pcPic = *(iterPic);

  if (pcPic->isField()) //Field Decoding
  {
	TComList<TComPic*>::iterator endPic   = pcListPic->end();
	endPic--;
	TComPic *pcPicTop, *pcPicBottom = NULL;
	while (iterPic != endPic)
	{
	  pcPicTop = *(iterPic);
	  iterPic++;
	  pcPicBottom = *(iterPic);

	  if ( pcPicTop->getOutputMark() && pcPicBottom->getOutputMark() && !(pcPicTop->getPOC()%2) && (pcPicBottom->getPOC() == pcPicTop->getPOC()+1) )
	  {
		// write to file
		if ( m_pchReconFile )
		{
		  const Window &conf = pcPicTop->getConformanceWindow();
		  const Window &defDisp = m_respectDefDispWindow ? pcPicTop->getDefDisplayWindow() : Window();
		  const Bool isTff = pcPicTop->isTopField();
		  m_cTVideoIOYuvReconFile.write( pcPicTop->getPicYuvRec(), pcPicBottom->getPicYuvRec(),
										 m_outputColourSpaceConvert,
										 conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
										 conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
										 conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
										 conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset(), NUM_CHROMA_FORMAT, isTff );
		}
		
   
        if (m_pchRefFile != NULL)
        {
		    //m_cTVideoIOYuvRefFile.read(m_pcPicYuvOrg,m_aiPad); // YGJ 29th July 2014 - Read YUV file -- Working here

		    // read input YUV file
		    m_cTVideoIOYuvRefFile.read( m_pcPicYuvOrg, &cPicYuvTrueOrg, m_outputColourSpaceConvert, m_aiPad, chrfmt );
        }


		// update POC of display order
		m_iPOCLastDisplay = pcPicBottom->getPOC();

		// erase non-referenced picture in the reference picture list after display
		if ( !pcPicTop->getSlice(0)->isReferenced() && pcPicTop->getReconMark() == true )
		{
#if !DYN_REF_FREE
		  pcPicTop->setReconMark(false);

		  // mark it should be extended later
		  pcPicTop->getPicYuvRec()->setBorderExtension( false );

#else
		  pcPicTop->destroy();
		  pcListPic->erase( iterPic );
		  iterPic = pcListPic->begin(); // to the beginning, non-efficient way, have to be revised!
		  continue;
#endif
		}
		if ( !pcPicBottom->getSlice(0)->isReferenced() && pcPicBottom->getReconMark() == true )
		{
#if !DYN_REF_FREE
		  pcPicBottom->setReconMark(false);

		  // mark it should be extended later
		  pcPicBottom->getPicYuvRec()->setBorderExtension( false );

#else
		  pcPicBottom->destroy();
		  pcListPic->erase( iterPic );
		  iterPic = pcListPic->begin(); // to the beginning, non-efficient way, have to be revised!
		  continue;
#endif
		}
		pcPicTop->setOutputMark(false);
		pcPicBottom->setOutputMark(false);

#if !DYN_REF_FREE
		if(pcPicTop)
		{
		  pcPicTop->destroy();
		  delete pcPicTop;
		  pcPicTop = NULL;
		}
#endif
	  }
	}
	if(pcPicBottom)
	{
	  pcPicBottom->destroy();
	  delete pcPicBottom;
	  pcPicBottom = NULL;
	}
  }
  else //Frame decoding
  {
	while (iterPic != pcListPic->end())
	{
	  pcPic = *(iterPic);

	  if ( pcPic->getOutputMark() )
	  {
		// write to file
		if ( m_pchReconFile )
		{
		  const Window &conf    = pcPic->getConformanceWindow();
		  const Window &defDisp = m_respectDefDispWindow ? pcPic->getDefDisplayWindow() : Window();

		  m_cTVideoIOYuvReconFile.write( pcPic->getPicYuvRec(),
										 m_outputColourSpaceConvert,
										 conf.getWindowLeftOffset() + defDisp.getWindowLeftOffset(),
										 conf.getWindowRightOffset() + defDisp.getWindowRightOffset(),
										 conf.getWindowTopOffset() + defDisp.getWindowTopOffset(),
										 conf.getWindowBottomOffset() + defDisp.getWindowBottomOffset() );
		}

        if (m_pchRefFile != NULL)
        {
		    //m_cTVideoIOYuvRefFile.read(m_pcPicYuvOrg,m_aiPad); // YGJ 29th July 2014 - Read YUV file -- Working here
				
		    // read input YUV file
		    m_cTVideoIOYuvRefFile.read( m_pcPicYuvOrg, &cPicYuvTrueOrg, m_outputColourSpaceConvert, m_aiPad, chrfmt );
        }

		// update POC of display order
		m_iPOCLastDisplay = pcPic->getPOC();

		#if RExt__DECODER_DEBUG_BIT_STATISTICS

		TComCodingStatistics::CurrentBitUsage();

		#endif

        if (m_pchRefFile != NULL)
        {

		    //saveFrameAsPNG
		    // Save Output as PNGs
		    if (m_outputFrmPartition && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
			    saveFrameAsPNGPartition(pcPic);
			    saveFrameAsPNGPartwQP(pcPic);
			    saveFrameAsPNGPartwBitUsage(pcPic);
		    }

			if (m_outputSSIMAndSSELog) saveFrameAsSSIMLog(pcPic);
				  
		    if (m_outputSSIMHeatmaps && (m_frameoutput == pcPic->getPOC() || m_frameoutput == 0))
		    {
			    saveFrameAsPNGSSIM(pcPic);
//			    saveFrameAsPNG_HadPreAssess_APC(pcPic);
                saveFrameAsPNG_HadPreAssess_wCornerTest_APC(pcPic);
                //saveFrameAsPNG_HadPreAssess_APCms(pcPic);
                //saveFrameAsPNG_Had4x4PreAssess_APC(pcPic);
                //saveFrameAsPNG_Had4x4wAPC(pcPic);
                //saveFrameAsPNG_RCHadPreAssess_MS_APC(pcPic);
                //saveFrameAsPNG_RCHadPreAssess_wCornerTest_MS_APC(pcPic);
                saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(pcPic);
                //saveFrameAsPNG_SAD4wAPC(pcPic);
//                saveFrameAsPNG_SADx_PreAssessSAD_APC(pcPic);
//			    saveFrameAsPNG_SADx_PreAssess_APC(pcPic);
                saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(pcPic);
                //saveFrameAsPNG_SADx_PreAssess_Asym_Only(pcPic);
//			    saveFrameAsPNG_SADx_NonSq_PreAssess_APC(pcPic);
                saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(pcPic);
                //saveFrameAsPNG_SSEx_wSASD(pcPic);
				saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(pcPic);
			    // Existing
			    saveFrameAsPNG_Hadamard(pcPic);
                //saveFrameAsPNG_Hadamard4x4(pcPic);
			    saveFrameAsPNG_RateControlHad(pcPic);
                saveFrameAsPNG_RateControlJND(pcPic);
			    saveFrameAsPNG_SSEx_Only(pcPic);
                //saveFrameAsPNG_SAD4_Only(pcPic);
			    saveFrameAsPNG_SADx_Only(pcPic);
			    saveFrameAsPNG_SADx_NonSq_Only(pcPic);
		    }
        }
		
		
		// erase non-referenced picture in the reference picture list after display
		if ( !pcPic->getSlice(0)->isReferenced() && pcPic->getReconMark() == true )
		{
  #if !DYN_REF_FREE
		  pcPic->setReconMark(false);

		  // mark it should be extended later
		  pcPic->getPicYuvRec()->setBorderExtension( false );

  #else
		  pcPic->destroy();
		  pcListPic->erase( iterPic );
		  iterPic = pcListPic->begin(); // to the beginning, non-efficient way, have to be revised!
		  continue;
  #endif
		}
		pcPic->setOutputMark(false);
	  }
  #if !DYN_REF_FREE
	  if(pcPic != NULL)
	  {
		pcPic->destroy();
		delete pcPic;
		pcPic = NULL;
	  }
  #endif
	  iterPic++;
	}
  }
  pcListPic->clear();
  m_iPOCLastDisplay = -MAX_INT;
}

/** \param nalu Input nalu to check whether its LayerId is within targetDecLayerIdSet
 */
Bool TAppDecTop::isNaluWithinTargetDecLayerIdSet( InputNALUnit* nalu )
{
  if ( m_targetDecLayerIdSet.size() == 0 ) // By default, the set is empty, meaning all LayerIds are allowed
  {
	return true;
  }
  for (std::vector<Int>::iterator it = m_targetDecLayerIdSet.begin(); it != m_targetDecLayerIdSet.end(); it++)
  {
	if ( nalu->m_reservedZero6Bits == (*it) )
	{
	  return true;
	}
  }
  return false;
}

// ====================================================================================================================
// YGJ Functions/Methods
// ====================================================================================================================

// Make this a variable in config file, default being 8
int TAppDecTop::DistWidthSize(int blkwidth)
{
	int value = 8; // default value;

	switch(blkwidth)
	{
	   case 16 : value = 16; break;
	   case 32 : value = 32; break;
	   case 64 : value = 64; break;
	}
	return value;
}

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
Void TAppDecTop::saveFrameAsSSIMLog(TComPic* pcPic)
{
  // YGJ 14th Oct 2013 - Attempting to save decoded frames/images as PNG
  //Pel*  pRec = pcPic->getPicYuvRec()->getLumaAddr();

  // Need to convert from YUV to RGB

  /*// From http://www.fourcc.org/yuv2ppm.c

	Another formula I found:  (seems to work)

	R = Y + 1.370705 (V-128)

	G = Y - 0.698001 (V-128) - 0.337633 (U-128)

	B = Y + 1.732446 (U-128)

  */

//  r = y + (1.370705 * (v-128));
//
//  g = y - (0.698001 * (v-128)) - (0.337633 * (u-128));
//
//  b = y + (1.732446 * (u-128));

  //--------------
  //http://softpixel.com/~cwright/programming/colorspace/yuv/

//  R = Y + 1.4075 * (V - 128)
//  G = Y - 0.3455 * (U - 128) - (0.7169 * (V - 128))
//  B = Y + 1.7790 * (U - 128)
  //--------------

// ChromaFormat chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
//                 m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

//  ComponentID CompId = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
//                 m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

// From TypeDef.h
//    enum ComponentID
//    {
//      COMPONENT_Y       = 0,
//      COMPONENT_Cb      = 1,
//      COMPONENT_Cr      = 2,
//      MAX_NUM_COMPONENT = 3
//    };

  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  //TComPicYuv* imageOrg = pcPic->getPicYuvOrg();
  //TComPicYuv* imageOrg = m_pcPicRef->getPicYuvOrg();
  TComPicYuv* imageOrg = m_pcPicYuvOrg; //pcPic->getPicYuvOrg(); //&cPicYuvTrueOrg;
  //TComPicYuv* imageRec = pcPic1->getPicYuvRec(); //m_pcPicYuvRec; // Seems to work  with pcPic and Rec
  TComPicYuv* imageRec =  pcPic->getPicYuvRec(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;
  //TComPicYuv* imageRecPart = &cPicYuvTrueOrg; //pcPic->getPicYuvRec(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;

  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);
  Pel*  piCb_Org  = imageOrg->getAddr(COMPONENT_Cb);
  Pel*  piCr_Org  = imageOrg->getAddr(COMPONENT_Cr);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
  Pel*  piCb_Rec  = imageRec->getAddr(COMPONENT_Cb);
  Pel*  piCr_Rec  = imageRec->getAddr(COMPONENT_Cr);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);
  Pel*  piCb_Part = imageRecPart->getAddr(COMPONENT_Cb);
  Pel*  piCr_Part  = imageRecPart->getAddr(COMPONENT_Cr);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);
  unsigned CStride = imageOrg->getStride(COMPONENT_Cb);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
  //unsigned CStrideRec = imageRec->getCStride();

  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
	int CShift = (YStride == (CStride<<1))? 1
		: YStride == CStride? 0 : -1;

//    int CShiftRec = (YStrideRec == (CStrideRec<<1))? 1
//        : YStrideRec == CStrideRec? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? (FrameRes >> 2)
	   : CShift == 0? (FrameRes >> 1) : FrameRes;

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
  Pel *ptrU_Org;   ptrU_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Org == NULL)   printf("calloc failed\n");
  Pel *ptrV_Org;   ptrV_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrU_Rec;   ptrU_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrV_Rec;   ptrV_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
  Pel *ptrU_Part;   ptrU_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Part == NULL)   printf("calloc failed\n");
  Pel *ptrV_Part;   ptrV_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  //char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  strcat(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;  // unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
	Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

 double frmAverageSSIM = 0.0;
 int OverlappingSSIMcount =0;
		  
 //float PxAve_SSIM_distortion = 0.0;
 unsigned long long FrmTotal_SSE_distortion = 0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;
		unsigned cloc = prevCloc;

		// CShift: 1, 0, -1
		// 420: 1/4, 422: 1/2, 444: 1
		if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 2) * (width >> 2) + (x >> 2);
		}
		else if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 1) * (width >> 1) + (x >> 1);
		}
		else if (CShift == -1)
		  cloc = yloc;

		prevCloc = cloc;

		// allocate YUV value
//		int yInt = 0, uInt = 0, vInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

		int iTemp = abs(yInt_Org - yInt_Rec);
		int SSE = iTemp*iTemp;
		// seems fine here
		if (iTemp > 255 || iTemp < 0 || SSE > 65025 || SSE < 0)
			printf("Out of range pixel value, iTemp, %d, SSE, %d \n", iTemp, SSE);


		FrmTotal_SSE_distortion += iTemp; //SSE;
		//// store max value max
		//FrmTotal_SSE_distortion =  SSE > FrmTotal_SSE_distortion ? SSE : FrmTotal_SSE_distortion;
		//                
		//if (FrmTotal_SSE_distortion > 65025 || FrmTotal_SSE_distortion < 0 )
		//    printf("Out of range pixel value, FrmTotal_SSE_distortion, %d \n", FrmTotal_SSE_distortion);
		 
		if ((x% CShift) == 0)
		{
		  unsigned cx = (x >> CShift);

		  ptrU_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Org[cx]+offsetc)>>shiftc); ptrV_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Org[cx]+offsetc)>>shiftc);
		  ptrU_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Rec[cx]+offsetc)>>shiftc); ptrV_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Rec[cx]+offsetc)>>shiftc);
		  ptrU_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Part[cx]+offsetc)>>shiftc); ptrV_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Part[cx]+offsetc)>>shiftc);

		  //uInt_Org = (int)ptrU_Org[cloc];  vInt_Org = (int)ptrV_Org[cloc];
//		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
		  //uInt_Part = (int)ptrU_Part[cloc];  vInt_Part = (int)ptrV_Part[cloc];

		}
//		else
//		{
//		  //uInt_Org = (int)ptrU_Org[cloc];  vInt_Org = (int)ptrV_Org[cloc];
//		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
//		  //uInt_Part = (int)ptrU_Part[cloc];  vInt_Part = (int)ptrV_Part[cloc];
//		}

		// Y-SSIM
		// From img_dist_ssim.c (JM 18.6 H.264 Ref Encoder)

//        float OneMinSSIM = 0.0;  // Assuming Perfect score at this point
//        bool SSIMRegion = false;

		if ((y < (height-8)) && (x < (width-8)))
		{
//          SSIMRegion = true;
		  static const float K1 = 0.01f, K2 = 0.03f;
		  float max_pix_value_sqd;
		  float C1, C2;
		  float win_pixels = (float) (8 * 8);
		  float win_pixels_bias = win_pixels - 1;
		  float mb_ssim, meanOrg, meanEnc;
		  float varOrg, varEnc, covOrgEnc;
		  int imeanOrg, imeanEnc, ivarOrg, ivarEnc, icovOrgEnc;
		  float cur_distortion = 0.0;
		  //int i, j, n, m, win_cnt = 0;
		  //int overlapSize = 7;

		  max_pix_value_sqd = (float) ( MaxValue * MaxValue);
		  C1 = K1 * K1 * max_pix_value_sqd;
		  C2 = K2 * K2 * max_pix_value_sqd;

		  imeanOrg = 0;
		  imeanEnc = 0;
		  ivarOrg  = 0;
		  ivarEnc  = 0;
		  icovOrgEnc = 0;



			for ( unsigned n = 0; n < 8; n++ )
			{
				for ( unsigned m = 0; m < 8; m++ )
				{
					unsigned yloc8x8 = n*m+m;

					//int y_Org = Clip3<Pel>(0, MaxValue, (piY_Org[x+m]+offset + (YStride*n) )>>shift);
					//int y_Rec = Clip3<Pel>(0, MaxValue, (piY_Rec[x+m]+offset + (YStride*n) )>>shift);

					ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);


					int y_Org = (int)ptrY_Org8x8[yloc8x8];//Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					int y_Rec = (int)ptrY_Rec8x8[yloc8x8];//Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStride*n)] +offset))>>shift);


					//int yloc_Rec = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

					//int yBase_Org = (int)ptrY_Org[yloc];
					//int yBase_Rec = (int)ptrY_Rec[yloc];

					//ylocDelta = y*(x+n)+x+m;

					imeanOrg   += y_Org;
					imeanEnc   += y_Rec;
					ivarOrg    += y_Org * y_Org;
					ivarEnc    += y_Rec * y_Rec;
					icovOrgEnc += y_Org * y_Rec;
				}
			}


		  meanOrg = (float) imeanOrg / win_pixels;
		  meanEnc = (float) imeanEnc / win_pixels;

		  varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
		  varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) / win_pixels_bias;
		  covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) / win_pixels_bias;

		  mb_ssim  = (float) ((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
		  mb_ssim /= (float) (meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

		  cur_distortion = mb_ssim;
		  //cur_distortion += mb_ssim;
		  //win_cnt++;

		  //cur_distortion /= (float) win_cnt;

		  //Test Scenarios SSIM of 1, 0 and -1
		  if (cur_distortion >= 1.0 && cur_distortion < 1.01) // avoid float accuracy problem at very low QP(e.g.2)
			cur_distortion = 1.0;

		  //PxAve_SSIM_distortion =cur_distortion;

//          OneMinSSIM = 1- cur_distortion;

		  frmAverageSSIM +=  cur_distortion;
		  OverlappingSSIMcount++;

		  //printf("PxAve_SSIM_distortion, %f, OneMinSSIM, %f \n", PxAve_SSIM_distortion, OneMinSSIM);

		}

//		yInt = yInt_Rec;

//		uInt = uInt_Rec;
//		vInt = vInt_Rec;

		//--------------

//        //--------------
//        //http://softpixel.com/~cwright/programming/colorspace/yuv/
//
//        // R = Y + 1.4075 * (V - 128)
//        // G = Y - 0.3455 * (U - 128) - (0.7169 * (V - 128))
//        // B = Y + 1.7790 * (U - 128)
//        //--------------


//		// Rec - Org
//
//		int u_MinHalfMaxVal = uInt - HalfMaxValue;   int v_MinHalfMaxVal = vInt - HalfMaxValue;
////        //int u_MinHalfMaxVal = uInt - HalfMaxValue;   int v_MinHalfMaxVal = vInt - HalfMaxValue;
////
////        // Convert YUV to RGB
//
//
//		int r = yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//		int g = yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//		int b = yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//
//		if (SSIMRegion == true)
//		{
//			float capped1MinSSIM = (float) (OneMinSSIM > 1.0 ? 1.0 : OneMinSSIM);  // Limit it to 1.
//
//			float avScaledScore = capped1MinSSIM; //(float)((cappedSSENorm + cappedSADNorm)/2.0);
//			//float 
//			avScaledScore = (2*avScaledScore - (avScaledScore*avScaledScore)); // y=4(2x-x^2)
//
//			//unsigned int val = (unsigned int)((float)OneMinSSIM*2.0);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.
//			//unsigned int val = (unsigned int)(avScaledScore);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.
//			unsigned int val = (unsigned int)(avScaledScore*4.0);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.
//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((avScaledScore/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((avScaledScore-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((avScaledScore-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((avScaledScore-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}
//
//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((avScaledScore/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((avScaledScore-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((avScaledScore-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				//default : r = yInt_Rec;  g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((avScaledScore-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------
//
//		}
//
//
//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;
//
//
//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}
//
//
//
//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;


	  // CShift: 1, 0, -1
	  // 420: 1/4, 422: 1/2, 444: 1
	  if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == -1)
	  {
		  piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
	  }
	}

	//printf("frmAverageSSIM, %f, 1-SSIM, %f, \n", frmAverageSSIM, 1-frmAverageSSIM);
	
	//PxAve_SSIM_distortion = PxAve_SSIM_distortion/((height-8) * (width-8));
	//printf("Frame (8x8 overlapping) SSIM and 1-SSIM scores, %f, %f, Frame SSE, %d ", PxAve_SSIM_distortion, 1-PxAve_SSIM_distortion), FrmTotal_SSE_distortion;
		//std::vector<unsigned char> png;
	//std::cout << "Frame (8x8 overlapping) SSIM and 1-SSIM scores, " << PxAve_SSIM_distortion << ", " << 1-PxAve_SSIM_distortion << ",  Frame SSE, " << FrmTotal_SSE_distortion << std::endl;

	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);
	free(ptrU_Org);
	free(ptrV_Org);

	free(ptrY_Rec);
	free(ptrU_Rec);
	free(ptrV_Rec);


	free(ptrY_Part);
	free(ptrU_Part);
	free(ptrV_Part);

	////-----------------------

	if(m_outputSSIMAndSSELog)
	{
		frmAverageSSIM /=  (double)OverlappingSSIMcount;
		//int frmAveSSE = 0; //(int)((double)FrmTotal_SSE_distortion/(double)FrameRes);
		int frmAveSSE = (int)((double)FrmTotal_SSE_distortion/(double)FrameRes);

		char SSIMFrmAveFile[255];  strcpy(SSIMFrmAveFile, m_pchSSIMLogAndImageFile);  strcat(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");
		//strcpy(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");

		ofstream DecFrmSSIM;
		DecFrmSSIM.open (SSIMFrmAveFile, ios::out | ios::app);


		// Log out the Existing  without Proposed , Existing  with Proposed, Final threshold based Result (with or without Proposed), Threshold Result , SSIM, 1-SSIM, stats,
		DecFrmSSIM << frmAverageSSIM << ","  << 1-frmAverageSSIM << ","  << FrmTotal_SSE_distortion << ","  << frmAveSSE << endl;

		//DecFrmSSIM << frmAveSSE ;

		//DecFrmSSIM << endl;
		DecFrmSSIM.close();
	}

	////-----------------------

	//-----------------------

	//if(m_outputSSIMHeatmaps)
	//{
	//  std::vector<unsigned char> png;

	//  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	//  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	//  //if there's an error, display it
	//  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	//}

   //-----------------------

}


// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
Void TAppDecTop::saveFrameAsPNGSSIM(TComPic* pcPic)
{
  // YGJ 14th Oct 2013 - Attempting to save decoded frames/images as PNG
  //Pel*  pRec = pcPic->getPicYuvRec()->getLumaAddr();

  // Need to convert from YUV to RGB

  /*// From http://www.fourcc.org/yuv2ppm.c

	Another formula I found:  (seems to work)

	R = Y + 1.370705 (V-128)

	G = Y - 0.698001 (V-128) - 0.337633 (U-128)

	B = Y + 1.732446 (U-128)

  */

//  r = y + (1.370705 * (v-128));
//
//  g = y - (0.698001 * (v-128)) - (0.337633 * (u-128));
//
//  b = y + (1.732446 * (u-128));

  //--------------
  //http://softpixel.com/~cwright/programming/colorspace/yuv/

//  R = Y + 1.4075 * (V - 128)
//  G = Y - 0.3455 * (U - 128) - (0.7169 * (V - 128))
//  B = Y + 1.7790 * (U - 128)
  //--------------

// ChromaFormat chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
//                 m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

//  ComponentID CompId = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
//                 m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

// From TypeDef.h
//    enum ComponentID
//    {
//      COMPONENT_Y       = 0,
//      COMPONENT_Cb      = 1,
//      COMPONENT_Cr      = 2,
//      MAX_NUM_COMPONENT = 3
//    };

  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  //TComPicYuv* imageOrg = pcPic->getPicYuvOrg();
  //TComPicYuv* imageOrg = m_pcPicRef->getPicYuvOrg();
  TComPicYuv* imageOrg = m_pcPicYuvOrg; //pcPic->getPicYuvOrg(); //&cPicYuvTrueOrg;
  //TComPicYuv* imageRec = pcPic1->getPicYuvRec(); //m_pcPicYuvRec; // Seems to work  with pcPic and Rec
  TComPicYuv* imageRec =  pcPic->getPicYuvRec(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;
  //TComPicYuv* imageRecPart = &cPicYuvTrueOrg; //pcPic->getPicYuvRec(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;

  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);
  Pel*  piCb_Org  = imageOrg->getAddr(COMPONENT_Cb);
  Pel*  piCr_Org  = imageOrg->getAddr(COMPONENT_Cr);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
  Pel*  piCb_Rec  = imageRec->getAddr(COMPONENT_Cb);
  Pel*  piCr_Rec  = imageRec->getAddr(COMPONENT_Cr);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);
  Pel*  piCb_Part = imageRecPart->getAddr(COMPONENT_Cb);
  Pel*  piCr_Part  = imageRecPart->getAddr(COMPONENT_Cr);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);
  unsigned CStride = imageOrg->getStride(COMPONENT_Cb);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
  //unsigned CStrideRec = imageRec->getCStride();

  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
	int CShift = (YStride == (CStride<<1))? 1
		: YStride == CStride? 0 : -1;

//    int CShiftRec = (YStrideRec == (CStrideRec<<1))? 1
//        : YStrideRec == CStrideRec? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? (FrameRes >> 2)
	   : CShift == 0? (FrameRes >> 1) : FrameRes;

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
  Pel *ptrU_Org;   ptrU_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Org == NULL)   printf("calloc failed\n");
  Pel *ptrV_Org;   ptrV_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrU_Rec;   ptrU_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrV_Rec;   ptrV_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
  Pel *ptrU_Part;   ptrU_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Part == NULL)   printf("calloc failed\n");
  Pel *ptrV_Part;   ptrV_Part = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  strcat(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
	Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

 double frmAverageSSIM = 0.0;
 int OverlappingSSIMcount =0;
		  
 //float PxAve_SSIM_distortion = 0.0;
 unsigned long long FrmTotal_SSE_distortion = 0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;
		unsigned cloc = prevCloc;

		// CShift: 1, 0, -1
		// 420: 1/4, 422: 1/2, 444: 1
		if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 2) * (width >> 2) + (x >> 2);
		}
		else if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 1) * (width >> 1) + (x >> 1);
		}
		else if (CShift == -1)
		  cloc = yloc;

		prevCloc = cloc;

		// allocate YUV value
		int yInt = 0, uInt = 0, vInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

		int iTemp = abs(yInt_Org - yInt_Rec);
		int SSE = iTemp*iTemp;
		// seems fine here
		if (iTemp > 255 || iTemp < 0 || SSE > 65025 || SSE < 0)
			printf("Out of range pixel value, iTemp, %d, SSE, %d \n", iTemp, SSE);


		FrmTotal_SSE_distortion += iTemp; //SSE;
		//// store max value max
		//FrmTotal_SSE_distortion =  SSE > FrmTotal_SSE_distortion ? SSE : FrmTotal_SSE_distortion;
		//                
		//if (FrmTotal_SSE_distortion > 65025 || FrmTotal_SSE_distortion < 0 )
		//    printf("Out of range pixel value, FrmTotal_SSE_distortion, %d \n", FrmTotal_SSE_distortion);
		 
		if ((x% CShift) == 0)
		{
		  unsigned cx = (x >> CShift);

		  ptrU_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Org[cx]+offsetc)>>shiftc); ptrV_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Org[cx]+offsetc)>>shiftc);
		  ptrU_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Rec[cx]+offsetc)>>shiftc); ptrV_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Rec[cx]+offsetc)>>shiftc);
		  ptrU_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Part[cx]+offsetc)>>shiftc); ptrV_Part[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Part[cx]+offsetc)>>shiftc);

		  //uInt_Org = (int)ptrU_Org[cloc];  vInt_Org = (int)ptrV_Org[cloc];
		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
		  //uInt_Part = (int)ptrU_Part[cloc];  vInt_Part = (int)ptrV_Part[cloc];

		}
		else
		{
		  //uInt_Org = (int)ptrU_Org[cloc];  vInt_Org = (int)ptrV_Org[cloc];
		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
		  //uInt_Part = (int)ptrU_Part[cloc];  vInt_Part = (int)ptrV_Part[cloc];
		}

		// Y-SSIM
		// From img_dist_ssim.c (JM 18.6 H.264 Ref Encoder)

		float OneMinSSIM = 0.0;  // Assuming Perfect score at this point
		bool SSIMRegion = false;

		if ((y < (height-8)) && (x < (width-8)))
		{
		  SSIMRegion = true;
		  static const float K1 = 0.01f, K2 = 0.03f;
		  float max_pix_value_sqd;
		  float C1, C2;
		  float win_pixels = (float) (8 * 8);
		  float win_pixels_bias = win_pixels - 1;
		  float mb_ssim, meanOrg, meanEnc;
		  float varOrg, varEnc, covOrgEnc;
		  int imeanOrg, imeanEnc, ivarOrg, ivarEnc, icovOrgEnc;
		  float cur_distortion = 0.0;
		  //int i, j, n, m, win_cnt = 0;
		  //int overlapSize = 7;

		  max_pix_value_sqd = (float) ( MaxValue * MaxValue);
		  C1 = K1 * K1 * max_pix_value_sqd;
		  C2 = K2 * K2 * max_pix_value_sqd;

		  imeanOrg = 0;
		  imeanEnc = 0;
		  ivarOrg  = 0;
		  ivarEnc  = 0;
		  icovOrgEnc = 0;



			for ( unsigned n = 0; n < 8; n++ )
			{
				for ( unsigned m = 0; m < 8; m++ )
				{
					unsigned yloc8x8 = n*m+m;

					//int y_Org = Clip3<Pel>(0, MaxValue, (piY_Org[x+m]+offset + (YStride*n) )>>shift);
					//int y_Rec = Clip3<Pel>(0, MaxValue, (piY_Rec[x+m]+offset + (YStride*n) )>>shift);

					ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);


					int y_Org = (int)ptrY_Org8x8[yloc8x8];//Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					int y_Rec = (int)ptrY_Rec8x8[yloc8x8];//Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStride*n)] +offset))>>shift);


					//int yloc_Rec = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

					//int yBase_Org = (int)ptrY_Org[yloc];
					//int yBase_Rec = (int)ptrY_Rec[yloc];

					//ylocDelta = y*(x+n)+x+m;

					imeanOrg   += y_Org;
					imeanEnc   += y_Rec;
					ivarOrg    += y_Org * y_Org;
					ivarEnc    += y_Rec * y_Rec;
					icovOrgEnc += y_Org * y_Rec;
				}
			}


		  meanOrg = (float) imeanOrg / win_pixels;
		  meanEnc = (float) imeanEnc / win_pixels;

		  varOrg    = ((float) ivarOrg - ((float) imeanOrg) * meanOrg) / win_pixels_bias;
		  varEnc    = ((float) ivarEnc - ((float) imeanEnc) * meanEnc) / win_pixels_bias;
		  covOrgEnc = ((float) icovOrgEnc - ((float) imeanOrg) * meanEnc) / win_pixels_bias;

		  mb_ssim  = (float) ((2.0 * meanOrg * meanEnc + C1) * (2.0 * covOrgEnc + C2));
		  mb_ssim /= (float) (meanOrg * meanOrg + meanEnc * meanEnc + C1) * (varOrg + varEnc + C2);

		  cur_distortion = mb_ssim;
		  //cur_distortion += mb_ssim;
		  //win_cnt++;

		  //cur_distortion /= (float) win_cnt;

		  //Test Scenarios SSIM of 1, 0 and -1
		  if (cur_distortion >= 1.0 && cur_distortion < 1.01) // avoid float accuracy problem at very low QP(e.g.2)
			cur_distortion = 1.0;

		  //PxAve_SSIM_distortion =cur_distortion;

		  OneMinSSIM = 1- cur_distortion;

		  frmAverageSSIM +=  cur_distortion;
		  OverlappingSSIMcount++;

		  //printf("PxAve_SSIM_distortion, %f, OneMinSSIM, %f \n", PxAve_SSIM_distortion, OneMinSSIM);

		}

		yInt = yInt_Rec;

		uInt = uInt_Rec;
		vInt = vInt_Rec;

		//--------------

//        //--------------
//        //http://softpixel.com/~cwright/programming/colorspace/yuv/
//
//        // R = Y + 1.4075 * (V - 128)
//        // G = Y - 0.3455 * (U - 128) - (0.7169 * (V - 128))
//        // B = Y + 1.7790 * (U - 128)
//        //--------------


		// Rec - Org

		int u_MinHalfMaxVal = uInt - HalfMaxValue;   int v_MinHalfMaxVal = vInt - HalfMaxValue;
//        //int u_MinHalfMaxVal = uInt - HalfMaxValue;   int v_MinHalfMaxVal = vInt - HalfMaxValue;
//
//        // Convert YUV to RGB


		int r = yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
		int g = yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
		int b = yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

		if (SSIMRegion == true)
		{
			float capped1MinSSIM = (float) (OneMinSSIM > 1.0 ? 1.0 : OneMinSSIM);  // Limit it to 1.

			float avScaledScore = capped1MinSSIM; //(float)((cappedSSENorm + cappedSADNorm)/2.0);
			//float 
			avScaledScore = (2*avScaledScore - (avScaledScore*avScaledScore)); // y=4(2x-x^2)

			//unsigned int val = (unsigned int)((float)OneMinSSIM*2.0);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.
			//unsigned int val = (unsigned int)(avScaledScore);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.
			unsigned int val = (unsigned int)(avScaledScore*4.0);  // This will ensure 1-SSIM is 0 if < 0.5, 1 if < 1.0, 2 if < 1.5 and 3 if > 1.5.
			//switch (val)
			//{
			//	case 0 :  r = yInt; g = (int)((avScaledScore/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt-((avScaledScore-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt; b = (int)(((avScaledScore-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt-((avScaledScore-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((avScaledScore/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((avScaledScore-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((avScaledScore-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;
				//default : r = yInt_Rec;  g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((avScaledScore-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}



		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;


	  // CShift: 1, 0, -1
	  // 420: 1/4, 422: 1/2, 444: 1
	  if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == -1)
	  {
		  piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
	  }
	}

	//printf("frmAverageSSIM, %f, 1-SSIM, %f, \n", frmAverageSSIM, 1-frmAverageSSIM);
	
	//PxAve_SSIM_distortion = PxAve_SSIM_distortion/((height-8) * (width-8));
	//printf("Frame (8x8 overlapping) SSIM and 1-SSIM scores, %f, %f, Frame SSE, %d ", PxAve_SSIM_distortion, 1-PxAve_SSIM_distortion), FrmTotal_SSE_distortion;
		//std::vector<unsigned char> png;
	//std::cout << "Frame (8x8 overlapping) SSIM and 1-SSIM scores, " << PxAve_SSIM_distortion << ", " << 1-PxAve_SSIM_distortion << ",  Frame SSE, " << FrmTotal_SSE_distortion << std::endl;

	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);
	free(ptrU_Org);
	free(ptrV_Org);

	free(ptrY_Rec);
	free(ptrU_Rec);
	free(ptrV_Rec);


	free(ptrY_Part);
	free(ptrU_Part);
	free(ptrV_Part);

	////-----------------------

	//if(m_outputSSIMAndSSELog)
	//{
	//	frmAverageSSIM /=  (double)OverlappingSSIMcount;
	//	int frmAveSSE = 0; //(int)((double)FrmTotal_SSE_distortion/(double)FrameRes);

	//	char SSIMFrmAveFile[255];  strcpy(SSIMFrmAveFile, m_pchSSIMLogAndImageFile);  strcat(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");
	//	//strcpy(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");

	//	ofstream DecFrmSSIM;
	//	DecFrmSSIM.open (SSIMFrmAveFile, ios::out | ios::app);


	//	// Log out the Existing  without Proposed , Existing  with Proposed, Final threshold based Result (with or without Proposed), Threshold Result , SSIM, 1-SSIM, stats,
	//	DecFrmSSIM << frmAverageSSIM << ","  << 1-frmAverageSSIM << ","  << FrmTotal_SSE_distortion << ","  << frmAveSSE << endl;

	//	//DecFrmSSIM << frmAveSSE ;

	//	//DecFrmSSIM << endl;
	//	DecFrmSSIM.close();
	//}

	////-----------------------

	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

}

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
Void TAppDecTop::saveFrameAsPNGPartition(TComPic* pcPic)
{
  // YGJ 14th Oct 2013 - Attempting to save decoded frames/images as PNG
  //Pel*  pRec = pcPic->getPicYuvRec()->getLumaAddr();

  // Need to convert from YUV to RGB

  /*// From http://www.fourcc.org/yuv2ppm.c

	Another formula I found:  (seems to work)

	R = Y + 1.370705 (V-128)

	G = Y - 0.698001 (V-128) - 0.337633 (U-128)

	B = Y + 1.732446 (U-128)

  */

//  r = y + (1.370705 * (v-128));
//
//  g = y - (0.698001 * (v-128)) - (0.337633 * (u-128));
//
//  b = y + (1.732446 * (u-128));

  //--------------
  //http://softpixel.com/~cwright/programming/colorspace/yuv/

//  R = Y + 1.4075 * (V - 128)
//  G = Y - 0.3455 * (U - 128) - (0.7169 * (V - 128))
//  B = Y + 1.7790 * (U - 128)
  //--------------

	// ChromaFormat chrfmt = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
	//                 m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

	//  ComponentID CompId = m_inputChromaFormat == 0? CHROMA_400 : m_inputChromaFormat == 1? CHROMA_420 :
	//                 m_inputChromaFormat == 2? CHROMA_422 : CHROMA_444;

	// From TypeDef.h
	//    enum ComponentID
	//    {
	//      COMPONENT_Y       = 0,
	//      COMPONENT_Cb      = 1,
	//      COMPONENT_Cr      = 2,
	//      MAX_NUM_COMPONENT = 3
	//    };
	 
  //printf("m_pimageOrgcPicYuvOrg->getHeight(COMPONENT_Y) , %d, m_pcPicYuvOrg->getWidth(COMPONENT_Y), %d \n", m_pcPicYuvOrg->getHeight(COMPONENT_Y), m_pcPicYuvOrg->getWidth(COMPONENT_Y));
  //printf("(pcPic->getPicYuvOrg())->getHeight(COMPONENT_Y) , %d, (pcPic->getPicYuvOrg())->getWidth(COMPONENT_Y), %d \n", (pcPic->getPicYuvOrg())->getHeight(COMPONENT_Y),  (pcPic->getPicYuvOrg())->getWidth(COMPONENT_Y));
  unsigned height = m_iSourceHeight; //m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; //m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  //TComPicYuv* imageOrg = pcPic->getPicYuvOrg();
  //TComPicYuv* imageOrg = m_pcPicRef->getPicYuvOrg();
  //TComPicYuv* imageOrg = &cPicYuvTrueOrg; //m_pcPicYuvOrg;
  //TComPicYuv* imageRec = pcPic->getPicYuvRec(); //m_pcPicYuvRec; // Seems to work  with pcPic and Rec
  TComPicYuv* imageRec = pcPic->getPicYuvWPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

  //Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);
  //Pel*  piCb_Org  = imageOrg->getAddr(COMPONENT_Cb);
  //Pel*  piCr_Org  = imageOrg->getAddr(COMPONENT_Cr);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
  Pel*  piCb_Rec  = imageRec->getAddr(COMPONENT_Cb);
  Pel*  piCr_Rec  = imageRec->getAddr(COMPONENT_Cr);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
  unsigned CStride = imageRec->getStride(COMPONENT_Cb);


  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
	int CShift = (YStride == (CStride<<1))? 1
		: YStride == CStride? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? (FrameRes >> 2)
	   : CShift == 0? (FrameRes >> 1) : FrameRes;

  // Allocate memory for output frame

  //// Orig
  //Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
  //Pel *ptrU_Org;   ptrU_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Org == NULL)   printf("calloc failed\n");
  //Pel *ptrV_Org;   ptrV_Org = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrU_Rec;   ptrU_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Rec == NULL)   printf("calloc failed\n");
  Pel *ptrV_Rec;   ptrV_Rec = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrV_Rec == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  //char FrmAsPNG[80];  strcpy(FrmAsPNG, "DecFrm_Partition_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");
  char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  strcat(FrmAsPNG, "DecFrm_Partition_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");
  //char SSIMHeatmap[500];  strcpy(SSIMHeatmap, m_pchSSIMALogAndImageFile);  strcat(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
	Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;
		unsigned cloc = prevCloc;

		// CShift: 1, 0, -1
		// 420: 1/4, 422: 1/2, 444: 1
		if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 2) * (width >> 2) + (x >> 2);
		}
		else if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 1) * (width >> 1) + (x >> 1);
		}
		else if (CShift == -1)
		  cloc = yloc;

		prevCloc = cloc;

		// allocate YUV value
		//ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];  int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];

		if ((x% CShift) == 0)
		{
		  unsigned cx = (x >> CShift);

		  //ptrU_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Org[cx]+offsetc)>>shiftc); ptrV_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Org[cx]+offsetc)>>shiftc);
		  ptrU_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Rec[cx]+offsetc)>>shiftc); ptrV_Rec[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Rec[cx]+offsetc)>>shiftc);

		  //uInt_Org = (int)ptrU_Org[cloc];  vInt_Org = (int)ptrV_Org[cloc];
		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];

		}
		else
		{
		  //uInt_Org = (int)ptrU_Org[cloc];  vInt_Org = (int)ptrV_Org[cloc];
		  uInt_Rec = (int)ptrU_Rec[cloc];  vInt_Rec = (int)ptrV_Rec[cloc];
		}

//        //--------------
//        //http://softpixel.com/~cwright/programming/colorspace/yuv/
//
//        // R = Y + 1.4075 * (V - 128)
//        // G = Y - 0.3455 * (U - 128) - (0.7169 * (V - 128))
//        // B = Y + 1.7790 * (U - 128)
//        //--------------
//

		// Original is read fin
		//int yInt_RmO = yInt_Org; int u_MinHalfMaxVal_RmO = uInt_Org - HalfMaxValue;   int v_MinHalfMaxVal_RmO = vInt_Org - HalfMaxValue;
		// Reconstructed not read correctly.
		int yInt_RmO = yInt_Rec; int u_MinHalfMaxVal_RmO = uInt_Rec - HalfMaxValue;   int v_MinHalfMaxVal_RmO = vInt_Rec - HalfMaxValue;


		// Need to abs(green) to avoid negative values. abs(Y-U/2-V/2)

		// Rec - Org
		int r_RmO = yInt_RmO + v_MinHalfMaxVal_RmO + ((13 * v_MinHalfMaxVal_RmO) >> 5);
		int g_RmO = abs(yInt_RmO - ((11 * u_MinHalfMaxVal_RmO) >> 5) - ((23 * v_MinHalfMaxVal_RmO) >> 5));
		int b_RmO = yInt_RmO + u_MinHalfMaxVal_RmO + ((99 * u_MinHalfMaxVal_RmO) >> 7);

		// Rec - Org
		r_RmO =  r_RmO > MaxValue ? MaxValue : r_RmO < 0 ? 0 : r_RmO;
		g_RmO =  g_RmO > MaxValue ? MaxValue : g_RmO < 0 ? 0 : g_RmO;
		b_RmO =  b_RmO > MaxValue ? MaxValue : b_RmO < 0 ? 0 : b_RmO;

		// Partitioning
		if (yInt_RmO == 0 && (x % 2 == 0 || y % 2 == 0))
		{
		  r_RmO = yInt_RmO;
		  g_RmO = yInt_RmO;
		  b_RmO = yInt_RmO;
		}

		imgFrmAsPNG[4 * width * y + 4 * x + 0] = r_RmO; //Red
		imgFrmAsPNG[4 * width * y + 4 * x + 1] = g_RmO; //Green
		imgFrmAsPNG[4 * width * y + 4 * x + 2] = b_RmO; //Blue
		imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  //piY_Org += YStride;
	  piY_Rec += YStride;


	  // CShift: 1, 0, -1
	  // 420: 1/4, 422: 1/2, 444: 1
	  if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  //piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  //piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
		}
	  }
	  else if (CShift == -1)
	  {
		  //piCr_Org += CStride; piCb_Org += CStride;
		  piCr_Rec += CStride; piCb_Rec += CStride;
	  }
	}

	free(ptrY_Rec);
	free(ptrU_Rec);
	free(ptrV_Rec);



	  //Encode the image
	  unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

	  //if there's an error, display it
	  if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;




}

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel) -- Working
Void TAppDecTop::saveFrameAsPNGPartwQP(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight; //m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; //m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  TComPicYuv* imageRec = pcPic->getPicYuvWPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;
  TComPicYuv* imageSig = pcPic->getPicYuvWQPPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);
  Pel*  piCb_Sig  = imageSig->getAddr(COMPONENT_Cb);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
  unsigned CStride = imageRec->getStride(COMPONENT_Cb);


  // 420: 1:1/4:1/4, Then Y:UV = 2xY:1xChr => CShift = 1
  // 422: 1:1/2:1/2, Then Y:UV = 2xY:2xChr => CShift = 0
  // 444: 1:1:1, Then Y:UV = 2xY:4xChr => CShift = -1
	int CShift = (YStride == (CStride<<1))? 1
		: YStride == CStride? 0 : -1;

   // 420: 1/4, 422: 1/2, 444: 1
   unsigned ChrFrmRes = CShift == 1? (FrameRes >> 2)
	   : CShift == 0? (FrameRes >> 1) : FrameRes;

  // Allocate memory for output frame

  //// Orig
  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");
  Pel *ptrU_Sig;   ptrU_Sig = (Pel *)calloc(ChrFrmRes, sizeof(Pel));   if (ptrU_Sig == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  //char FrmAsPNG[80];  strcpy(FrmAsPNG, "DecFrm_Partition_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");
  char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  strcat(FrmAsPNG, "DecFrm_PartwQP_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");
  //char SSIMHeatmap[500];  strcpy(SSIMHeatmap, m_pchSSIMALogAndImageFile);  strcat(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
	Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

int prevCloc = 0; // Previous cloc

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;
		unsigned cloc = prevCloc;

		// CShift: 1, 0, -1
		// 420: 1/4, 422: 1/2, 444: 1
		if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 2) * (width >> 2) + (x >> 2);
		}
		else if (CShift == 1)
		{
		  if (x%2 == 0)
			cloc = (y >> 1) * (width >> 1) + (x >> 1);
		}
		else if (CShift == -1)
		  cloc = yloc;

		prevCloc = cloc;

		// allocate YUV value

		// Y_Sig contains QP and U_Sig contains skipped_flag

		ptrY_Sig[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Sig[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);

		int yInt_Sig = (int)ptrY_Sig[yloc];  int  uInt_Sig = (int)ptrU_Sig[cloc]; //int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];

		if ((x% CShift) == 0)
		{
		  unsigned cx = (x >> CShift);

		  ptrU_Sig[cloc]  = Clip3<Pel>(0, MaxValue, (piCb_Sig[cx]+offsetc)>>shiftc); //ptrV_Org[cloc]  = Clip3<Pel>(0, MaxValue, (piCr_Org[cx]+offsetc)>>shiftc);

		  uInt_Sig = (int)ptrU_Sig[cloc];  //vInt_Sig = (int)ptrV_Sig[cloc];

		}
		else
		{
		  uInt_Sig = (int)ptrU_Sig[cloc]; // vInt_Sig = (int)ptrV_Sig[cloc];
		}


		// Rec - Org
		int r = 0;
		int g = 0;
		int b = 0;


		//int val = 0;

		//yInt_Sig = (yInt_Sig < 0 || yInt_Sig > 51) ? 51 : yInt_Sig;

//        if ( yInt_Sig > 0 )
//            printf("yInt_Sig (QP) %d \n", yInt_Sig);

		int val = yInt_Sig < 13 ? 0 : yInt_Sig < 26 ? 1 : yInt_Sig < 39 ? 2 : 3;

		// Normalise Had against assumed max.
		float normQP = ((float)yInt_Sig)/51; //((float)iSumHad)/quartAssumedMax;

		//if ( yInt_Sig > 0 )
		if ( uInt_Sig == 0 ) // Skipped Flag is zero
		{
			//switch (val)
			//{
			//	case 0 :  r = yInt_Rec; g = (int)((normQP/(float)0.25)*yInt_Rec); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt_Rec; b = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = yInt_Rec; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normQP/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normQP-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normQP-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;
				//default : r = yInt_Rec;  g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normQP-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = g = b = yInt_Rec;
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

		// Partitioning
		if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
		{
		  r = yInt_Rec;
		  g = yInt_Rec;
		  b = yInt_Rec;
		}

		imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
		imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
		imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
		imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Sig += YStride;
	  piY_Rec += YStride;


	  // CShift: 1, 0, -1
	  // 420: 1/4, 422: 1/2, 444: 1
	  if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCb_Sig += CStride;
		}
	  }
	  else if (CShift == 1)
	  {
		if (y%2 == 0)
		{
		  piCb_Sig += CStride;
		}
	  }
	  else if (CShift == -1)
	  {
		  piCb_Sig += CStride;
	  }
	}

	free(ptrY_Sig);
	free(ptrU_Sig);

	free(ptrY_Rec);


 
	  //Encode the image
	  unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

	  //if there's an error, display it
	  if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;



	////---------------------


}


Void TAppDecTop::saveFrameAsPNGPartwBitUsage(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight; //m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; //m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  TComPicYuv* imageRec = pcPic->getPicYuvWPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;
  TComPicYuv* imageSig = pcPic->getPicYuv_CU_BitUsage(); //>getPicYuvWQPPart(); //>getPicYuvOrg(); //>getPicYuvRec(); //m_pcPicYuvRec;

  int pcPOC = pcPic->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPOC; // For Test purpose override poc with correct poc for decoded stream

  Pel*  piY_Sig   = imageSig->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  unsigned YStride = imageRec->getStride(COMPONENT_Y);
 
  // Allocate memory for output frame

  //// Orig
  Pel *ptrY_Sig;   ptrY_Sig = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Sig == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");


  //unsigned poc = ;
  char strpoc[6];
  char strMaxCUsize[8];



  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strMaxCUsize, sizeof(strMaxCUsize), "%d", m_maxCUsize);

  //char FrmAsPNG[80];  strcpy(FrmAsPNG, "DecFrm_Partition_");    strcat(FrmAsPNG, strpoc);        strcat(FrmAsPNG, ".png");
  char FrmAsPNG[255];  strcpy(FrmAsPNG, m_pchSSIMLogAndImageFile);  
    
  strcat(FrmAsPNG, "DecFrm_PartwCU_BitUsage_");    
  strcat(FrmAsPNG, strpoc);   
  strcat(FrmAsPNG, "_MaxCUsize");  strcat(FrmAsPNG, strMaxCUsize);  
  strcat(FrmAsPNG, ".png");

  //char SSIMHeatmap[500];  strcpy(SSIMHeatmap, m_pchSSIMALogAndImageFile);  strcat(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgFrmAsPNG; imgFrmAsPNG.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
	//Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		// Position to be at the start of the Coding Unit (CU)
		// Since first four px in every row in the Sub-CU has been set with Bit Usage value it is OK to start at the beginning of the row for every CU
		unsigned CUx = (x >> 6) << 6; // Round down to the nearest 64th px.
		unsigned ylocCU = y*width+CUx;

		ptrY_Sig[ylocCU]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx]+offset)>>shift);
		ptrY_Sig[ylocCU + 1]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx + 1]+offset)>>shift);
		ptrY_Sig[ylocCU + 2]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx + 2]+offset)>>shift);
		ptrY_Sig[ylocCU + 3]  = Clip3<Pel>(0, MaxValue, (piY_Sig[CUx + 3]+offset)>>shift);

		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
	
		// Assuming Coding Unit is fixed at 64 x 64.
		// However, remaining width and height may be less than 64 by 64.

		// This stays the same within CU
		//int yInt_Sig = (int)ptrY_Sig[ylocCU];  //int  uInt_Sig = (int)ptrU_Sig[cloc]; //int  vInt_Org = (int)ptrV_Org[cloc];vInt_Org
		// Obtain the y (luma part).
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];

		// Rec - Org
		int r = 0;
		int g = 0;
		int b = 0;

		int  px[4];

		px[0] = (int)ptrY_Sig[ylocCU];  
		px[1] = (int)ptrY_Sig[ylocCU + 1];  
		px[2] = (int)ptrY_Sig[ylocCU + 2];  
		px[3] = (int)ptrY_Sig[ylocCU + 3];  
		
		// Put the bit usage value back together.
		Int64 combinedScore = px[3] << 24 | px[2] << 16 | px[1] << 8 | px[0];  

		Int BitUsage = (Int)combinedScore;
		

		//// Yes these values match those put into the the pixel array at TDecCu
		//unsigned CUy = (y >> 6) << 6; // Round down to the nearest 64th px.
		//if ( x== CUx && y == CUy)
		//    printf("combinedScore %d \n", combinedScore);

		int MaxBitUsage = m_maxCUsize;

		BitUsage = BitUsage > MaxBitUsage? MaxBitUsage : BitUsage;
		 
		int val = BitUsage < (MaxBitUsage >> 2) ? 0 : BitUsage < (MaxBitUsage >> 1) ? 1 : BitUsage < ((MaxBitUsage >> 1) + ( MaxBitUsage >> 2)) ? 2 : 3;

		// Normalise Had against assumed max.
		float normBit = ((float)BitUsage)/((float)MaxBitUsage); //((float)iSumHad)/quartAssumedMax;

		if ( BitUsage > 0 )        
		{
			//switch (val)
			//{
			//	case 0 :  r = yInt_Rec; g = (int)((normBit/(float)0.25)*yInt_Rec); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt_Rec-((normBit-0.25)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt_Rec; b = (int)(((normBit-0.50)/(float)0.25)*yInt_Rec); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = yInt_Rec; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}

			////------------------
			//switch (val)
			//{
			//	case 0 :  r = 0; g = (int)((normBit/(float)0.25)*yInt_Rec); b = yInt_Rec;   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
			//		break;
			//	case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normBit-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
			//		break;
			//	case 2 :  r = (int)(((normBit-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
			//		break;
			//	default :  r = yInt_Rec; g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
			//		break;
			//}
   //         //------------------

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normBit/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normBit-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normBit-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;
				//default : r = yInt_Rec;  g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normBit-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
			r = g = b = yInt_Rec;
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;

		// Partitioning
		if (yInt_Rec == 0 && (x % 2 == 0 || y % 2 == 0))
		{
		  r = yInt_Rec;
		  g = yInt_Rec;
		  b = yInt_Rec;
		}

		imgFrmAsPNG[4 * width * y + 4 * x + 0] = r; //Red
		imgFrmAsPNG[4 * width * y + 4 * x + 1] = g; //Green
		imgFrmAsPNG[4 * width * y + 4 * x + 2] = b; //Blue
		imgFrmAsPNG[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Sig += YStride;
	  piY_Rec += YStride;


	}

	free(ptrY_Sig);

	free(ptrY_Rec);


 
	  //Encode the image
	  unsigned error = lodepng::encode(FrmAsPNG, imgFrmAsPNG, width, height);

	  //if there's an error, display it
	  if(error) std::cout << "encoder error " << error << ": "<< lodepng_error_text(error) << std::endl;



	////---------------------


}

//Void TAppDecTop::saveFrameAsPNG_SAD4_Only(TComPic* pcPic)
//{


//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);

//  // YGJ 22nd Septy 2014
//  // Set width
//  unsigned blkwidth = 4; //DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;
  
//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);
  
//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SAD4x");    strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "_OnlyHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//	//Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

////int prevCloc = 0; // Previous cloc


//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);
        

//		bool HadRegion = false;
//		Distortion iSumHad =0;

//		if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//		{
//		  HadRegion = true;

//		  //int HadDiff[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* HadDiff = new int[blksz];


//			for ( unsigned n = 0; n < blkwidth; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

//					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

//				}
//			}

//			int i, j; //, jj;//, k;

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				iSumHad += abs(HadDiff[i+j*blkwidth]); // + abs(APC[i+j*8]);
//			  }
//			}

//			//iSumHad=((iSumHad+2)>>2);

//			delete HadDiff;

//		}



//		int yInt = yInt_Rec;


//		int r, b, g;

//		//  APC score will be between 0 and 127.
//		// Dependent upon value apply different colour
//		if (HadRegion == true)
//		{


//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = 0; //(int)log2((double)blkwidth) - 3; //
//			// Take blk width = 8 then divide by 4
//			int maxUnscaled = ((maxLimitSAD_k[loc] >> 2) * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SAD %d is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);
			
//			////------------------
//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//				//        // Convert YUV to RGB
//			// Without chroma parts
//			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}



//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;
      
//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);

//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}




Void TAppDecTop::saveFrameAsPNG_SADx_Only(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  // YGJ 22nd Septy 2014
  // Set width
  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;
  
  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_iSumHad;   ptrDist_iSumHad = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHad == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];  
  char strRange[8];
  char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);  
  strcat(SSIMHeatmap, "_OnlyHeatMap_");    
  strcat(SSIMHeatmap, strpoc);   
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);        
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);  
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
	//Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc


	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);
        

		bool HadRegion = false;
		Distortion iSumHad =0;

        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
		{
		  HadRegion = true;

		  //int HadDiff[blksz];
		  // http://www.cplusplus.com/forum/general/40423/
		  int* HadDiff = new int[blksz];


			for ( unsigned n = 0; n < blkwidth; n++ )
			{
				for ( unsigned m = 0; m < blkwidth; m++ )
				{
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

				}
			}

			int i, j; //, jj;//, k;

			for (i = 0; i < blkwidth; i++)
			{
			  for (j = 0; j < blkwidth; j++)
			  {
				iSumHad += abs(HadDiff[i+j*blkwidth]); // + abs(APC[i+j*8]);
			  }
			}

			//iSumHad=((iSumHad+2)>>2);

            ptrDist_iSumHad[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = iSumHad;

			delete HadDiff;

		}
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {

            iSumHad = ptrDist_iSumHad[(x >> shiftby) + (y >> 3)*(width>>shiftby)];
            HadRegion = true;
        }

		int yInt = yInt_Rec;


		int r, b, g;

		//  APC score will be between 0 and 127.
		// Dependent upon value apply different colour
		if (HadRegion == true)
		{


			//------------------

			// Using arrays as look up tables to ensure values set are consistent
			int loc = (int)log2((double)blkwidth) - 3;
			
			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));
			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
				printf("SAD %d is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n", 
				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;
			
			////------------------
			//switch (val)
			//{
			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------
		}
		else
		{
				//        // Convert YUV to RGB
			// Without chroma parts
			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}



		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;
      
	}


	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);

	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

}


Void TAppDecTop::saveFrameAsPNG_SADx_NonSq_Only(TComPic* pcPic)
{


  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);


  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blkheight = (blkwidth >> 1);
  unsigned blksz = blkwidth*blkheight;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);
  
  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);


  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);  
  strcat(SSIMHeatmap, "NonSq_OnlyHeatMap_");    
  strcat(SSIMHeatmap, strpoc);   
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);        
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);  
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		int yInt = 0; //, uInt = 0, vInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


		bool HadRegion = false;
		Distortion iSumHad =0;

		if ((y < (height-blkheight)) && (x < (width-blkwidth)))
		{
		  HadRegion = true;

		  //int HadDiff[blksz];		  		  
		  // http://www.cplusplus.com/forum/general/40423/
		  int* HadDiff = new int[blksz];



			for ( unsigned n = 0; n < blkheight; n++ )
			{
				for ( unsigned m = 0; m < blkwidth; m++ )
				{
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

				}
			}

			int i, j; //, jj;//, k;

			for (j = 0; j < blkheight; j++)
			{
			  for (i = 0; i < blkwidth; i++)
			  {
				iSumHad += abs(HadDiff[i+j*blkwidth]); // + abs(APC[i+j*8]);
			  }
			}

			delete HadDiff;

		}



		yInt = yInt_Rec;

//
		int r, b, g;

		//  APC score will be between 0 and 127.
		// Dependent upon value apply different colour
		if (HadRegion == true)
		{
			
			//------------------

			// Using arrays as look up tables to ensure values set are consistent
			int loc = (int)log2((double)blkwidth) - 3;
			
			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));
			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

			// For Non-Sq
			halfMaxThreshold >>= 1; // Half

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
				printf("SAD %d NonSq is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n", 
				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;
			
			//------------------

			//int loc2 = (int)log2((double)blkheight) - 3;

			//loc = loc > -1 ? loc : 0;
			//loc2 = loc2 > -1 ? loc2 : 0;

			//Distortion quartAssumedMax = quartMaxLimit[loc][loc2];

			//int quad = quartAssumedMax >> 2; //quadrant[loc][loc];

			//int val = int((float)iSumHad/quad); // In order to be compare SAD, SADwAPC, HAD and HADwAPC the same scales will be set for the heatmaps

			////------------------


			//if (iSumHad > (quartAssumedMax << 1))
			//    printf("SAD %d NonSq exceeded quartAssumedMax of %d, distortion is %d, will be set to %d \n", blkwidth, quartAssumedMax, iSumHad, quartAssumedMax);

			//// Cap MS-APC SATD max to 4k
			//iSumHad = iSumHad > quartAssumedMax? quartAssumedMax : iSumHad;

			//// Normalise Had against assumed max.
			//float normHad = ((float)iSumHad)/quartAssumedMax;

			//switch (val)
			//{
			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
				//        // Convert YUV to RGB
			// Without chroma parts
			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}



		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;
      
	}


	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);


	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

}



Void TAppDecTop::saveFrameAsPNG_SSEx_Only(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);

  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_SSE;   ptrDist_SSE = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SSE == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  //char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  
  strcat(SSIMHeatmap, "DecFrm_SSE");  strcat(SSIMHeatmap, strblkwidth); 
  strcat(SSIMHeatmap, "_OnlyHeatMap_");    
  strcat(SSIMHeatmap, strpoc);        
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);      
  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor); 
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		// allocate YUV value
		int yInt = 0; //, uInt = 0, vInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


		bool SSERegion = false;
		Distortion iSumHad =0;

        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
		{
		  SSERegion = true;

		  //int SSEDiff[blksz];
		  // http://www.cplusplus.com/forum/general/40423/
		  int* SSEDiff = new int[blksz];
		  
			for ( unsigned n = 0; n < blkwidth; n++ )
			{
				for ( unsigned m = 0; m < blkwidth; m++ )
				{
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					int Temp = y_Org - y_Rec;

					SSEDiff[yloc8x8] = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;

					//SSEDiff[yloc8x8] = Temp*Temp; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

				}
			}

			int i, j; //, jj;//, k;

			for (i = 0; i < blkwidth; i++)
			{
			  for (j = 0; j < blkwidth; j++)
			  {
				iSumHad += abs(SSEDiff[i+j*blkwidth]); // + abs(APC[i+j*8]);
			  }
			}

			//iSumHad=((iSumHad+2)>>2);

            ptrDist_SSE[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = iSumHad;

			delete SSEDiff;

		}
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {
            SSERegion = true;

            iSumHad = ptrDist_SSE[(x >> shiftby) + (y >> 3)*(width>>shiftby)];
        }

		yInt = yInt_Rec;



//
		int r, b, g;

		//  APC score will be between 0 and 127.
		// Dependent upon value apply different colour
		if (SSERegion == true)
		{

	

			//------------------------------
			// YGJ 28th Sept 2014 - Instead of 1/2 max, here it is 1/(2^2), 1/4 Max
			// Correction 1/16. This will reduce the dynamic range.
			// However, the banding is log scale, doubling each time (bit like Fibbannaci sequence)
			// Then the intensity is scaled lineary, within these non-linear sized bands

			int loc = (int)log2((double)blkwidth) - 3;


			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));
			//float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); // Not applicable

			Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor; 

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
				printf("SSE %d is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n", 
				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

			//switch (val)
			//{
			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
				//        // Convert YUV to RGB
			// Without chroma parts
			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}

		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;

	}


	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);


	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

}




//=========================================
//=========================================
// Proposed Methods shown as Heatmaps
//=========================================
//=========================================

// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
// YGJ 15th Sept 2014

// Added specifically to switch between Had only and Had with Integrated APC, called by xCalcHADs8x8
//static int HadAllZero16[16] = {0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0};
static int HadAllZero64[64] = {0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0};


// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
// YGJ 15th Sept 2014
// Detects the perceptual activity of a frame using the RateControl method of Hadamard.
// Here, like Rate Control, this is dependednt upon the reference video frame only, no on the reconstructed.
// Unlike in Rate Control, which assesses block by block in non overlapping manner, here, Hadamard is applied in overlapping blocks.
// Each pixel is assess based on the surrounding 8x8 pixels.
// Also like in the proposed encoder APC is integrated to the difference cost
// The score must be scaled to fit the range of of the heatmap



//Void TAppDecTop::saveFrameAsPNG_SAD4wAPC(TComPic* pcPic)
//{


//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);

//  // YGJ 22nd Septy 2014
//  // Set width
//  unsigned blkwidth = 4; //DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;
  
//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);
  
//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SAD4x");    strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "_wAPC_HeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//	//Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

////int prevCloc = 0; // Previous cloc


//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);
        

//		bool HadRegion = false;
//		Distortion iSumHad =0;

//		if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//		{
//		  HadRegion = true;

//		  //int HadDiff[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* HadDiff = new int[blksz];
//          int* APC = new int[blksz];

//			for ( unsigned n = 0; n < blkwidth; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);
//                    //HadDiff[yloc8x8] += TComRdCost::HadAPC(y_Org, y_Rec, 0);
//                    //APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

//					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

//				}
//			}

//			int i, j; //, jj;//, k;

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				//iSumHad += abs(HadDiff[i+j*blkwidth]); // + abs(APC[i+j*8]);
//                iSumHad += abs(HadDiff[i+j*blkwidth]) + abs(APC[i+j*blkwidth]);
//			  }
//			}

//			//iSumHad=((iSumHad+2)>>2);

//			delete HadDiff;
//			delete APC;

//		}



//		int yInt = yInt_Rec;


//		int r, b, g;

//		//  APC score will be between 0 and 127.
//		// Dependent upon value apply different colour
//		if (HadRegion == true)
//		{


//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = 0; //(int)log2((double)blkwidth) - 3; //
//			// Take blk width = 8 then divide by 4
//			int maxUnscaled = ((maxLimitSAD_k[loc] >> 2) * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SAD %d is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);
			
//			////------------------
//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}
//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//				//        // Convert YUV to RGB
//			// Without chroma parts
//			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}



//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;
      
//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);

//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}



//Void TAppDecTop::saveFrameAsPNG_SADx_PreAssess_Asym_Only(TComPic* pcPic)
//{
  
//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);


//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

  
//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "_PreAssess_Asym_GrThnThresh_HeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  //strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0; //, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


//		bool HadRegion = false;
//		Distortion iSumHad =0;

//		if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//		{
//		  HadRegion = true;

//		  //int HadDiff[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* HadDiff = new int[blksz];

//		  //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* APC = new int[blksz];

//			for ( unsigned n = 0; n < blkwidth; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

//				}
//			}

//			int i, j, k; //, jj;//, k;

//			int Top=0, Bottom = 0, Left =0, Right =0;

//			// Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated

//			// Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
//			for (k=1; k < (blkwidth-1); k++) {Top += abs(APC[k]);} // Top Row
//			for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(APC[k]);} // Bottom Row
//			for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(APC[k]);} // Left Column
//			for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(APC[k]);} // Right Column

//			UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            //if (AbsAsymCost > 28)
//            //{
//            //    //================================================
//            //    //Log Threshold by CU and Frame number

//            //    //    ofstream CalcValues;

//            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//            //     ofstream ThreshLog;
//            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_SADx_with_APC.txt", ios::out | ios::app);
//            //
//            //     UInt MaxCUx = width >> 6;
//            //     UInt MaxCUy = height >> 6;
//            //     UInt CUx = x >> 6;
//            //     UInt CUy = y >> 6;

//            //     ThreshLog << poc << " ," << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//            //     ThreshLog.close();

//            //    //================================================
//            //}

//			// YGJ 26th Sept 2014
//			// Initially Threshold was 64, but this did not hold sufficient APC features.
//			// Then through testing 16 was seen as the universal threshold suitable for all block sizes.
//			// When investigating the raw sampled data via R, the threshold of 16 affected 60% of 30k observed samples.
//			// Using linear algebra 27.2 is the half-way point, however 28 is more computer friendly version.
//			// Comparing the decoder heatmaps outputs of 16 vs 28, 28 seems sufficient.
//			// Hence, a threshold of 28 is able to detect a majority of the APC "features" for the least amount of observed samples.
//			//UInt Threshold = 28;
//			UInt ThresholdMin = 28;
//            UInt ThresholdMax = 128;

//			bool ProceedwAPC = AbsAsymCost > ThresholdMin && AbsAsymCost < ThresholdMax ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//            //// This is about registering the asymmetry cost if greater than threshold, in order to see what it effects
//            //HadRegion = AbsAsymCost > Threshold ? true : false;

//            //iSumHad = AbsAsymCost; // > Threshold ? AbsAsymCost : 0;

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				 switch (ProceedwAPC)
//				 {
//				 case false : iSumHad += abs(HadDiff[i+j*blkwidth]);
//					 break;

//				 case true : iSumHad += abs(HadDiff[i+j*blkwidth]) + abs(APC[i+j*blkwidth]);
//					 break;
//				 }

//			  }
//			}

//			delete HadDiff;
//			delete APC;
//		}

//		yInt = yInt_Rec;

//		int r, b, g;

//		//  APC score will be between 0 and 127.
//		// Dependent upon value apply different colour
//		if (HadRegion == true)
//		{
//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("PreAssess SAD %d with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);
			
//			//------------------

//            //float normHad = (float)iSumHad/750;

//            //int val = (int)((float)iSumHad/200);


//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//				//        // Convert YUV to RGB
//			// Without chroma parts
//			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}

//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}




//Void TAppDecTop::saveFrameAsPNG_SADx_PreAssessSAD_APC(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);


//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);


//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "_SADPreAssess_APCHeatMap_");
//  //strcat(SSIMHeatmap, "_PreAssess_APCHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0; //, uInt = 0, vInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


//        //bool HadRegion = false;
//        Distortion iSumHad =0;
//        Distortion iSumHadAPC =0;
//        bool ProceedwAPC = false;

//        if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//        {
//          //HadRegion = true;

//          //int HadDiff[blksz];
//          // http://www.cplusplus.com/forum/general/40423/
//          int* HadDiff = new int[blksz];

//          //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//          // http://www.cplusplus.com/forum/general/40423/
//          int* APC = new int[blksz];

//            for ( unsigned n = 0; n < blkwidth; n++ )
//            {
//                for ( unsigned m = 0; m < blkwidth; m++ )
//                {
//                    // y*width + x
//                    unsigned yloc8x8 = n*blkwidth+m;

//                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//                    ////------------------
//                    //// YGJ 12th July 2014
//                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
//                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//                    //// a -- set up and initialise variables

//                    ////------------------

//                    HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//                    APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

//                }
//            }

//            int i, j, k; //, jj;//, k;

//            int Top=0, Bottom = 0, Left =0, Right =0;

//            // Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated

////			// Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
////			for (k=1; k < (blkwidth-1); k++) {Top += abs(APC[k]);} // Top Row
////			for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(APC[k]);} // Bottom Row
////			for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(APC[k]);} // Left Column
////			for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(APC[k]);} // Right Column


//            // YGJ 25th Nov 2014 - Try SAD not APC px scores for AbsAsymCost
//            // Note : --- File name has been changed to say ---> SADPreAssess_
//            // And Theshold changed to SAD version!!!
//            // Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
//            for (k=1; k < (blkwidth-1); k++) {Top += abs(HadDiff[k]);} // Top Row
//            for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(HadDiff[k]);} // Bottom Row
//            for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(HadDiff[k]);} // Left Column
//            for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(HadDiff[k]);} // Right Column

//            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            //if (AbsAsymCost > 28)
//            //{
//            //    //================================================
//            //    //Log Threshold by CU and Frame number

//            //    //    ofstream CalcValues;

//            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//            //     ofstream ThreshLog;
//            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_SADx_with_APC.txt", ios::out | ios::app);
//            //
//            //     UInt MaxCUx = width >> 6;
//            //     UInt MaxCUy = height >> 6;
//            //     UInt CUx = x >> 6;
//            //     UInt CUy = y >> 6;

//            //     ThreshLog << poc << " ," << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//            //     ThreshLog.close();

//            //    //================================================
//            //}

//            // YGJ 26th Sept 2014
//            // Initially Threshold was 64, but this did not hold sufficient APC features.
//            // Then through testing 16 was seen as the universal threshold suitable for all block sizes.
//            // When investigating the raw sampled data via R, the threshold of 16 affected 60% of 30k observed samples.
//            // Using linear algebra 27.2 is the half-way point, however 28 is more computer friendly version.
//            // Comparing the decoder heatmaps outputs of 16 vs 28, 28 seems sufficient.
//            // Hence, a threshold of 28 is able to detect a majority of the APC "features" for the least amount of observed samples.


//            // Sun 23rd Nov 2014
//            // Having analysed log calculated values the median value for AbsAsymCost was 4 for SAD with APC.
//            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//            // Over 48 million observations were logged, which represented 8.7 million unique records.
//            // This is significantly lower than previous as they were based on decoded reconstructed frame or upon logged from a partially encoded Intra frame.
//            // Expect more samples will be affected than previous and that the processing time will increase accordingly.
//            //UInt Threshold = TComRdCost::getMinThreshold(); //  28;

//            // SAD median used 26 opposed to 32 for APC
//            //UInt Threshold = 26; //TComRdCost::getMinThreshold(); //  28;
//            // Since SAD PreAssess can have values twice as large as APC version. Threshold should be doubled.
//            UInt Threshold = blkwidth == 8? 32 : blkwidth == 16? 64 : blkwidth == 32? 128 : 256; //TComRdCost::getMinThreshold(); //  28;
//            Threshold >>=1;

//            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//            for (i = 0; i < blkwidth; i++)
//            {
//              for (j = 0; j < blkwidth; j++)
//              {
//                 switch (ProceedwAPC)
//                 {
//                 case false : iSumHad += abs(HadDiff[i+j*blkwidth]);
//                     break;

//                 case true :  // Decouple SAD and APCj
//                     iSumHad += abs(HadDiff[i+j*blkwidth]);
//                     iSumHadAPC += abs(APC[i+j*blkwidth]);
//                     break;
//                 }

//              }
//            }

//            delete HadDiff;
//            delete APC;
//        }

//        yInt = yInt_Rec;

//        int r, b, g;

//        //  APC score will be between 0 and 127.
//        // Dependent upon value apply different colour
//        //if (HadRegion == true)
//        if (ProceedwAPC == true)
//        {
//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = (int)log2((double)blkwidth) - 3;

//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//            // Divide APC cost by 1/2 Blk size before adding to Had cost

//            // Divide APC cost by 1/4 Blk size before adding to SAD cost
//            //iSumHadAPC = iSumHadAPC/(blksz >> 2);
//            //iSumHadAPC = iSumHadAPC/((blkwidth + blkwidth) >> 0);
//            //iSumHadAPC = iSumHadAPC/(blkwidth + blkwidth) ;
//            iSumHadAPC = iSumHadAPC >> 4 ; // fixed scale for APC

//            iSumHad += iSumHadAPC;
//            //iSumHad = iSumHadAPC;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////            int val = dist < (halfMaxThreshold >> 2) ? 0
////                : dist < (halfMaxThreshold >> 1) ? 1
////                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("PreAssess SAD %d with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);

//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;

//            //------------------


//            //switch (val)
//            //{
//            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//            //		break;
//            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//            //		break;
//            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //}

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//                //        // Convert YUV to RGB
//            // Without chroma parts
//            r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//            g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//            b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//        // Partitioning -- Not Working
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0; //yInt_RmO;
//          g = 0; //yInt_RmO;
//          b = 0; //yInt_RmO;
//        }

//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      //piY += YStride;
//      piY_Org += YStride;
//      piY_Rec += YStrideRec;
//      piY_Part += YStrideRec;


//    }


//    free(ptrY_Org8x8);
//    free(ptrY_Rec8x8);

//    free(ptrY_Org);

//    free(ptrY_Rec);

//    free(ptrY_Part);


//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//}





//Void TAppDecTop::saveFrameAsPNG_SADx_PreAssess_APC(TComPic* pcPic)
//{
  
//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);


//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  
//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
//  //strcat(SSIMHeatmap, "_SADPreAssess_APCHeatMap_");
//  strcat(SSIMHeatmap, "_PreAssess_APCHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0; //, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


//        //bool HadRegion = false;
//		Distortion iSumHad =0;
//        Distortion iSumHadAPC =0;
//        bool ProceedwAPC = false;

//		if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//		{
//          //HadRegion = true;

//		  //int HadDiff[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* HadDiff = new int[blksz];

//		  //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* APC = new int[blksz];

//			for ( unsigned n = 0; n < blkwidth; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

//				}
//			}

//			int i, j, k; //, jj;//, k;

//			int Top=0, Bottom = 0, Left =0, Right =0;

//			// Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated

//            // Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
//            for (k=1; k < (blkwidth-1); k++) {Top += abs(APC[k]);} // Top Row
//            for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(APC[k]);} // Bottom Row
//            for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(APC[k]);} // Left Column
//            for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(APC[k]);} // Right Column


////            // YGJ 25th Nov 2014 - Try SAD not APC px scores for AbsAsymCost
////            // Note : --- File name has been changed to say ---> SADPreAssess_
////            // And Theshold changed to SAD version!!!
////            // Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
////            for (k=1; k < (blkwidth-1); k++) {Top += abs(HadDiff[k]);} // Top Row
////            for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(HadDiff[k]);} // Bottom Row
////            for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(HadDiff[k]);} // Left Column
////            for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(HadDiff[k]);} // Right Column

//			UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            //if (AbsAsymCost > 28)
//            //{
//            //    //================================================
//            //    //Log Threshold by CU and Frame number

//            //    //    ofstream CalcValues;

//            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//            //     ofstream ThreshLog;
//            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_SADx_with_APC.txt", ios::out | ios::app);
//            //
//            //     UInt MaxCUx = width >> 6;
//            //     UInt MaxCUy = height >> 6;
//            //     UInt CUx = x >> 6;
//            //     UInt CUy = y >> 6;

//            //     ThreshLog << poc << " ," << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//            //     ThreshLog.close();

//            //    //================================================
//            //}

//			// YGJ 26th Sept 2014
//			// Initially Threshold was 64, but this did not hold sufficient APC features.
//			// Then through testing 16 was seen as the universal threshold suitable for all block sizes.
//			// When investigating the raw sampled data via R, the threshold of 16 affected 60% of 30k observed samples.
//			// Using linear algebra 27.2 is the half-way point, however 28 is more computer friendly version.
//			// Comparing the decoder heatmaps outputs of 16 vs 28, 28 seems sufficient.
//			// Hence, a threshold of 28 is able to detect a majority of the APC "features" for the least amount of observed samples.


//            // Sun 23rd Nov 2014
//            // Having analysed log calculated values the median value for AbsAsymCost was 4 for SAD with APC.
//            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//            // Over 48 million observations were logged, which represented 8.7 million unique records.
//            // This is significantly lower than previous as they were based on decoded reconstructed frame or upon logged from a partially encoded Intra frame.
//            // Expect more samples will be affected than previous and that the processing time will increase accordingly.
//            //UInt Threshold = TComRdCost::getMinThreshold(); //  28;

//            // SAD median used 26 opposed to 32 for APC
//            UInt Threshold = blkwidth == 8? 32 : blkwidth == 16? 64 : blkwidth == 32? 128 : 256; //TComRdCost::getMinThreshold(); //  28;

//            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				 switch (ProceedwAPC)
//				 {
//				 case false : iSumHad += abs(HadDiff[i+j*blkwidth]);
//					 break;

//                 case true :  // Decouple SAD and APCj
//                     iSumHad += abs(HadDiff[i+j*blkwidth]);
//                     iSumHadAPC += abs(APC[i+j*blkwidth]);
//                     break;
//				 }

//			  }
//			}

//			delete HadDiff;
//			delete APC;
//		}

//		yInt = yInt_Rec;

//		int r, b, g;

//		//  APC score will be between 0 and 127.
//		// Dependent upon value apply different colour
//        //if (HadRegion == true)
//        if (ProceedwAPC == true)
//		{
//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//            // Divide APC cost by 1/2 Blk size before adding to Had cost

//            // Divide APC cost by 1/4 Blk size before adding to SAD cost
//            //iSumHadAPC = iSumHadAPC/(blksz >> 2);
//            //iSumHadAPC = iSumHadAPC/((blkwidth + blkwidth) >> 0);
//            //iSumHadAPC = iSumHadAPC/(blkwidth + blkwidth) ;
//            iSumHadAPC = iSumHadAPC >> 4 ; // fixed scale for APC

//            iSumHad += iSumHadAPC;
//            //iSumHad = iSumHadAPC;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////			int val = dist < (halfMaxThreshold >> 2) ? 0
////				: dist < (halfMaxThreshold >> 1) ? 1
////				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("PreAssess SAD %d with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);
			
//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;

//			//------------------


//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//				//        // Convert YUV to RGB
//			// Without chroma parts
//			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}

//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}



Void TAppDecTop::saveFrameAsPNG_SADx_PreAssess_wCornerTest_APC(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);


  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_iSumHad;   ptrDist_iSumHad = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHad == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_iSumHadAPC;   ptrDist_iSumHadAPC = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_iSumHadAPC == NULL)   printf("calloc failed\n");
    bool *ptrbool_ProceedwAPC;   ptrbool_ProceedwAPC = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_ProceedwAPC == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);


  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
  //strcat(SSIMHeatmap, "_SADPreAssess_APCHeatMap_");
  strcat(SSIMHeatmap, "_PreAssess_wCornerTest_APCHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


        //bool HadRegion = false;
        Distortion iSumHad =0;
        Distortion iSumHadAPC =0;
        bool ProceedwAPC = false;

        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
        {
          //HadRegion = true;

          //int HadDiff[blksz];
          // http://www.cplusplus.com/forum/general/40423/
          int* HadDiff = new int[blksz];

          //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
          // http://www.cplusplus.com/forum/general/40423/
          int* APC = new int[blksz];

            for ( unsigned n = 0; n < blkwidth; n++ )
            {
                for ( unsigned m = 0; m < blkwidth; m++ )
                {
                    // y*width + x
                    unsigned yloc8x8 = n*blkwidth+m;

                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                    ////------------------
                    //// YGJ 12th July 2014
                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                    //// a -- set up and initialise variables

                    ////------------------

                    HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
                    APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

                }
            }

            int i, j, k; //, jj;//, k;

            int Top=0, Bottom = 0, Left =0, Right =0;

            // Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated

            // Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
            for (k=1; k < (blkwidth-1); k++) {Top += abs(APC[k]);} // Top Row
            for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(APC[k]);} // Bottom Row
            for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(APC[k]);} // Left Column
            for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(APC[k]);} // Right Column


//            // YGJ 25th Nov 2014 - Try SAD not APC px scores for AbsAsymCost
//            // Note : --- File name has been changed to say ---> SADPreAssess_
//            // And Theshold changed to SAD version!!!
//            // Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
//            for (k=1; k < (blkwidth-1); k++) {Top += abs(HadDiff[k]);} // Top Row
//            for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(HadDiff[k]);} // Bottom Row
//            for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(HadDiff[k]);} // Left Column
//            for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(HadDiff[k]);} // Right Column

            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

            //if (AbsAsymCost > 28)
            //{
            //    //================================================
            //    //Log Threshold by CU and Frame number

            //    //    ofstream CalcValues;

            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

            //     ofstream ThreshLog;
            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_SADx_with_APC.txt", ios::out | ios::app);
            //
            //     UInt MaxCUx = width >> 6;
            //     UInt MaxCUy = height >> 6;
            //     UInt CUx = x >> 6;
            //     UInt CUy = y >> 6;

            //     ThreshLog << poc << " ," << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

            //     ThreshLog.close();

            //    //================================================
            //}

            // YGJ 26th Sept 2014
            // Initially Threshold was 64, but this did not hold sufficient APC features.
            // Then through testing 16 was seen as the universal threshold suitable for all block sizes.
            // When investigating the raw sampled data via R, the threshold of 16 affected 60% of 30k observed samples.
            // Using linear algebra 27.2 is the half-way point, however 28 is more computer friendly version.
            // Comparing the decoder heatmaps outputs of 16 vs 28, 28 seems sufficient.
            // Hence, a threshold of 28 is able to detect a majority of the APC "features" for the least amount of observed samples.


            // Sun 23rd Nov 2014
            // Having analysed log calculated values the median value for AbsAsymCost was 4 for SAD with APC.
            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
            // Over 48 million observations were logged, which represented 8.7 million unique records.
            // This is significantly lower than previous as they were based on decoded reconstructed frame or upon logged from a partially encoded Intra frame.
            // Expect more samples will be affected than previous and that the processing time will increase accordingly.
            //UInt Threshold = TComRdCost::getMinThreshold(); //  28;

            // SAD median used 26 opposed to 32 for APC
            UInt Threshold = blkwidth == 8? 32 : blkwidth == 16? 64 : blkwidth == 32? 128 : 256; //TComRdCost::getMinThreshold(); //  28;

            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

            // Corner Test
            switch(ProceedwAPC)
            {
            case true:
                    {
                      // YGJ 3rd Dec 2014
                      // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
                      // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
                      // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
                      // Modelling showed that corner test should occur after thresholding, not before or alone.
                      // This approach is the most effective at shifting and broadening the peak in Had away from zero.
                      // From 30k sampled observations, 7k were affected, approx 23%.
                      // In R threshold was 32, divide was done by 6 and count min was >1.
                      // Here it is the same except that divide is 8.
                      // When modelled

                      UInt Downscale = blkwidth == 8? 3 : blkwidth == 16? 4 : blkwidth == 32? 5 : 6;

                      int count = 0;
                      count +=  ((abs(APC[0]) << 1) - ((abs(Top) +  abs(Left)) >> Downscale)) > 0 ? 1 : 0;
                      count +=  ((abs(APC[7]) << 1) - ((abs(Top) +  abs(Right)) >> Downscale)) > 0 ? 1 : 0;
                      count +=  ((abs(APC[56]) << 1) - ((abs(Bottom) +  abs(Left)) >> Downscale)) > 0 ? 1 : 0;
                      count +=  ((abs(APC[63]) << 1) - ((abs(Bottom) +  abs(Right)) >> Downscale)) > 0 ? 1 : 0;

                      ProceedwAPC = count > 1? true: false;

                    }

            //case false: // leave as false

            }

            for (i = 0; i < blkwidth; i++)
            {
              for (j = 0; j < blkwidth; j++)
              {
                 switch (ProceedwAPC)
                 {
                 case false : iSumHad += abs(HadDiff[i+j*blkwidth]);
                     break;

                 case true :  // Decouple SAD and APCj
                     iSumHad += abs(HadDiff[i+j*blkwidth]);
                     iSumHadAPC += abs(APC[i+j*blkwidth]);
                     break;
                 }

              }
            }


            ptrDist_iSumHad[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = iSumHad;
            ptrDist_iSumHadAPC[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = iSumHadAPC;
            ptrbool_ProceedwAPC[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = ProceedwAPC;

            delete HadDiff;
            delete APC;
        }
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {

            iSumHad = ptrDist_iSumHad[(x >> shiftby) + (y >> 3)*(width>>shiftby)];
            iSumHadAPC = ptrDist_iSumHadAPC[(x >> shiftby) + (y >> 3)*(width>>shiftby)];
            ProceedwAPC = ptrbool_ProceedwAPC[(x >> shiftby) + (y >> 3)*(width>>shiftby)];

        }

        yInt = yInt_Rec;

        int r, b, g;

        //  APC score will be between 0 and 127.
        // Dependent upon value apply different colour
        //if (HadRegion == true)
        if (ProceedwAPC == true)
        {
            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            // Divide APC cost by 1/2 Blk size before adding to Had cost

            // Divide APC cost by 1/4 Blk size before adding to SAD cost
            //iSumHadAPC = iSumHadAPC/(blksz >> 2);
            //iSumHadAPC = iSumHadAPC/((blkwidth + blkwidth) >> 0);
            //iSumHadAPC = iSumHadAPC/(blkwidth + blkwidth) ;
            iSumHadAPC = iSumHadAPC >> 4 ; // fixed scale for APC

            iSumHad += iSumHadAPC;
            //iSumHad = iSumHadAPC;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//            int val = dist < (halfMaxThreshold >> 2) ? 0
//                : dist < (halfMaxThreshold >> 1) ? 1
//                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("PreAssess SAD %d with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
                blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

            //------------------


            //switch (val)
            //{
            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
            //		break;
            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
            //		break;
            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //}

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
                //        // Convert YUV to RGB
            // Without chroma parts
            r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
            g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
            b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }

        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;


    }


    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}




//Void TAppDecTop::saveFrameAsPNG_SADx_NonSq_PreAssess_APC(TComPic* pcPic)
//{
  
//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);


//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blkheight = (blkwidth >> 1);
//  unsigned blksz = blkwidth*blkheight;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "NonSq_PreAssess_APCHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0; //, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


////		bool HadRegion = false;
//		Distortion iSumHad =0;
//        Distortion iSumHadAPC =0;
//        bool ProceedwAPC = false;

//		if ((y < (height-blkheight)) && (x < (width-blkwidth)))
//		{
//          //HadRegion = true;

//		  //int HadDiff[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* HadDiff = new int[blksz];


//		  //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* APC = new int[blksz];

//		  //Int OrgPx[64], RecPx[64];


//			for ( unsigned n = 0; n < blkheight; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);
//					APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

//				}
//			}

//			int i, j, k; //, jj;//, k;

//			int Top=0, Bottom = 0, Left =0, Right =0;

//			// Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated

//			// Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
//			for (k=1; k < (blkwidth-1); k++) {Top += abs(APC[k]);} // Top Row
//			for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(APC[k]);} // Bottom Row
//			for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(APC[k]);} // Left Column
//			for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(APC[k]);} // Right Column

//			UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//            //if (AbsAsymCost > 28)
//            //{
//            //    //================================================
//            //    //Log Threshold by CU and Frame number

//            //    //    ofstream CalcValues;

//            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//            //     ofstream ThreshLog;
//            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_SAD_NonSq_with_APC.txt", ios::out | ios::app);
//            //
//            //     UInt MaxCUx = width >> 6;
//            //     UInt MaxCUy = height >> 6;
//            //     UInt CUx = x >> 6;
//            //     UInt CUy = y >> 6;

//            //     ThreshLog << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//            //     ThreshLog.close();

//            //    //================================================
//            //}

//            // Sun 23rd Nov 2014
//            // Having analysed log calculated values the median value for AbsAsymCost was 4 for SAD with APC.
//            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//            // Over 48 million observations were logged, which represented 8.7 million unique records.
//            // This is significantly lower than previous as they were based on decoded reconstructed frame or upon logged from a partially encoded Intra frame.
//            // Expect more samples will be affected than previous and that the processing time will increase accordingly.
//            UInt Threshold = TComRdCost::getMinThreshold(); //  28;
//            //UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?

//            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained



//			for (j = 0; j < blkheight; j++)
//			{
//			  for (i = 0; i < blkwidth; i++)
//			  {
//				 switch (ProceedwAPC)
//				 {
//				 case false : iSumHad += abs(HadDiff[i+j*blkwidth]);
//					 break;

//                 case true : // Decouple SAD and APC
//                     iSumHad += abs(HadDiff[i+j*blkwidth]);
//                     iSumHadAPC += abs(APC[i+j*blkwidth]);
//					 break;
//				 }

//			  }
//			}

//			delete HadDiff;
//			delete APC;
//		}

//		yInt = yInt_Rec;

//		//--------------

////
//		int r, b, g;

//		//  APC score will be between 0 and 127.
//		// Dependent upon value apply different colour
//        //if (HadRegion == true)
//        if (ProceedwAPC == true)
//		{


//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;
			
//			// For Non-Sq
//			halfMaxThreshold >>= 1; // Half

//            // Divide APC cost by 1/2 Blk size before adding to Had cost

//            // Divide APC cost by 1/4 Blk size before adding to SAD cost
//            //iSumHadAPC = iSumHadAPC/(blksz >> 2);
//            //iSumHadAPC = iSumHadAPC/((blkheight + blkwidth) >> 2);
//            iSumHadAPC = iSumHadAPC/(blkheight + blkwidth) ;

//            iSumHad += iSumHadAPC;
//            //iSumHad = iSumHadAPC;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////			int val = dist < (halfMaxThreshold >> 2) ? 0
////				: dist < (halfMaxThreshold >> 1) ? 1
////				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("Pre Assess SAD %d NonSq with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;
			
//			//------------------


//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//				//        // Convert YUV to RGB
//			// Without chroma parts
//			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}



//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;

//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}



Void TAppDecTop::saveFrameAsPNG_SADx_NonSq_PreAssess_wCornerTest_APC(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);


  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blkheight = (blkwidth >> 1);
  unsigned blksz = blkwidth*blkheight;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  strcat(SSIMHeatmap, "DecFrm_SAD");    strcat(SSIMHeatmap, strblkwidth);
  strcat(SSIMHeatmap, "NonSq_PreAssess_wCornerTest_APCHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


//		bool HadRegion = false;
        Distortion iSumHad =0;
        Distortion iSumHadAPC =0;
        bool ProceedwAPC = false;

        if ((y < (height-blkheight)) && (x < (width-blkwidth)))
        {
          //HadRegion = true;

          //int HadDiff[blksz];
          // http://www.cplusplus.com/forum/general/40423/
          int* HadDiff = new int[blksz];


          //Int APC[blksz]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
          // http://www.cplusplus.com/forum/general/40423/
          int* APC = new int[blksz];

          //Int OrgPx[64], RecPx[64];


            for ( unsigned n = 0; n < blkheight; n++ )
            {
                for ( unsigned m = 0; m < blkwidth; m++ )
                {
                    // y*width + x
                    unsigned yloc8x8 = n*blkwidth+m;

                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                    ////------------------
                    //// YGJ 12th July 2014
                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                    //// a -- set up and initialise variables

                    ////------------------

                    HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
                    //APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);
                    APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0);

                }
            }

            int i, j, k; //, jj;//, k;

            int Top=0, Bottom = 0, Left =0, Right =0;

            // Use loops to recreate accumulation of APC on edges to judge if SAD or SAD with APC is calculated

            // Edges minus corners (0, 7, 56, 63) (0, blkwidth-1, blksz-blkwidth, blksz-1)
            for (k=1; k < (blkwidth-1); k++) {Top += abs(APC[k]);} // Top Row
            for (k=(blksz-blkwidth+1); k < (blksz-1); k++) {Bottom += abs(APC[k]);} // Bottom Row
            for (k=blksz; k < (blksz-blkwidth); k+=blkwidth) {Left += abs(APC[k]);} // Left Column
            for (k=((blkwidth << 1) -1); k < (blksz-1); k+=blkwidth) {Right += abs(APC[k]);} // Right Column

            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

            //if (AbsAsymCost > 28)
            //{
            //    //================================================
            //    //Log Threshold by CU and Frame number

            //    //    ofstream CalcValues;

            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

            //     ofstream ThreshLog;
            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_SAD_NonSq_with_APC.txt", ios::out | ios::app);
            //
            //     UInt MaxCUx = width >> 6;
            //     UInt MaxCUy = height >> 6;
            //     UInt CUx = x >> 6;
            //     UInt CUy = y >> 6;

            //     ThreshLog << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

            //     ThreshLog.close();

            //    //================================================
            //}

            // Sun 23rd Nov 2014
            // Having analysed log calculated values the median value for AbsAsymCost was 4 for SAD with APC.
            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
            // Over 48 million observations were logged, which represented 8.7 million unique records.
            // This is significantly lower than previous as they were based on decoded reconstructed frame or upon logged from a partially encoded Intra frame.
            // Expect more samples will be affected than previous and that the processing time will increase accordingly.
            UInt Threshold = TComRdCost::getMinThreshold(); //  28;
            //UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?

            ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

            // Corner Test
            switch(ProceedwAPC)
            {
            case true:
                    {
                      // YGJ 3rd Dec 2014
                      // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
                      // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
                      // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
                      // Modelling showed that corner test should occur after thresholding, not before or alone.
                      // This approach is the most effective at shifting and broadening the peak in Had away from zero.
                      // From 30k sampled observations, 7k were affected, approx 23%.
                      // In R threshold was 32, divide was done by 6 and count min was >1.
                      // Here it is the same except that divide is 8.
                      // When modelled

                      UInt DownscaleWidth = blkwidth == 8? 3 : blkwidth == 16? 4 : blkwidth == 32? 5 : 6;
                      UInt DownscaleHeight = blkheight == 4? 2 : blkheight == 8? 3 : blkheight == 16? 4 : blkheight == 32? 5 : 6;

                      int count = 0;
                      count +=  ((abs(APC[0]) << 1) - ((abs(Top) >> DownscaleWidth) +  (abs(Left) >> DownscaleHeight))) > 0 ? 1 : 0;
                      count +=  ((abs(APC[7]) << 1) - ((abs(Top) >> DownscaleWidth) +  (abs(Right) >> DownscaleHeight))) > 0 ? 1 : 0;
                      count +=  ((abs(APC[56]) << 1) - ((abs(Bottom) >> DownscaleWidth) +  (abs(Left) >> DownscaleHeight))) > 0 ? 1 : 0;
                      count +=  ((abs(APC[63]) << 1) - ((abs(Bottom) >> DownscaleWidth) +  (abs(Right) >> DownscaleHeight))) > 0 ? 1 : 0;

                      ProceedwAPC = count > 1? true: false;

                    }

            //case false: // leave as false

            }

            for (j = 0; j < blkheight; j++)
            {
              for (i = 0; i < blkwidth; i++)
              {
                 switch (ProceedwAPC)
                 {
                 case false : iSumHad += abs(HadDiff[i+j*blkwidth]);
                     break;

                 case true : // Decouple SAD and APC
                     iSumHad += abs(HadDiff[i+j*blkwidth]);
                     iSumHadAPC += abs(APC[i+j*blkwidth]);
                     break;
                 }

              }
            }

            delete HadDiff;
            delete APC;
        }

        yInt = yInt_Rec;

        //--------------

//
        int r, b, g;

        //  APC score will be between 0 and 127.
        // Dependent upon value apply different colour
        //if (HadRegion == true)
        if (ProceedwAPC == true)
        {


            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            // For Non-Sq
            halfMaxThreshold >>= 1; // Half

            // Divide APC cost by 1/2 Blk size before adding to Had cost

            // Divide APC cost by 1/4 Blk size before adding to SAD cost
            //iSumHadAPC = iSumHadAPC/(blksz >> 2);
            //iSumHadAPC = iSumHadAPC/((blkheight + blkwidth) >> 2);
            iSumHadAPC = iSumHadAPC/(blkheight + blkwidth) ;

            iSumHad += iSumHadAPC;
            //iSumHad = iSumHadAPC;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//            int val = dist < (halfMaxThreshold >> 2) ? 0
//                : dist < (halfMaxThreshold >> 1) ? 1
//                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("Pre Assess SAD %d NonSq with APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
                blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

            //------------------


            //switch (val)
            //{
            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
            //		break;
            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
            //		break;
            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //}

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
                //        // Convert YUV to RGB
            // Without chroma parts
            r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
            g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
            b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}



//Void TAppDecTop::saveFrameAsPNG_SSEx_wSASD(TComPic* pcPic)
//{


//  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
//  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
//  unsigned FrameRes = (height*width);
  
//  unsigned blkwidth = DistWidthSize(m_distWidthSize);
//  unsigned blksz = blkwidth*blkwidth;

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
////  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char strblkwidth[6];
//  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

//  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_SSE");
//  strcat(SSIMHeatmap, strblkwidth);
//  strcat(SSIMHeatmap, "wSASD_HeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0;//, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


//        //bool SSERegion = false;
//		Distortion iSumHad =0;
//		Distortion iSumSSE =0;
//		Distortion iSumSASD =0;
//        bool SASD_Grth_Threshold = false;

//		if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
//		{
//          //SSERegion = true;


//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* SSEDiff = new int[blksz];
//		  // http://www.cplusplus.com/forum/general/40423/
//		  int* SASDDiff = new int[blksz];

//			for ( unsigned n = 0; n < blkwidth; n++ )
//			{
//				for ( unsigned m = 0; m < blkwidth; m++ )
//				{
//					// y*width + x
//					unsigned yloc8x8 = n*blkwidth+m;

//					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------

//					int Temp = y_Org - y_Rec;
//					int TempSq = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;

//					SSEDiff[yloc8x8] = TempSq;

////                    int OrgSq = y_Org*y_Org;
////                    int RecSq= y_Rec*y_Rec;

//					int OrgSq = shift == 0? LumaSq_LUT[y_Org] : y_Org*y_Org;
//					int RecSq=  shift == 0? LumaSq_LUT[y_Rec] : y_Rec*y_Rec;

//					//SASDDiff[yloc8x8] = abs(OrgSq-RecSq) - TempSq; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					SASDDiff[yloc8x8] = abs(abs(OrgSq-RecSq) - TempSq);
//					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

//					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

//				}
//			}

//			int i, j; //, jj;//, k;

//			for (i = 0; i < blkwidth; i++)
//			{
//			  for (j = 0; j < blkwidth; j++)
//			  {
//				iSumSSE += abs(SSEDiff[i+j*blkwidth]);
//				iSumSASD += abs(SASDDiff[i+j*blkwidth]);
//			  }
//			}

//            //iSumSASD >>=5;

//            // YGJ 23rd Nov 2014 - Down scale then upscale.
//            // First downscale by 7 to match LUT version, then upscale by blk specific size
//            // LUT is similar to calc version of SASD minor rounding errors
//            //iSumSASD >>=7;
//            iSumSASD >>=8;

//            // YGJ 24th Nov 2014 - Looking various block sizes for SSE the scaling need not increase.
//            // Leave it at 2, double.
//            //iSumSASD <<=1;

////            switch(blkwidth)
////            {
//////                case 4: iSumSASD <<=3; break;
//////                case 8: iSumSASD <<=5; break;
//////                case 16: iSumSASD <<=7; break;
//////                case 32: iSumSASD <<=9; break;
//////                case 64: iSumSASD <<=11; break;

//////                // Rather than scale up by 1/2 Block size, scale up by 1/2 block width
//////                case 4: iSumSASD <<=1; break;
//////                case 8: iSumSASD <<=2; break;
//////                case 16: iSumSASD <<=3; break;
//////                case 32: iSumSASD <<=4; break;
//////                case 64: iSumSASD <<=5; break;


//////            // Rather than scale up by 1/2 Block size, scale up by 1/2 block width
//////            case 4: iSumSASD <<=1; break;
//////            case 8: iSumSASD <<=1; break;
//////            case 16: iSumSASD <<=2; break;
//////            case 32: iSumSASD <<=4; break;
//////            case 64: iSumSASD <<=5; break;


////            }


//			//int threshold = 32;
//            // threshold is half max area for given block area

//            // YGJ 23rd Nov 2014 - Based upon 5/4 * Blocksize or 1.25*Blksize
//            int threshold = LumaSq_LUT[blkwidth] + (LumaSq_LUT[blkwidth] >> 2);

//            SASD_Grth_Threshold = iSumSASD > threshold? true : false ;


//			//iSumHad = iSumSASD > threshold? iSumSASD < (iSumSSE >> 2)? (iSumSASD + iSumSSE) : iSumSSE : iSumSSE; // No fun

//            //Prev: This below
//            //iSumHad = iSumSASD > threshold? (iSumSASD + iSumSSE) : iSumSSE ;

//            //iSumHad = (iSumSASD + iSumSSE); // works with iSumSASD >>=4;
			
//			delete SSEDiff;
//			delete SASDDiff;
//		}



//		yInt = yInt_Rec;

//        int r, b, g;

//        //  APC score will be between 0 and 127.
//        // Dependent upon value apply different colour
//        //if (SSERegion == true)
//        if (SASD_Grth_Threshold == true)
//        {

//            //iSumHad = iSumSASD > threshold? (iSumSASD + iSumSSE) : iSumSSE ;
//            iSumHad = iSumSSE + iSumSASD;

//			//------------------------------

//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			//float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); // Not applicable

//			Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////			int val = dist < (halfMaxThreshold >> 2) ? 0
////				: dist < (halfMaxThreshold >> 1) ? 1
////				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("SSE %d wSASD is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;
			

//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}
//			////------------------

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//		else
//		{
//				//        // Convert YUV to RGB
//			// Without chroma parts
//			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
//		}


//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}



//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;

//	}

//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);

//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}


Void TAppDecTop::saveFrameAsPNG_SSEx_wSASD_wEdgeDetect(TComPic* pcPic)
{


  unsigned height = m_iSourceHeight; // m_pcPicYuvOrg->getHeight(COMPONENT_Y);
  unsigned width = m_iSourceWidth; // m_pcPicYuvOrg->getWidth(COMPONENT_Y);
  unsigned FrameRes = (height*width);
  
  unsigned blkwidth = DistWidthSize(m_distWidthSize);
  unsigned blksz = blkwidth*blkwidth;

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(blksz, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    int shiftby = (int)log2(blkwidth);
    int downscaleby = (int)log2(blksz);

    Distortion *ptrDist_SSE;   ptrDist_SSE = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SSE == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_SASD;   ptrDist_SASD = (Distortion *)calloc((FrameRes >> downscaleby), sizeof(Distortion));    if (ptrDist_SASD == NULL)   printf("calloc failed\n");
    bool *ptrbool_perfSASD;   ptrbool_perfSASD = (bool *)calloc((FrameRes >> downscaleby), sizeof(bool));    if (ptrbool_perfSASD == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];  
  char strRange[8];
//  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char strblkwidth[6];
  snprintf(strblkwidth, sizeof(strblkwidth), "0%d", blkwidth);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);  
  strcat(SSIMHeatmap, "DecFrm_SSE");   
  strcat(SSIMHeatmap, strblkwidth);  
  strcat(SSIMHeatmap, "wSASD_wEdgeDetect_HeatMap_");  
  strcat(SSIMHeatmap, strpoc);        
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);        
  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);  
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

	for ( unsigned y = 0; y < height; y++ )
	{
	  for ( unsigned x = 0; x < width; x++ )
	  {
		unsigned yloc = y*width+x;

		// allocate YUV value
		int yInt = 0;//, uInt = 0, vInt = 0;

		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

		int yInt_Org = (int)ptrY_Org[yloc];  //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

		// seems fine here
		if (yInt_Org > 255 || yInt_Org < 0 || yInt_Rec > 255 || yInt_Rec < 0)
			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


        //bool SSERegion = false;
		Distortion iSumHad =0;
		Distortion iSumSSE =0;
		Distortion iSumSASD =0;
        bool SASD_Grth_Threshold = false;

        //if ((y < (height-blkwidth)) && (x < (width-blkwidth)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-blkwidth)) && (x < (width-blkwidth)) && ((y % blkwidth == 0) && (x % blkwidth == 0)))
		{
          //SSERegion = true;


		  // http://www.cplusplus.com/forum/general/40423/
		  int* SSEDiff = new int[blksz];
		  // http://www.cplusplus.com/forum/general/40423/
		  int* SASDDiff = new int[blksz];

			for ( unsigned n = 0; n < blkwidth; n++ )
			{
				for ( unsigned m = 0; m < blkwidth; m++ )
				{
					// y*width + x
					unsigned yloc8x8 = n*blkwidth+m;

					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

					////------------------
					//// YGJ 12th July 2014
					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
					//// a -- set up and initialise variables

					////------------------

					int Temp = y_Org - y_Rec;
					int TempSq = shift == 0? LumaSq_LUT[abs(Temp)] : Temp*Temp;

					SSEDiff[yloc8x8] = TempSq;

//                    int OrgSq = y_Org*y_Org;
//                    int RecSq= y_Rec*y_Rec;

					int OrgSq = shift == 0? LumaSq_LUT[y_Org] : y_Org*y_Org;
					int RecSq=  shift == 0? LumaSq_LUT[y_Rec] : y_Rec*y_Rec;

					//SASDDiff[yloc8x8] = abs(OrgSq-RecSq) - TempSq; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
                    SASDDiff[yloc8x8] = (abs(abs(OrgSq-RecSq) - TempSq)) >> 8; // YGJ 14th April 2015 was applying downshift by 8 later not during SASD calc.
					//APC[yloc8x8] = HadDiff[yloc8x8] > 0 ? TComRdCost::DecAPC(y_Org, y_Rec) : - TComRdCost::DecAPC(y_Org, y_Rec);

					//APC[yloc8x8] = TComRdCost::HadAPC(y_Org, y_Rec, 0); - Not used here in SAD only

				}
			}

            int i=0, j=0; //, jj;//, k;

			for (i = 0; i < blkwidth; i++)
			{
			  for (j = 0; j < blkwidth; j++)
			  {
				iSumSSE += abs(SSEDiff[i+j*blkwidth]);
				iSumSASD += abs(SASDDiff[i+j*blkwidth]);
			  }
			}

            //----
            // YGJ 13th Apr 2015
            // Added AysBlkTest prior to block test within block.
            //----

            // Like in HadRC and in SAD/HAD apply perceptual cost to perceptual poor blocks (where 1-SSIM score is high)
            // Edges minus corners

            int Top = 0;
            int Left = 0;
            int Right = 0;
            int Bottom = 0;

            for (i = 1; i < blkwidth-1; i++)
            {
                Top += abs(SASDDiff[i]);
                Left += abs(SASDDiff[i*blkwidth]);
                Right += abs(SASDDiff[i*blkwidth+blkwidth-1]);
                Bottom += abs(SASDDiff[blkwidth*(blkwidth-1)+i]);
            }

            // Approx Average. If 8x8, then 6 items read then divide by width, 8.
            Top /= blkwidth;
            Left /= blkwidth;
            Right /= blkwidth;
            Bottom /= blkwidth;

            // From ::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

            //UInt AsymBlkEdgeThresh = 48; //28; // Does a threshold of 28 sufficient as 16?

            //YGJ 14th April 2015 - Having used the log from the decoder (CrowdRun 1, 4 and 16 Mbps (a single frame, frame 77), a threshold of >2 was deemed appropiate
            // This should reduce where SASD is added to the SSE score.
            UInt AsymBlkEdgeThresh = 2; //28; // Does a threshold of 28 sufficient as 16?

            bool PerformIntBlkEdge = AbsAsymCost > AsymBlkEdgeThresh ? true : false;  // 16 Found to be highest point to at which most APC features are retained


//            ////-----------------------

//            //if(m_outputSSIMAndSSELog)
//            {
//                // frmAverageSSIM /=  (double)OverlappingSSIMcount;
//                // int frmAveSSE = 0; //(int)((double)FrmTotal_SSE_distortion/(double)FrameRes);

//                char SASDFile[255];  strcpy(SASDFile, m_pchSSIMLogAndImageFile);  strcat(SASDFile, "_DecFrmSASD.txt");
//                //strcpy(SSIMFrmAveFile, "_DecFrmSSIMandSSE.txt");

//                ofstream DecSASD;
//                DecSASD.open (SASDFile, ios::out | ios::app);


//                // Log out the Existing  without Proposed , Existing  with Proposed, Final threshold based Result (with or without Proposed), Threshold Result , SSIM, 1-SSIM, stats,
//                DecSASD << iSumSSE << ","  << iSumSASD << ","  << Top << ","  << Bottom << ","  << Left << ","  << Right << "," << AbsAsymCost << ","  << AsymBlkEdgeThresh << endl;

//                //DecFrmSSIM << frmAveSSE ;

//                //DecFrmSSIM << endl;
//                DecSASD.close();
//            }

//            ////-----------------------

            //----

            int SumSASDEdgeCost=0;

            //for (i = 0; i < blkwidth; i=+4)
            //{
            //  for (j = 0; j < blkwidth; j=+4)
            //  {
            //	//iSumSSE += abs(SSEDiff[i+j*blkwidth]);
            //	//iSumSASD += abs(SASDDiff[i+j*blkwidth]);
            //  }
            //}

            //iSumSASD >>=5;

            // YGJ 23rd Nov 2014 - Down scale then upscale.
            // First downscale by 7 to match LUT version, then upscale by blk specific size
            // LUT is similar to calc version of SASD minor rounding errors
            //iSumSASD >>=7;
            //iSumSASD >>=8; //Disabled - applied earlier, when calculating SASD itself

            //----

            if (PerformIntBlkEdge == true)
            {




            // YGJ 24th Nov 2014 - Looking various block sizes for SSE the scaling need not increase.
            // Leave it at 2, double.
            //iSumSASD <<=1;

//            switch(blkwidth)
//            {
////                case 4: iSumSASD <<=3; break;
////                case 8: iSumSASD <<=5; break;
////                case 16: iSumSASD <<=7; break;
////                case 32: iSumSASD <<=9; break;
////                case 64: iSumSASD <<=11; break;

////                // Rather than scale up by 1/2 Block size, scale up by 1/2 block width
////                case 4: iSumSASD <<=1; break;
////                case 8: iSumSASD <<=2; break;
////                case 16: iSumSASD <<=3; break;
////                case 32: iSumSASD <<=4; break;
////                case 64: iSumSASD <<=5; break;


////            // Rather than scale up by 1/2 Block size, scale up by 1/2 block width
////            case 4: iSumSASD <<=1; break;
////            case 8: iSumSASD <<=1; break;
////            case 16: iSumSASD <<=2; break;
////            case 32: iSumSASD <<=4; break;
////            case 64: iSumSASD <<=5; break;


//            }



//            SumSASDEdgeCost += abs( (SASDDiff[9] << 1) - SASDDiff[8] - SASDDiff[1]); // SE
//            SumSASDEdgeCost += abs( (SASDDiff[3] << 1) - SASDDiff[2] - SASDDiff[11]); //NE
//            SumSASDEdgeCost += abs( (SASDDiff[24] << 1) - SASDDiff[25] - SASDDiff[16]); // SW
//            SumSASDEdgeCost += abs( (SASDDiff[18] << 1) - SASDDiff[19] - SASDDiff[26]); // NW

//            SumSASDEdgeCost += abs( (SASDDiff[13] << 1) - SASDDiff[12] - SASDDiff[5]); // SE
//            SumSASDEdgeCost += abs( (SASDDiff[7] << 1) - SASDDiff[6] - SASDDiff[15]); //NE
//            SumSASDEdgeCost += abs( (SASDDiff[28] << 1) - SASDDiff[29] - SASDDiff[20]); // SW
//            SumSASDEdgeCost += abs( (SASDDiff[22] << 1) - SASDDiff[23] - SASDDiff[30]); // NW

//            SumSASDEdgeCost += abs( (SASDDiff[41] << 1) - SASDDiff[40] - SASDDiff[33]); // SE
//            SumSASDEdgeCost += abs( (SASDDiff[35] << 1) - SASDDiff[34] - SASDDiff[43]); //NE
//            SumSASDEdgeCost += abs( (SASDDiff[56] << 1) - SASDDiff[57] - SASDDiff[48]); // SW
//            SumSASDEdgeCost += abs( (SASDDiff[50] << 1) - SASDDiff[51] - SASDDiff[58]); // NW

//            SumSASDEdgeCost += abs( (SASDDiff[45] << 1) - SASDDiff[44] - SASDDiff[37]); // SE
//            SumSASDEdgeCost += abs( (SASDDiff[39] << 1) - SASDDiff[38] - SASDDiff[47]); //NE
//            SumSASDEdgeCost += abs( (SASDDiff[60] << 1) - SASDDiff[61] - SASDDiff[52]); // SW
//            SumSASDEdgeCost += abs( (SASDDiff[54] << 1) - SASDDiff[55] - SASDDiff[62]); // NW



            SumSASDEdgeCost += ( (SASDDiff[9] << 1) - SASDDiff[8] - SASDDiff[1]) >  0 ? 1 : 0; // SE
            SumSASDEdgeCost += ( (SASDDiff[3] << 1) - SASDDiff[2] - SASDDiff[11]) >  0 ? 1 : 0; //NE
            SumSASDEdgeCost += ( (SASDDiff[24] << 1) - SASDDiff[25] - SASDDiff[16]) >  0 ? 1 : 0; // SW
            SumSASDEdgeCost += ( (SASDDiff[18] << 1) - SASDDiff[19] - SASDDiff[26]) >  0 ? 1 : 0; // NW

            SumSASDEdgeCost += ( (SASDDiff[13] << 1) - SASDDiff[12] - SASDDiff[5]) >  0 ? 1 : 0; // SE
            SumSASDEdgeCost += ( (SASDDiff[7] << 1) - SASDDiff[6] - SASDDiff[15]) >  0 ? 1 : 0; //NE
            SumSASDEdgeCost += ( (SASDDiff[28] << 1) - SASDDiff[29] - SASDDiff[20]) >  0 ? 1 : 0; // SW
            SumSASDEdgeCost += ( (SASDDiff[22] << 1) - SASDDiff[23] - SASDDiff[30]) >  0 ? 1 : 0; // NW

            SumSASDEdgeCost += ( (SASDDiff[41] << 1) - SASDDiff[40] - SASDDiff[33]) >  0 ? 1 : 0; // SE
            SumSASDEdgeCost += ( (SASDDiff[35] << 1) - SASDDiff[34] - SASDDiff[43]) >  0 ? 1 : 0; //NE
            SumSASDEdgeCost += ( (SASDDiff[56] << 1) - SASDDiff[57] - SASDDiff[48]) >  0 ? 1 : 0; // SW
            SumSASDEdgeCost += ( (SASDDiff[50] << 1) - SASDDiff[51] - SASDDiff[58]) >  0 ? 1 : 0; // NW

            SumSASDEdgeCost += ( (SASDDiff[45] << 1) - SASDDiff[44] - SASDDiff[37]) >  0 ? 1 : 0; // SE
            SumSASDEdgeCost += ( (SASDDiff[39] << 1) - SASDDiff[38] - SASDDiff[47]) >  0 ? 1 : 0; //NE
            SumSASDEdgeCost += ( (SASDDiff[60] << 1) - SASDDiff[61] - SASDDiff[52]) >  0 ? 1 : 0; // SW
            SumSASDEdgeCost += ( (SASDDiff[54] << 1) - SASDDiff[55] - SASDDiff[62]) >  0 ? 1 : 0; // NW

            }

			//int threshold = 32;
            // threshold is half max area for given block area

            // YGJ 23rd Nov 2014 - Based upon 5/4 * Blocksize or 1.25*Blksize
            //int threshold = 80;//LumaSq_LUT[blkwidth] + (LumaSq_LUT[blkwidth] >> 2);

            // YGJ 11th Dec 2014 - Based upon recalc SASD from raw values for affected pixel of edge detect
            // Median was 496, will approx to 512.
            int threshold = 512;

            //SASD_Grth_Threshold = iSumSASD > threshold? true : false ;

            //int SASD_EdgeCompassSum_thresh = 128; // Based upon modeling of raw data, median was 118, rounded to 128.
            int SASD_EdgeCompassSum_thresh = 8; // Based upon modeling of raw data, median was 8. Removed abs, keep it simple. ~1/6 obs affected

			// Apply if initial threshold has been met
            //SASD_Grth_Threshold = iSumSASD > threshold? (SumSASDEdgeCost > SASD_EdgeCompassSum_thresh? true : false ): false;

            //SASD_Grth_Threshold = iSumSASD > threshold? true : false;

            SASD_Grth_Threshold = (SumSASDEdgeCost > SASD_EdgeCompassSum_thresh) && (iSumSASD > threshold) ? true : false;
            iSumSASD >>= 1;

            //SASD_Grth_Threshold = SumSASDEdgeCost > 0? true : false;

            //iSumSASD = SumSASDEdgeCost > SASD_EdgeCompassSum_thresh? iSumSASD >> 1:
            //           SumSASDEdgeCost > (SASD_EdgeCompassSum_thresh >> 1)? iSumSASD >> 2 : iSumSASD >> 3;



			//iSumHad = iSumSASD > threshold? iSumSASD < (iSumSSE >> 2)? (iSumSASD + iSumSSE) : iSumSSE : iSumSSE; // No fun

            //Prev: This below
            //iSumHad = iSumSASD > threshold? (iSumSASD + iSumSSE) : iSumSSE ;

            //iSumHad = (iSumSASD + iSumSSE); // works with iSumSASD >>=4;                        

            ptrDist_SSE[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = iSumSSE;
            ptrDist_SASD[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = iSumSASD;
            ptrbool_perfSASD[(x >> shiftby) + (y >> 3)*(width>>shiftby)] = SASD_Grth_Threshold;
			
			delete SSEDiff;
			delete SASDDiff;
		}
        else if ((y < (height-blkwidth)) && (x < (width-blkwidth)))
        {

            iSumSSE = ptrDist_SSE[(x >> shiftby) + (y >> 3)*(width>>shiftby)];
            iSumSASD = ptrDist_SASD[(x >> shiftby) + (y >> 3)*(width>>shiftby)];
            SASD_Grth_Threshold = ptrbool_perfSASD[(x >> shiftby) + (y >> 3)*(width>>shiftby)];

        }



		yInt = yInt_Rec;

        int r, b, g;

        //  APC score will be between 0 and 127.
        // Dependent upon value apply different colour
        //if (SSERegion == true)
        if (SASD_Grth_Threshold == true)
        {

            //iSumHad = iSumSASD > threshold? (iSumSASD + iSumSSE) : iSumSSE ;
            iSumHad = iSumSSE + iSumSASD;

			//------------------------------

			int loc = (int)log2((double)blkwidth) - 3;

			int maxUnscaled = (maxLimitSSE_k[loc] * NormDist_OneMin10k[m_distRange]);
			float maxScaled = (float)((float)maxUnscaled * (0.1024));
			//float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); // Not applicable

			Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
				printf("SSE %d wSASD (with EdgeDetect) is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n", 
				blkwidth, halfMaxThreshold, iSumHad, halfMaxThreshold);
						
			float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

			//switch (val)
			//{
			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
			//		break;
			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
			//		break;
			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
			//		break;
			//}
			////------------------

			//------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
			switch (val)
			{
				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
					break;
				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
					break;
				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
					break;				
				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
					break;
			}
            //------------------

		}
		else
		{
				//        // Convert YUV to RGB
			// Without chroma parts
			r = yInt; // + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
			g = yInt; // - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
			b = yInt; // + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);
		}


		// Rec - Org
		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


		// Partitioning -- Not Working
		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
		{
		  r = 0; //yInt_RmO;
		  g = 0; //yInt_RmO;
		  b = 0; //yInt_RmO;
		}



		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

	  }
	  //piY += YStride;
	  piY_Org += YStride;
	  piY_Rec += YStrideRec;
	  piY_Part += YStrideRec;

	}

	free(ptrY_Org8x8);
	free(ptrY_Rec8x8);

	free(ptrY_Org);

	free(ptrY_Rec);

	free(ptrY_Part);

	//-----------------------

	if(m_outputSSIMHeatmaps)
	{
	  std::vector<unsigned char> png;

	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

	  //if there's an error, display it
	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
	}

   //-----------------------

}



//Void TAppDecTop::saveFrameAsPNG_RCHadPreAssess_MS_APC(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  //char strFactor[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_RCActivity_PreAssessMSAPCHadActiHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0; //, uInt = 0, vInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
////        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
////        int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);


//        //bool HadRegion = false;
//        Distortion iSumHad =0;
//        Distortion iSumHadAPC = 0;
//        bool PerformMsAPC = false;

//        Pel *diff;
//        int i, j, jj, k;
//        int blksz = 64;


//        if ((y < (height-8)) && (x < (width-8)))
//        {
//          //HadRegion = true;

////          Distortion diff[64];
//          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//          Int m1APC[8][8], m2APC[8][8], m3APC[8][8]; //, iSumHadAPC = 0;
//          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.



//            for ( unsigned n = 0; n < 8; n++ )
//            {
//                for ( unsigned m = 0; m < 8; m++ )
//                {
//                    unsigned yloc8x8 = n*m+m;

//                    ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

//                }
//            }

//            diff = ptrY_Org8x8;

//            //-------------------------

//            // YGJ Sun 24th Aug 2014 - Pre Assessment to determine whether multi-scale APC is justified
//            // Calc APC for Top, Bottom, Left and Right side of 8x8 (First and Last Row and Columns)
//            // Note that APC is calculated by accessing the Look Up Table (LUT).
//            // While in SAD, APC can be accumulated then divided by 2, here the LUT used, (APC_NegAndPos_1D) via the function (RCHadAPC) has the values already divided by 2.
//            // However, in multi-scale APC they must be divided by their interval, which APC_NegAndPos_1D will perform by entering the number bits to shift by.
//            //
//            // Multi-scale APC does require significant amount of processing.
//            // Under rate-control this will occur when a new Group of Pictures (GOP) sequence requires the bit-rate to be budgetted by frame/slice type.
//            // Regardless, applying multi-scale APC irrespectively, can increase processing demand unnecessarily.
//            // Also, hadamard transform employs symmetry to elminate/minimise accumulated differences.
//            // Applying a test for asymmetrical perceptual changes can then differieniate when multi-scale is suitable to apply and limiting the use of additional complexity till then.
//            //
//            // A non-symmetrical distribution of two regions in a block can affect the percpetual rate of change along one of the edges of the block.
//            // By subtracting opposing edges from each other any dominant edge, where the perceptual rate of change is far higher than the others will be shown.
//            // The threshold by which the resulting value should tested against should be the block size, in this case, 8x8 = 64.
//            // If (abs(abs(T-B) - abs(L-R)) > 64
//            // In general, this should make the processing more adaptive/dynamic, only applying multi-scale APC  according to the level of asymmetric boundary changes where the intensity (Luma) is high.
//            // Expect processing demand to vary depending upon the scene in question.
//            // Based upon simulations based observations gathered from the first frame of Race Horses video (416 x 240) where 1560 samples are processed, one per 8x8 block region, the need to called multi-scale APC can be reduced by 2/3.

//            //----

//            // First calc Horizontal
//            // For Top and Left this their initial cost (stage 1 of 2).
//            // For Bottom it is the only time it will be updated (1 of 1).
//            // For Right it will be set during vertical (0 of 1).

//            //-----

//            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//            //H/V: x, 1/8, 1/4, 1/2
//            // H: 0: (0,4),(0,2),(0,1)
//            // H: 1: (1,5),(1,3),--
//            // H: 2: (2,6),--, (2,3)
//            // H: 3: (3,7),--,--
//            // H: 4: --,(4,6),(4,5)
//            // H: 5: --,(5,7),--
//            // H: 6: --,--,(6,7)
//            // H:7: Always  Zero

//            // This means for Top and Bottom the above is correct.
//            // For  Left    // H: 0: (0,4),(0,2),(0,1) needs to be performed.
//            // For Right as stated it is // H:7: Always  Zero

//            //-----

//            // Second  calc Vertical
//            // Like Horizontal but now for the others are updated/completed.
//            // Top and Left are completed
//            // Right is updated.

//            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//            //H/V: x, 1/8, 1/4, 1/2
//            // V: 0: (0,4),(0,2),(0,1)
//            // V: 1: (1,5),(1,3),--
//            // V: 2: (2,6),--, (2,3)
//            // V: 3: (3,7),--,--
//            // V: 4: --,(4,6),(4,5)
//            // V: 5: --,(5,7),--
//            // V: 6: --,--,(6,7)
//            // V:7: Always  Zero

//            // For Left and Right the above is correct
//            // Top -  // V: 0: (0,4),(0,2),(0,1)
//            // Bottom - // V:7: Always  Zero

//            //-----

//            // Now to check if full multi-scale APC is required of Hadamard is sufficient
//            // If (abs(abs(Top-Bottom) - abs(Left-Right)) > 64 then perform multii-scale APC.
//            // Multi-scale APC has a high score where boundary changes occur where  Luma intensity is high.
//            // Hadamard is suited for where symmetrical differences exist.
//            // Thus, multi-scale APC is suited for where asymmetric boundary changes occur for high Luma 8x8 blocks.
//            // It is possible that the top left corner pixel can strongly influence both Top and Left.
//            // To avoid the top left corner pixel affecting the scores, the test for full multi-scale APC is a series of differences.
//            // Furthermore, the threshold of 64 is sufficiently low enough to allow a range of potential candidates for the full multi-scale APC.

//            //---------------

//            // YGJ Wed 27th Aug 2014
//            // Pre-Assessment Test for multi-scale APC
//            // Just the sides without corners.
//            // Assuming perceptual information is continuous and may cross over blocksizes.
//            // If the change on the edges are high then they is likley asymmetric change in the block.
//            // For Hadamard symmetry is used to cancel accumulated differences.
//            // While asymmetric differences do not cancel out.
//            // This means APC on Had is best applied when asymmetric changes are high
//            // The use of this Pre-Assessment is devised to initially detect if asymmetric differences exist.
//            // If not the remaining process reverts back to the existing Hadamard method.
//            // The proposed method is expected to applible about 10% of the time, though this will vary depending upon video/frame content.

//            // Distance
//            int dist4 = 5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
//            int dist2 = 3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
//            int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value

//            //int TopLeftPx = 0;  // Shared by Left and Top
//            int Top = 0, Left = 0;

//              // Ignore Corner, this leaves 1-6

//            Top += multiscaleAPC[1] = TComRdCost::RCHadAPC((int)diff[1], (int)diff[5], dist4) + TComRdCost::RCHadAPC((int)diff[1], (int)diff[3], dist2);
//            Top += multiscaleAPC[2] = TComRdCost::RCHadAPC((int)diff[2], (int)diff[6], dist4) + TComRdCost::RCHadAPC((int)diff[2], (int)diff[3], dist1);
//            Top += multiscaleAPC[3] = TComRdCost::RCHadAPC((int)diff[3], (int)diff[7], dist4);
//            Top += multiscaleAPC[4] = TComRdCost::RCHadAPC((int)diff[4], (int)diff[6], dist2) + TComRdCost::RCHadAPC((int)diff[4], (int)diff[5], dist1);
//            Top += multiscaleAPC[5] = TComRdCost::RCHadAPC((int)diff[5], (int)diff[7], dist2);
//            Top += multiscaleAPC[6] = TComRdCost::RCHadAPC((int)diff[6], (int)diff[7], dist1);
//            //---


//          // Since the first row (0) is done, and the last row (56) will be done later, just do the intervening rows (8, 16, 32, 40, 48)
//          for( k = 8; k < 56; k += 8 )
//          {
//            Left += multiscaleAPC[k] = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+4], dist4)
//                                    +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+2], dist2)
//                                    +   TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+1], dist1);
//          }

//          //int BottomLeft = 0; // Shared by Left and Bottom
//          int Bottom = 0;
//          //---

//          // Ignore Corner, this leaves 57-62

//          Bottom += multiscaleAPC[57] = TComRdCost::RCHadAPC((int)diff[57], (int)diff[61], dist4) + TComRdCost::RCHadAPC((int)diff[57], (int)diff[59], dist2);
//          Bottom += multiscaleAPC[58] = TComRdCost::RCHadAPC((int)diff[58], (int)diff[62], dist4) + TComRdCost::RCHadAPC((int)diff[58], (int)diff[59], dist1);
//          Bottom += multiscaleAPC[59] = TComRdCost::RCHadAPC((int)diff[59], (int)diff[63], dist4);
//          Bottom += multiscaleAPC[60] = TComRdCost::RCHadAPC((int)diff[60], (int)diff[62], dist2) + TComRdCost::RCHadAPC((int)diff[60], (int)diff[61], dist1);
//          Bottom += multiscaleAPC[61] = TComRdCost::RCHadAPC((int)diff[61], (int)diff[63], dist2);
//          Bottom += multiscaleAPC[62] = TComRdCost::RCHadAPC((int)diff[62], (int)diff[63], dist1);

//          //---

//          // ----------
//          // Vertical

//        //  //---

//          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//          int iTemp;

//          iTemp = TComRdCost::RCHadAPC((int)diff[8], (int)diff[40], dist4)  + TComRdCost::RCHadAPC((int)diff[8], (int)diff[24], dist2);  Left += iTemp; multiscaleAPC[8] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[16], (int)diff[48], dist4) + TComRdCost::RCHadAPC((int)diff[16], (int)diff[24], dist1); Left += iTemp; multiscaleAPC[16] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[24], (int)diff[56], dist4);                                               Left += iTemp; multiscaleAPC[24] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[32], (int)diff[48], dist2) + TComRdCost::RCHadAPC((int)diff[32], (int)diff[40], dist1); Left += iTemp; multiscaleAPC[32] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[40], (int)diff[56], dist2);                                               Left += iTemp; multiscaleAPC[40] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[48], (int)diff[56], dist1);                                               Left += iTemp; multiscaleAPC[48] += iTemp;

//          //---

//          // Similar to before since the top left (0) has been calc for Left and top right (7) will be calc afterwards for Right only those in between need to be calc. (1- 6)
//          for( k = 1; k < 7; k++ )
//          {
//            iTemp = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+32], dist4)
//                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+16], dist2)
//                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+8], dist1);

//            Top += iTemp; multiscaleAPC[k] += iTemp;
//          }

//          //---

//          int Right = 0;

//          // Ignore Corner, this leaves 15, 23, 31, 39, 47, 55
//          Right += multiscaleAPC[15] =  TComRdCost::RCHadAPC((int)diff[15], (int)diff[47], dist4) +  TComRdCost::RCHadAPC((int)diff[15], (int)diff[31], dist2);
//          Right += multiscaleAPC[23] =  TComRdCost::RCHadAPC((int)diff[23], (int)diff[55], dist4) +  TComRdCost::RCHadAPC((int)diff[23], (int)diff[31], dist1);
//          Right += multiscaleAPC[31] =  TComRdCost::RCHadAPC((int)diff[31], (int)diff[63], dist4);
//          Right += multiscaleAPC[39] =  TComRdCost::RCHadAPC((int)diff[39], (int)diff[55], dist2) +  TComRdCost::RCHadAPC((int)diff[39], (int)diff[47], dist1);
//          Right += multiscaleAPC[47] =  TComRdCost::RCHadAPC((int)diff[47], (int)diff[63], dist2);
//          Right += multiscaleAPC[55] =  TComRdCost::RCHadAPC((int)diff[55], (int)diff[63], dist1);
//          //---
//            //-------------------------
//            // Now to Test if the full multi-scale APC is required or not

//            //bool PerformMsAPC = abs(abs(Top-Bottom) - abs(Left-Right)) > 64 ? true : false;

//            // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));


//            //if (AbsAsymCost > 28)
//            //{

//            //    //================================================
//            //    //Log Threshold by CU and Frame number

//            //    //    ofstream CalcValues;

//            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//            //     ofstream ThreshLog;
//            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_HAD_RC.txt", ios::out | ios::app);
//            //
//            //     UInt MaxCUx = width >> 6;
//            //     UInt MaxCUy = height >> 6;
//            //     UInt CUx = x >> 6;
//            //     UInt CUy = y >> 6;

//            //     ThreshLog << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//            //     ThreshLog.close();

//            //    //================================================
//            //}

//            // Sun 23rd Nov 2014
//            // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
//            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//            // Over 48 million observations were logged, which represented 8.7 million unique records.
//            UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?

//            PerformMsAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//            int *ptrAPCDiff;

//            switch(PerformMsAPC)
//            {

//            case false: ptrAPCDiff = HadAllZero64; break;

//            case true:
//                {

//                    //-------------------------
//                    // YGJ Fri 22nd Aug 2014 - Since the jump between pixels is 4 and APC is divided by 2 by default then the APC score should be divided by (4*2), 8, shift by 3.
//                    // Since APC LUT violates SSIM and other existing distortion measures use of symmetry, where pixel x vs y is the same as pixel y vs x, choice of which is the reference is important.
//                    // Use max for the two pixels to determine the reference point.

//                    // YGJ Sat 23rd Aug 2014 - MulitScaled APC Prior to Hadamard - accumulates the various weighted APC/2 scores by different intervals
//                    // APC/2, if space of 4, div by 4, if space of 2, div by 2, if space of 1, div by 1.
//                    // Repeat for Vertical and then accumulate.
//                    // When being used H1, div APC by 8.

//                    // Wrong (ignore)-> Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//                    // YGJ Wed 27th Aug 2014 - Correction: RCHadAPC divides by two before it returns the value, just divide by the spacing 4, 2 or 1.
//                    //H/V: x, 1/64, 1/16, 1/2
//                    // H: 0: (0,4),(0,2),(0,1)
//                    // H: 1: (1,5),(1,3),--
//                    // H: 2: (2,6),--, (2,3)
//                    // H: 3: (3,7),--,--
//                    // H: 4: --,(4,6),(4,5)
//                    // H: 5: --,(5,7),--
//                    // H: 6: --,--,(6,7)
//                    // H:7: Always  Zero

//                    // First the inner square (block without the edges or corners)



//                // Horizontal
//                for( k = 8; k < 56; k += 8 )
//                {
//                  multiscaleAPC[k+1] = TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+5], dist4) + TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+3], dist2);
//                  multiscaleAPC[k+2] = TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+6], dist4) + TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+3], dist1);
//                  multiscaleAPC[k+3] = TComRdCost::RCHadAPC((int)diff[k+3], (int)diff[k+7], dist4);
//                  multiscaleAPC[k+4] = TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+6], dist2) +  TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+5], dist1);
//                  multiscaleAPC[k+5] = TComRdCost::RCHadAPC((int)diff[k+5], (int)diff[k+7], dist2);
//                  multiscaleAPC[k+6] = TComRdCost::RCHadAPC((int)diff[k+6], (int)diff[k+7], dist1);
//                }


//                //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//                //H/V: x, 1/8, 1/4, 1/2
//                // V: 0: (0,4),(0,2),(0,1)
//                // V: 1: (1,5),(1,3),--
//                // V: 2: (2,6),--, (2,3)
//                // V: 3: (3,7),--,--
//                // V: 4: --,(4,6),(4,5)
//                // V: 5: --,(5,7),--
//                // V: 6: --,--,(6,7)
//                // V:7: Always  Zero

//                // Vertical
//                // Same as Horizontal but now k is from 0 to 7 and k+1/2/3/4/5/6/7 are now k+(1/2/3/4/5/6/7 x 8)
//                // Hence it is the same as Horizontal but rotated

//                // Remember to increment and not assign/replace existing value

//                for( k = 1; k < 7; k++ )
//                {
//                  multiscaleAPC[k+8] += TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+40], dist4) + TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+24], dist2);
//                  multiscaleAPC[k+16] += TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+48], dist4) + TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+24], dist1);
//                  multiscaleAPC[k+24] += TComRdCost::RCHadAPC((int)diff[k+24], (int)diff[k+56], dist4);
//                  multiscaleAPC[k+32] += TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+48], dist2) + TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+40], dist1);
//                  multiscaleAPC[k+40] += TComRdCost::RCHadAPC((int)diff[k+40], (int)diff[k+56], dist2);
//                  multiscaleAPC[k+48] += TComRdCost::RCHadAPC((int)diff[k+48], (int)diff[k+56], dist1);
//                }

//                //Now the corners

//                  //---
//                  // Top Left (Horizontal and Vertical)
//                  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

//                  // Bottom Left only has Horizontal components only
//                  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
//                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
//                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


//                  // Top Right only has Vertical components only
//                  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

//                  // Bottom Right has no components
//                  multiscaleAPC[63] = 0; // Always Zero
//                //-------------------------

//                      //----
//                  ptrAPCDiff = multiscaleAPC;
//                }
//                break; // End of (if (PerformMsAPC = true))
//            }

//            // End of Multi-Scale APC
//            //=============================
//            // Beginning of Hadamard with APC

//            //Now to add/subtract to the Hadamard Diff.
//            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
//            //int APCscale = 0;

//            //horizontal
//            for (j=0; j < 8; j++)
//            {
//              jj = j << 3;

//              // Additional Pixel Cost (APC) - Add APC to the difference
////			  m2[j][0] = diff[jj  ] + diff[jj+4] + ptrAPCDiff[jj  ];
////			  m2[j][1] = diff[jj+1] + diff[jj+5] + ptrAPCDiff[jj+1];
////			  m2[j][2] = diff[jj+2] + diff[jj+6] + ptrAPCDiff[jj+2];
////			  m2[j][3] = diff[jj+3] + diff[jj+7] + ptrAPCDiff[jj+3];
////			  m2[j][4] = diff[jj  ] - diff[jj+4] + ptrAPCDiff[jj+4];
////			  m2[j][5] = diff[jj+1] - diff[jj+5] + ptrAPCDiff[jj+5];
////			  m2[j][6] = diff[jj+2] - diff[jj+6] + ptrAPCDiff[jj+6];
////			  m2[j][7] = diff[jj+3] - diff[jj+7] + ptrAPCDiff[jj+7];

//              m2[j][0] = diff[jj  ] + diff[jj+4];
//              m2[j][1] = diff[jj+1] + diff[jj+5];
//              m2[j][2] = diff[jj+2] + diff[jj+6];
//              m2[j][3] = diff[jj+3] + diff[jj+7];
//              m2[j][4] = diff[jj  ] - diff[jj+4];
//              m2[j][5] = diff[jj+1] - diff[jj+5];
//              m2[j][6] = diff[jj+2] - diff[jj+6];
//              m2[j][7] = diff[jj+3] - diff[jj+7];


//              m1[j][0] = m2[j][0] + m2[j][2];
//              m1[j][1] = m2[j][1] + m2[j][3];
//              m1[j][2] = m2[j][0] - m2[j][2];
//              m1[j][3] = m2[j][1] - m2[j][3];
//              m1[j][4] = m2[j][4] + m2[j][6];
//              m1[j][5] = m2[j][5] + m2[j][7];
//              m1[j][6] = m2[j][4] - m2[j][6];
//              m1[j][7] = m2[j][5] - m2[j][7];

//              m2[j][0] = m1[j][0] + m1[j][1];
//              m2[j][1] = m1[j][0] - m1[j][1];
//              m2[j][2] = m1[j][2] + m1[j][3];
//              m2[j][3] = m1[j][2] - m1[j][3];
//              m2[j][4] = m1[j][4] + m1[j][5];
//              m2[j][5] = m1[j][4] - m1[j][5];
//              m2[j][6] = m1[j][6] + m1[j][7];
//              m2[j][7] = m1[j][6] - m1[j][7];

//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {

//                      m2APC[j][0] = ptrAPCDiff[jj  ] ;
//                      m2APC[j][1] = ptrAPCDiff[jj+1] ;
//                      m2APC[j][2] = ptrAPCDiff[jj+2] ;
//                      m2APC[j][3] = ptrAPCDiff[jj+3] ;
//                      m2APC[j][4] = - (ptrAPCDiff[jj+4] );
//                      m2APC[j][5] = - (ptrAPCDiff[jj+5] );
//                      m2APC[j][6] = - (ptrAPCDiff[jj+6] );
//                      m2APC[j][7] = - (ptrAPCDiff[jj+7] );

//                      m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
//                      m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
//                      m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
//                      m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
//                      m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
//                      m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
//                      m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
//                      m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

//                      m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
//                      m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
//                      m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
//                      m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
//                      m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
//                      m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
//                      m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
//                      m2APC[j][7] = m1APC[j][6] - m1APC[j][7];

//                      }
//              }


//            }

//            //vertical
//            for (i=0; i < 8; i++)
//            {
//              m3[0][i] = m2[0][i] + m2[4][i];
//              m3[1][i] = m2[1][i] + m2[5][i];
//              m3[2][i] = m2[2][i] + m2[6][i];
//              m3[3][i] = m2[3][i] + m2[7][i];
//              m3[4][i] = m2[0][i] - m2[4][i];
//              m3[5][i] = m2[1][i] - m2[5][i];
//              m3[6][i] = m2[2][i] - m2[6][i];
//              m3[7][i] = m2[3][i] - m2[7][i];

//              m1[0][i] = m3[0][i] + m3[2][i];
//              m1[1][i] = m3[1][i] + m3[3][i];
//              m1[2][i] = m3[0][i] - m3[2][i];
//              m1[3][i] = m3[1][i] - m3[3][i];
//              m1[4][i] = m3[4][i] + m3[6][i];
//              m1[5][i] = m3[5][i] + m3[7][i];
//              m1[6][i] = m3[4][i] - m3[6][i];
//              m1[7][i] = m3[5][i] - m3[7][i];

//              m2[0][i] = m1[0][i] + m1[1][i];
//              m2[1][i] = m1[0][i] - m1[1][i];
//              m2[2][i] = m1[2][i] + m1[3][i];
//              m2[3][i] = m1[2][i] - m1[3][i];
//              m2[4][i] = m1[4][i] + m1[5][i];
//              m2[5][i] = m1[4][i] - m1[5][i];
//              m2[6][i] = m1[6][i] + m1[7][i];
//              m2[7][i] = m1[6][i] - m1[7][i];


//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {
//                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
//                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
//                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
//                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
//                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
//                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
//                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
//                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

//                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
//                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
//                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
//                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
//                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
//                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
//                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
//                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

//                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
//                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
//                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
//                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
//                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
//                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
//                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
//                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];

//                      }
//              }



//            }

//            for (i = 0; i < 8; i++)
//            {
//              for (j = 0; j < 8; j++)
//              {
//                iSumHad += abs(m2[i][j]);
//                iSumHadAPC += PerformMsAPC == true? abs(m2APC[i][j]) : 0;
//              }
//            }
//            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
//            iSumHad =(iSumHad+2)>>2;

//            iSumHadAPC -= PerformMsAPC == true? abs(m2APC[0][0]) : 0;
//            iSumHadAPC =(iSumHadAPC+2)>>2;


//        }

//        yInt = yInt_Org;


//         int r=0, g=0, b=0;

//        //if (HadRegion == true)
//        if (PerformMsAPC == true)
//        {


//            //------------------

//            int blkwidth = 8;

//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = (int)log2((double)blkwidth) - 3;

//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            //float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); //Not applicable

//            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//            // For Rate-Control
//            halfMaxThreshold <<= 1; // Double

//            // Divide APC cost by 1/2 Blk size before adding to Had cost
//            iSumHadAPC = iSumHadAPC/(blksz >> 1);
//            iSumHad += iSumHadAPC;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////            int val = dist < (halfMaxThreshold >> 2) ? 0
////                : dist < (halfMaxThreshold >> 1) ? 1
////                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("RateControl Pre Assess Had with Multiscale-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);

//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;

//            //------------------


//            //switch (val)
//            //{
//            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//            //		break;
//            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//            //		break;
//            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //}

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt;
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//        // Partitioning -- Not Working?
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0; //yInt_RmO;
//          g = 0; //yInt_RmO;
//          b = 0; //yInt_RmO;
//        }



//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      piY_Org += YStride;
//      piY_Part += YStrideRec;

//    }

//    free(ptrY_Org8x8);

//    free(ptrY_Org);

//    free(ptrY_Part);

//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//}




//Void TAppDecTop::saveFrameAsPNG_RCHadPreAssess_wCornerTest_MS_APC(TComPic* pcPic)
Void TAppDecTop::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight;
  unsigned width = m_iSourceWidth;
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

  Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");

  // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
  // Store values for when at the start of 8x8 and recalled for when within 8x8 block
  Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");
  Distortion *ptrDist_APCms;   ptrDist_APCms = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_APCms == NULL)   printf("calloc failed\n");
  bool *ptrbool_perfAPCms;   ptrbool_perfAPCms = (bool *)calloc((FrameRes >> 6), sizeof(bool));    if (ptrbool_perfAPCms == NULL)   printf("calloc failed\n");


   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  //char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  //strcat(SSIMHeatmap, "DecFrm_RCActivity_PreAssess_wCornerTest_MSAPCHadActiHeatMap_");
  strcat(SSIMHeatmap, "DecFrm_RCActivity_PreAssess_wCornerTestwEdgeScale_MSAPCHadActiHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    //////////////////////////
    // YGJ 5th Jan 2015
    // Non-Overlapping 8x8, to be more like Rate Control
    // Save as previous values

//    Distortion PrevHad = 0;
//    Distortion  PrevAPCms = 0;
//    bool PrevBoolPerformAPCms = false;


    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);




        //bool HadRegion = false;
        Distortion iSumHad =0; // PrevHad = 0;
        Distortion iSumHadAPC = 0; //, PrevAPCms = 0;
        bool PerformMsAPC = false; //, PrevBoolPerformAPCms = false;

        Pel *diff;
        int i, j, jj, k;
        //int blksz = 64;
        Int SumAPCmsEdgeCost = 0;


        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          //HadRegion = true;

//          Distortion diff[64];
          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
          //Int m1APC[8][8], m2APC[8][8], m3APC[8][8]; //, iSumHadAPC = 0;
          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.


            for ( unsigned n = 0; n < 8; n++ )
            {
                for ( unsigned m = 0; m < 8; m++ )
                {
                    unsigned yloc8x8 = n*m+m;

                    ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

                }
            }

            diff = ptrY_Org8x8;

            //-------------------------

            // YGJ Sun 24th Aug 2014 - Pre Assessment to determine whether multi-scale APC is justified
            // Calc APC for Top, Bottom, Left and Right side of 8x8 (First and Last Row and Columns)
            // Note that APC is calculated by accessing the Look Up Table (LUT).
            // While in SAD, APC can be accumulated then divided by 2, here the LUT used, (APC_NegAndPos_1D) via the function (RCHadAPC) has the values already divided by 2.
            // However, in multi-scale APC they must be divided by their interval, which APC_NegAndPos_1D will perform by entering the number bits to shift by.
            //
            // Multi-scale APC does require significant amount of processing.
            // Under rate-control this will occur when a new Group of Pictures (GOP) sequence requires the bit-rate to be budgetted by frame/slice type.
            // Regardless, applying multi-scale APC irrespectively, can increase processing demand unnecessarily.
            // Also, hadamard transform employs symmetry to elminate/minimise accumulated differences.
            // Applying a test for asymmetrical perceptual changes can then differieniate when multi-scale is suitable to apply and limiting the use of additional complexity till then.
            //
            // A non-symmetrical distribution of two regions in a block can affect the percpetual rate of change along one of the edges of the block.
            // By subtracting opposing edges from each other any dominant edge, where the perceptual rate of change is far higher than the others will be shown.
            // The threshold by which the resulting value should tested against should be the block size, in this case, 8x8 = 64.
            // If (abs(abs(T-B) - abs(L-R)) > 64
            // In general, this should make the processing more adaptive/dynamic, only applying multi-scale APC  according to the level of asymmetric boundary changes where the intensity (Luma) is high.
            // Expect processing demand to vary depending upon the scene in question.
            // Based upon simulations based observations gathered from the first frame of Race Horses video (416 x 240) where 1560 samples are processed, one per 8x8 block region, the need to called multi-scale APC can be reduced by 2/3.

            //----

            // First calc Horizontal
            // For Top and Left this their initial cost (stage 1 of 2).
            // For Bottom it is the only time it will be updated (1 of 1).
            // For Right it will be set during vertical (0 of 1).

            //-----

            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
            //H/V: x, 1/8, 1/4, 1/2
            // H: 0: (0,4),(0,2),(0,1)
            // H: 1: (1,5),(1,3),--
            // H: 2: (2,6),--, (2,3)
            // H: 3: (3,7),--,--
            // H: 4: --,(4,6),(4,5)
            // H: 5: --,(5,7),--
            // H: 6: --,--,(6,7)
            // H:7: Always  Zero

            // This means for Top and Bottom the above is correct.
            // For  Left    // H: 0: (0,4),(0,2),(0,1) needs to be performed.
            // For Right as stated it is // H:7: Always  Zero

            //-----

            // Second  calc Vertical
            // Like Horizontal but now for the others are updated/completed.
            // Top and Left are completed
            // Right is updated.

            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
            //H/V: x, 1/8, 1/4, 1/2
            // V: 0: (0,4),(0,2),(0,1)
            // V: 1: (1,5),(1,3),--
            // V: 2: (2,6),--, (2,3)
            // V: 3: (3,7),--,--
            // V: 4: --,(4,6),(4,5)
            // V: 5: --,(5,7),--
            // V: 6: --,--,(6,7)
            // V:7: Always  Zero

            // For Left and Right the above is correct
            // Top -  // V: 0: (0,4),(0,2),(0,1)
            // Bottom - // V:7: Always  Zero

            //-----

            // Now to check if full multi-scale APC is required of Hadamard is sufficient
            // If (abs(abs(Top-Bottom) - abs(Left-Right)) > 64 then perform multii-scale APC.
            // Multi-scale APC has a high score where boundary changes occur where  Luma intensity is high.
            // Hadamard is suited for where symmetrical differences exist.
            // Thus, multi-scale APC is suited for where asymmetric boundary changes occur for high Luma 8x8 blocks.
            // It is possible that the top left corner pixel can strongly influence both Top and Left.
            // To avoid the top left corner pixel affecting the scores, the test for full multi-scale APC is a series of differences.
            // Furthermore, the threshold of 64 is sufficiently low enough to allow a range of potential candidates for the full multi-scale APC.

            //---------------

            // YGJ Wed 27th Aug 2014
            // Pre-Assessment Test for multi-scale APC
            // Just the sides without corners.
            // Assuming perceptual information is continuous and may cross over blocksizes.
            // If the change on the edges are high then they is likley asymmetric change in the block.
            // For Hadamard symmetry is used to cancel accumulated differences.
            // While asymmetric differences do not cancel out.
            // This means APC on Had is best applied when asymmetric changes are high
            // The use of this Pre-Assessment is devised to initially detect if asymmetric differences exist.
            // If not the remaining process reverts back to the existing Hadamard method.
            // The proposed method is expected to applible about 10% of the time, though this will vary depending upon video/frame content.

            // Distance
            int dist4 = 5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
            int dist2 = 3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
            int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value

            //int TopLeftPx = 0;  // Shared by Left and Top
            int Top = 0, Left = 0;

              // Ignore Corner, this leaves 1-6

            Top += multiscaleAPC[1] = TComRdCost::RCHadAPC((int)diff[1], (int)diff[5], dist4) + TComRdCost::RCHadAPC((int)diff[1], (int)diff[3], dist2);
            Top += multiscaleAPC[2] = TComRdCost::RCHadAPC((int)diff[2], (int)diff[6], dist4) + TComRdCost::RCHadAPC((int)diff[2], (int)diff[3], dist1);
            Top += multiscaleAPC[3] = TComRdCost::RCHadAPC((int)diff[3], (int)diff[7], dist4);
            Top += multiscaleAPC[4] = TComRdCost::RCHadAPC((int)diff[4], (int)diff[6], dist2) + TComRdCost::RCHadAPC((int)diff[4], (int)diff[5], dist1);
            Top += multiscaleAPC[5] = TComRdCost::RCHadAPC((int)diff[5], (int)diff[7], dist2);
            Top += multiscaleAPC[6] = TComRdCost::RCHadAPC((int)diff[6], (int)diff[7], dist1);
            //---


          // Since the first row (0) is done, and the last row (56) will be done later, just do the intervening rows (8, 16, 32, 40, 48)
          for( k = 8; k < 56; k += 8 )
          {
            Left += multiscaleAPC[k] = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+4], dist4)
                                    +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+2], dist2)
                                    +   TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+1], dist1);
          }

          //int BottomLeft = 0; // Shared by Left and Bottom
          int Bottom = 0;
          //---

          // Ignore Corner, this leaves 57-62

          Bottom += multiscaleAPC[57] = TComRdCost::RCHadAPC((int)diff[57], (int)diff[61], dist4) + TComRdCost::RCHadAPC((int)diff[57], (int)diff[59], dist2);
          Bottom += multiscaleAPC[58] = TComRdCost::RCHadAPC((int)diff[58], (int)diff[62], dist4) + TComRdCost::RCHadAPC((int)diff[58], (int)diff[59], dist1);
          Bottom += multiscaleAPC[59] = TComRdCost::RCHadAPC((int)diff[59], (int)diff[63], dist4);
          Bottom += multiscaleAPC[60] = TComRdCost::RCHadAPC((int)diff[60], (int)diff[62], dist2) + TComRdCost::RCHadAPC((int)diff[60], (int)diff[61], dist1);
          Bottom += multiscaleAPC[61] = TComRdCost::RCHadAPC((int)diff[61], (int)diff[63], dist2);
          Bottom += multiscaleAPC[62] = TComRdCost::RCHadAPC((int)diff[62], (int)diff[63], dist1);

          //---

          // ----------
          // Vertical

        //  //---

          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

          int iTemp;

          iTemp = TComRdCost::RCHadAPC((int)diff[8], (int)diff[40], dist4)  + TComRdCost::RCHadAPC((int)diff[8], (int)diff[24], dist2);  Left += iTemp; multiscaleAPC[8] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[16], (int)diff[48], dist4) + TComRdCost::RCHadAPC((int)diff[16], (int)diff[24], dist1); Left += iTemp; multiscaleAPC[16] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[24], (int)diff[56], dist4);                                               Left += iTemp; multiscaleAPC[24] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[32], (int)diff[48], dist2) + TComRdCost::RCHadAPC((int)diff[32], (int)diff[40], dist1); Left += iTemp; multiscaleAPC[32] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[40], (int)diff[56], dist2);                                               Left += iTemp; multiscaleAPC[40] += iTemp;
          iTemp = TComRdCost::RCHadAPC((int)diff[48], (int)diff[56], dist1);                                               Left += iTemp; multiscaleAPC[48] += iTemp;

          //---

          // Similar to before since the top left (0) has been calc for Left and top right (7) will be calc afterwards for Right only those in between need to be calc. (1- 6)
          for( k = 1; k < 7; k++ )
          {
            iTemp = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+32], dist4)
                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+16], dist2)
                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+8], dist1);

            Top += iTemp; multiscaleAPC[k] += iTemp;
          }

          //---

          int Right = 0;

          // Ignore Corner, this leaves 15, 23, 31, 39, 47, 55
          Right += multiscaleAPC[15] =  TComRdCost::RCHadAPC((int)diff[15], (int)diff[47], dist4) +  TComRdCost::RCHadAPC((int)diff[15], (int)diff[31], dist2);
          Right += multiscaleAPC[23] =  TComRdCost::RCHadAPC((int)diff[23], (int)diff[55], dist4) +  TComRdCost::RCHadAPC((int)diff[23], (int)diff[31], dist1);
          Right += multiscaleAPC[31] =  TComRdCost::RCHadAPC((int)diff[31], (int)diff[63], dist4);
          Right += multiscaleAPC[39] =  TComRdCost::RCHadAPC((int)diff[39], (int)diff[55], dist2) +  TComRdCost::RCHadAPC((int)diff[39], (int)diff[47], dist1);
          Right += multiscaleAPC[47] =  TComRdCost::RCHadAPC((int)diff[47], (int)diff[63], dist2);
          Right += multiscaleAPC[55] =  TComRdCost::RCHadAPC((int)diff[55], (int)diff[63], dist1);
          //---
            //-------------------------
            // Now to Test if the full multi-scale APC is required or not

            //bool PerformMsAPC = abs(abs(Top-Bottom) - abs(Left-Right)) > 64 ? true : false;

            // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));


            //if (AbsAsymCost > 28)
            //{

            //    //================================================
            //    //Log Threshold by CU and Frame number

            //    //    ofstream CalcValues;

            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

            //     ofstream ThreshLog;
            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_HAD_RC.txt", ios::out | ios::app);
            //
            //     UInt MaxCUx = width >> 6;
            //     UInt MaxCUy = height >> 6;
            //     UInt CUx = x >> 6;
            //     UInt CUy = y >> 6;

            //     ThreshLog << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

            //     ThreshLog.close();

            //    //================================================
            //}

            // Sun 23rd Nov 2014
            // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
            // Over 48 million observations were logged, which represented 8.7 million unique records.
            UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?

            PerformMsAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

            switch(PerformMsAPC)
            {

                case true:
                {

                //Now the corners

                  //---
                  // Top Left (Horizontal and Vertical)
                  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

                  // Bottom Left only has Horizontal components only
                  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


                  // Top Right only has Vertical components only
                  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

                  // Bottom Right has no components
                  multiscaleAPC[63] = 0; // Always Zero
                //-------------------------

////                  // YGJ 3rd Dec 2014
////                  // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
////                  // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
////                  // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
////                  // Modelling showed that corner test should occur after thresholding, not before or alone.
////                  // This approach is the most effective at shifting and broadening the peak in Had away from zero.
////                  // From 30k sampled observations, 7k were affected, approx 23%.
////                  // In R threshold was 32, divide was done by 6 and count min was >1.
////                  // Here it is the same except that divide is 8.
////                  // When modelled

                  int count = 0;
                  count +=  ((abs(multiscaleAPC[0]) << 1) - ((abs(Top) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
                  count +=  ((abs(multiscaleAPC[7]) << 1) - ((abs(Top) +  abs(Right)) >> 3)) > 0 ? 1 : 0;
                  count +=  ((abs(multiscaleAPC[56]) << 1) - ((abs(Bottom) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
                  //count +=  ((abs(multiscaleAPC[63]) << 1) - ((abs(Bottom) +  abs(Right)) >> 3)) > 0 ? 1 : 0; // Always zero

                  PerformMsAPC = count > 1? true: false;

                }

            }

            switch(PerformMsAPC)
            {

                case true:
                {
                  // Monday 5th January 2015

                  // Edge Detect on APCms, similar to Edfge on SASD calc percetual importance of activity
                  // Then the sum of the edges should be used to produced a weighted APCms score to add to the Had cost

                  // At this point check for edges on APCms block.


                  SumAPCmsEdgeCost += ( (multiscaleAPC[9] << 1) - multiscaleAPC[8] - multiscaleAPC[1]) >  0 ? 1 : 0; // SE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[3] << 1) - multiscaleAPC[2] - multiscaleAPC[11]) >  0 ? 1 : 0; //NE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[24] << 1) - multiscaleAPC[25] - multiscaleAPC[16]) >  0 ? 1 : 0; // SW
                  SumAPCmsEdgeCost += ( (multiscaleAPC[18] << 1) - multiscaleAPC[19] - multiscaleAPC[26]) >  0 ? 1 : 0; // NW

                  SumAPCmsEdgeCost += ( (multiscaleAPC[13] << 1) - multiscaleAPC[12] - multiscaleAPC[5]) >  0 ? 1 : 0; // SE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[7] << 1) - multiscaleAPC[6] - multiscaleAPC[15]) >  0 ? 1 : 0; //NE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[28] << 1) - multiscaleAPC[29] - multiscaleAPC[20]) >  0 ? 1 : 0; // SW
                  SumAPCmsEdgeCost += ( (multiscaleAPC[22] << 1) - multiscaleAPC[23] - multiscaleAPC[30]) >  0 ? 1 : 0; // NW

                  SumAPCmsEdgeCost += ( (multiscaleAPC[41] << 1) - multiscaleAPC[40] - multiscaleAPC[33]) >  0 ? 1 : 0; // SE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[35] << 1) - multiscaleAPC[34] - multiscaleAPC[43]) >  0 ? 1 : 0; //NE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[56] << 1) - multiscaleAPC[57] - multiscaleAPC[48]) >  0 ? 1 : 0; // SW
                  SumAPCmsEdgeCost += ( (multiscaleAPC[50] << 1) - multiscaleAPC[51] - multiscaleAPC[58]) >  0 ? 1 : 0; // NW

                  SumAPCmsEdgeCost += ( (multiscaleAPC[45] << 1) - multiscaleAPC[44] - multiscaleAPC[37]) >  0 ? 1 : 0; // SE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[39] << 1) - multiscaleAPC[38] - multiscaleAPC[47]) >  0 ? 1 : 0; //NE
                  SumAPCmsEdgeCost += ( (multiscaleAPC[60] << 1) - multiscaleAPC[61] - multiscaleAPC[52]) >  0 ? 1 : 0; // SW
                  SumAPCmsEdgeCost += ( (multiscaleAPC[54] << 1) - multiscaleAPC[55] - multiscaleAPC[62]) >  0 ? 1 : 0; // NW

                  //PerformMsAPC = SumAPCmsEdgeCost > 8? true: false; // Triggers on a handful of times
                  //PerformMsAPC = SumAPCmsEdgeCost > 6? true: false; //
                  PerformMsAPC = SumAPCmsEdgeCost > 4? true: false; // Triggers on nearly everything

                }

            }


            //int *ptrAPCDiff;

            switch(PerformMsAPC)
            {

            //case false: ptrAPCDiff = HadAllZero64; break;

            case true:
                {

                    //-------------------------
                    // YGJ Fri 22nd Aug 2014 - Since the jump between pixels is 4 and APC is divided by 2 by default then the APC score should be divided by (4*2), 8, shift by 3.
                    // Since APC LUT violates SSIM and other existing distortion measures use of symmetry, where pixel x vs y is the same as pixel y vs x, choice of which is the reference is important.
                    // Use max for the two pixels to determine the reference point.

                    // YGJ Sat 23rd Aug 2014 - MulitScaled APC Prior to Hadamard - accumulates the various weighted APC/2 scores by different intervals
                    // APC/2, if space of 4, div by 4, if space of 2, div by 2, if space of 1, div by 1.
                    // Repeat for Vertical and then accumulate.
                    // When being used H1, div APC by 8.

                    // Wrong (ignore)-> Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
                    // YGJ Wed 27th Aug 2014 - Correction: RCHadAPC divides by two before it returns the value, just divide by the spacing 4, 2 or 1.
                    //H/V: x, 1/64, 1/16, 1/2
                    // H: 0: (0,4),(0,2),(0,1)
                    // H: 1: (1,5),(1,3),--
                    // H: 2: (2,6),--, (2,3)
                    // H: 3: (3,7),--,--
                    // H: 4: --,(4,6),(4,5)
                    // H: 5: --,(5,7),--
                    // H: 6: --,--,(6,7)
                    // H:7: Always  Zero

                    // First the inner square (block without the edges or corners)



                // Horizontal
                for( k = 8; k < 56; k += 8 )
                {
                  multiscaleAPC[k+1] = TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+5], dist4) + TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+3], dist2);
                  multiscaleAPC[k+2] = TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+6], dist4) + TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+3], dist1);
                  multiscaleAPC[k+3] = TComRdCost::RCHadAPC((int)diff[k+3], (int)diff[k+7], dist4);
                  multiscaleAPC[k+4] = TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+6], dist2) +  TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+5], dist1);
                  multiscaleAPC[k+5] = TComRdCost::RCHadAPC((int)diff[k+5], (int)diff[k+7], dist2);
                  multiscaleAPC[k+6] = TComRdCost::RCHadAPC((int)diff[k+6], (int)diff[k+7], dist1);
                }


                //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
                //H/V: x, 1/8, 1/4, 1/2
                // V: 0: (0,4),(0,2),(0,1)
                // V: 1: (1,5),(1,3),--
                // V: 2: (2,6),--, (2,3)
                // V: 3: (3,7),--,--
                // V: 4: --,(4,6),(4,5)
                // V: 5: --,(5,7),--
                // V: 6: --,--,(6,7)
                // V:7: Always  Zero

                // Vertical
                // Same as Horizontal but now k is from 0 to 7 and k+1/2/3/4/5/6/7 are now k+(1/2/3/4/5/6/7 x 8)
                // Hence it is the same as Horizontal but rotated

                // Remember to increment and not assign/replace existing value

                for( k = 1; k < 7; k++ )
                {
                  multiscaleAPC[k+8] += TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+40], dist4) + TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+24], dist2);
                  multiscaleAPC[k+16] += TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+48], dist4) + TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+24], dist1);
                  multiscaleAPC[k+24] += TComRdCost::RCHadAPC((int)diff[k+24], (int)diff[k+56], dist4);
                  multiscaleAPC[k+32] += TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+48], dist2) + TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+40], dist1);
                  multiscaleAPC[k+40] += TComRdCost::RCHadAPC((int)diff[k+40], (int)diff[k+56], dist2);
                  multiscaleAPC[k+48] += TComRdCost::RCHadAPC((int)diff[k+48], (int)diff[k+56], dist1);
                }

//				//Now the corners

//				  //---
//				  // Top Left (Horizontal and Vertical)
//				  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
//								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
//								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
//								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
//								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
//								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

//				  // Bottom Left only has Horizontal components only
//				  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
//									+ TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
//									+ TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


//				  // Top Right only has Vertical components only
//				  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
//								   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
//								   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

//				  // Bottom Right has no components
//				  multiscaleAPC[63] = 0; // Always Zero
//				//-------------------------

                      //----
                  //ptrAPCDiff = multiscaleAPC;
                }
                break; // End of (if (PerformMsAPC = true))
            }

            // End of Multi-Scale APC
            //=============================
            // Beginning of Hadamard with APC

            //Now to add/subtract to the Hadamard Diff.
            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
            //int APCscale = 0;

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;

              // Additional Pixel Cost (APC) - Add APC to the difference
//			  m2[j][0] = diff[jj  ] + diff[jj+4] + ptrAPCDiff[jj  ];
//			  m2[j][1] = diff[jj+1] + diff[jj+5] + ptrAPCDiff[jj+1];
//			  m2[j][2] = diff[jj+2] + diff[jj+6] + ptrAPCDiff[jj+2];
//			  m2[j][3] = diff[jj+3] + diff[jj+7] + ptrAPCDiff[jj+3];
//			  m2[j][4] = diff[jj  ] - diff[jj+4] + ptrAPCDiff[jj+4];
//			  m2[j][5] = diff[jj+1] - diff[jj+5] + ptrAPCDiff[jj+5];
//			  m2[j][6] = diff[jj+2] - diff[jj+6] + ptrAPCDiff[jj+6];
//			  m2[j][7] = diff[jj+3] - diff[jj+7] + ptrAPCDiff[jj+7];

              m2[j][0] = diff[jj  ] + diff[jj+4];
              m2[j][1] = diff[jj+1] + diff[jj+5];
              m2[j][2] = diff[jj+2] + diff[jj+6];
              m2[j][3] = diff[jj+3] + diff[jj+7];
              m2[j][4] = diff[jj  ] - diff[jj+4];
              m2[j][5] = diff[jj+1] - diff[jj+5];
              m2[j][6] = diff[jj+2] - diff[jj+6];
              m2[j][7] = diff[jj+3] - diff[jj+7];


              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];

//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {

//                      m2APC[j][0] = ptrAPCDiff[jj  ] ;
//                      m2APC[j][1] = ptrAPCDiff[jj+1] ;
//                      m2APC[j][2] = ptrAPCDiff[jj+2] ;
//                      m2APC[j][3] = ptrAPCDiff[jj+3] ;
//                      m2APC[j][4] = - (ptrAPCDiff[jj+4] );
//                      m2APC[j][5] = - (ptrAPCDiff[jj+5] );
//                      m2APC[j][6] = - (ptrAPCDiff[jj+6] );
//                      m2APC[j][7] = - (ptrAPCDiff[jj+7] );

//                      m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
//                      m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
//                      m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
//                      m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
//                      m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
//                      m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
//                      m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
//                      m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

//                      m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
//                      m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
//                      m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
//                      m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
//                      m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
//                      m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
//                      m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
//                      m2APC[j][7] = m1APC[j][6] - m1APC[j][7];

//                      }
//              }


            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];


//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {
//                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
//                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
//                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
//                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
//                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
//                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
//                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
//                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

//                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
//                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
//                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
//                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
//                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
//                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
//                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
//                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

//                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
//                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
//                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
//                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
//                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
//                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
//                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
//                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];

//                      }
//              }



            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
                iSumHadAPC += PerformMsAPC == true? abs(multiscaleAPC[i + (j << 3)]) : 0;
              }
            }
            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
            iSumHad =(iSumHad+2)>>2;

            iSumHadAPC -= PerformMsAPC == true? abs(multiscaleAPC[0]) : 0;
            iSumHadAPC =(iSumHadAPC+2)>>2;




//            //////////////////////////
//            // YGJ 5th Jan 2015
//            // Non-Overlapping 8x8, to be more like Rate Control
//            // Use mod to only operate every 8x8 block
//            // The output will look messy but should reflect how RC works on judging activity
//            if ((y%8 == 0) && (x%8 == 0))
//            {
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Save as previous values

//            PrevHad = iSumHad;
//            PrevAPCms = iSumHadAPC;
//            PrevBoolPerformAPCms = PerformMsAPC;


            ////

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;
            ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)] = iSumHadAPC;
            ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)] = PerformMsAPC;

//            }
//            else
//            {
//                //////////////////////////
//                // YGJ 5th Jan 2015
//                // Non-Overlapping 8x8, to be more like Rate Control
//                // Use previous values

//                iSumHad = PrevHad;
//                iSumHadAPC = PrevAPCms;
//                PerformMsAPC = PrevBoolPerformAPCms;
//            }

        }
        else if ((y%8 != 0) || (x%8 != 0))
        {
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Use previous values

//            iSumHad = PrevHad;
//            iSumHadAPC = PrevAPCms;
//            PerformMsAPC = PrevBoolPerformAPCms;

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            iSumHadAPC = ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)];
            PerformMsAPC = ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)];
        }


        yInt = yInt_Org;


         int r=0, g=0, b=0;

        //if (HadRegion == true)

        //if (PerformMsAPC == true)

         //if (SumAPCmsEdgeCost < 8)
         //iSumHadAPC >>= 3;

         if (iSumHadAPC < 256)
             PerformMsAPC = false;
         //if (iSumHadAPC < 192)
//            iSumHad +=  iSumHadAPC >> 1;
//         else
         //    PerformMsAPC = false;



        if (PerformMsAPC == true)
        {


            //------------------

            int blkwidth = 8;

            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            //float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); //Not applicable

            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

            // For Rate-Control
            halfMaxThreshold <<= 1; // Double

            // Divide APC cost by 1/2 Blk size before adding to Had cost
            //iSumHadAPC = iSumHadAPC/(blksz >> 1);

            iSumHadAPC  = SumAPCmsEdgeCost > 8? iSumHadAPC : SumAPCmsEdgeCost > 4? iSumHadAPC >> 1 : iSumHadAPC >> 2;
            //iSumHadAPC  = SumAPCmsEdgeCost > 8? iSumHadAPC >> 3 : 0; //: SumAPCmsEdgeCost > 4? iSumHadAPC >> 2 : iSumHadAPC >> 3;

            //iSumHad += iSumHadAPC;
            //iSumHad += iSumHadAPC >> 1;

            //iSumHad += iSumHadAPC > 256? iSumHadAPC >> 1 : 0;
            //iSumHad += iSumHadAPC > 512? iSumHadAPC >> 1 : 0;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//            int val = dist < (halfMaxThreshold >> 2) ? 0
//                : dist < (halfMaxThreshold >> 1) ? 1
//                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("RateControl Pre Assess Had with Multiscale-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
                halfMaxThreshold, iSumHad, halfMaxThreshold);
						
            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;
			
            //------------------


            //switch (val)
            //{
            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
            //		break;
            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
            //		break;
            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //}

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      piY_Org += YStride;
      piY_Part += YStrideRec;

    }

    free(ptrY_Org8x8);

    free(ptrY_Org);

    free(ptrY_Part);

    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}


//Void TAppDecTop::saveFrameAsPNG_RCHadPreAssess_wCornerTest_MS_APC(TComPic* pcPic)
////Void TAppDecTop::saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  //char strFactor[8];

//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  //strcat(SSIMHeatmap, "DecFrm_RCActivity_PreAssess_wCornerTestwEdgeScle_MSAPCHadActiHeatMap_");
//  strcat(SSIMHeatmap, "DecFrm_RCActivity_PreAssess_wCornerTest_MSAPCHadActiHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//    for ( unsigned y = 0; y < height; y++ )
//    //for ( unsigned y = 0; y < height; y+=8 )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      //  for ( unsigned x = 0; x < width; x+=8 )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0; //, uInt = 0, vInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
////        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
////        int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);


//        //bool HadRegion = false;
//        Distortion iSumHad =0;
//        Distortion iSumHadAPC = 0;
//        bool PerformMsAPC = false;
//        int SumAPCmsEdgeCost = 0;

//        Pel *diff;
//        int i, j, jj, k;
//        //int blksz = 64;


//        if ((y < (height-8)) && (x < (width-8)))
//        {
//          //HadRegion = true;

////          Distortion diff[64];
//          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//          Int m1APC[8][8], m2APC[8][8], m3APC[8][8]; //, iSumHadAPC = 0;
//          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.



//            for ( unsigned n = 0; n < 8; n++ )
//            {
//                for ( unsigned m = 0; m < 8; m++ )
//                {
//                    unsigned yloc8x8 = n*m+m;

//                    ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

//                }
//            }

//            diff = ptrY_Org8x8;

//            //-------------------------

//            // YGJ Sun 24th Aug 2014 - Pre Assessment to determine whether multi-scale APC is justified
//            // Calc APC for Top, Bottom, Left and Right side of 8x8 (First and Last Row and Columns)
//            // Note that APC is calculated by accessing the Look Up Table (LUT).
//            // While in SAD, APC can be accumulated then divided by 2, here the LUT used, (APC_NegAndPos_1D) via the function (RCHadAPC) has the values already divided by 2.
//            // However, in multi-scale APC they must be divided by their interval, which APC_NegAndPos_1D will perform by entering the number bits to shift by.
//            //
//            // Multi-scale APC does require significant amount of processing.
//            // Under rate-control this will occur when a new Group of Pictures (GOP) sequence requires the bit-rate to be budgetted by frame/slice type.
//            // Regardless, applying multi-scale APC irrespectively, can increase processing demand unnecessarily.
//            // Also, hadamard transform employs symmetry to elminate/minimise accumulated differences.
//            // Applying a test for asymmetrical perceptual changes can then differieniate when multi-scale is suitable to apply and limiting the use of additional complexity till then.
//            //
//            // A non-symmetrical distribution of two regions in a block can affect the percpetual rate of change along one of the edges of the block.
//            // By subtracting opposing edges from each other any dominant edge, where the perceptual rate of change is far higher than the others will be shown.
//            // The threshold by which the resulting value should tested against should be the block size, in this case, 8x8 = 64.
//            // If (abs(abs(T-B) - abs(L-R)) > 64
//            // In general, this should make the processing more adaptive/dynamic, only applying multi-scale APC  according to the level of asymmetric boundary changes where the intensity (Luma) is high.
//            // Expect processing demand to vary depending upon the scene in question.
//            // Based upon simulations based observations gathered from the first frame of Race Horses video (416 x 240) where 1560 samples are processed, one per 8x8 block region, the need to called multi-scale APC can be reduced by 2/3.

//            //----

//            // First calc Horizontal
//            // For Top and Left this their initial cost (stage 1 of 2).
//            // For Bottom it is the only time it will be updated (1 of 1).
//            // For Right it will be set during vertical (0 of 1).

//            //-----

//            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//            //H/V: x, 1/8, 1/4, 1/2
//            // H: 0: (0,4),(0,2),(0,1)
//            // H: 1: (1,5),(1,3),--
//            // H: 2: (2,6),--, (2,3)
//            // H: 3: (3,7),--,--
//            // H: 4: --,(4,6),(4,5)
//            // H: 5: --,(5,7),--
//            // H: 6: --,--,(6,7)
//            // H:7: Always  Zero

//            // This means for Top and Bottom the above is correct.
//            // For  Left    // H: 0: (0,4),(0,2),(0,1) needs to be performed.
//            // For Right as stated it is // H:7: Always  Zero

//            //-----

//            // Second  calc Vertical
//            // Like Horizontal but now for the others are updated/completed.
//            // Top and Left are completed
//            // Right is updated.

//            //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//            //H/V: x, 1/8, 1/4, 1/2
//            // V: 0: (0,4),(0,2),(0,1)
//            // V: 1: (1,5),(1,3),--
//            // V: 2: (2,6),--, (2,3)
//            // V: 3: (3,7),--,--
//            // V: 4: --,(4,6),(4,5)
//            // V: 5: --,(5,7),--
//            // V: 6: --,--,(6,7)
//            // V:7: Always  Zero

//            // For Left and Right the above is correct
//            // Top -  // V: 0: (0,4),(0,2),(0,1)
//            // Bottom - // V:7: Always  Zero

//            //-----

//            // Now to check if full multi-scale APC is required of Hadamard is sufficient
//            // If (abs(abs(Top-Bottom) - abs(Left-Right)) > 64 then perform multii-scale APC.
//            // Multi-scale APC has a high score where boundary changes occur where  Luma intensity is high.
//            // Hadamard is suited for where symmetrical differences exist.
//            // Thus, multi-scale APC is suited for where asymmetric boundary changes occur for high Luma 8x8 blocks.
//            // It is possible that the top left corner pixel can strongly influence both Top and Left.
//            // To avoid the top left corner pixel affecting the scores, the test for full multi-scale APC is a series of differences.
//            // Furthermore, the threshold of 64 is sufficiently low enough to allow a range of potential candidates for the full multi-scale APC.

//            //---------------

//            // YGJ Wed 27th Aug 2014
//            // Pre-Assessment Test for multi-scale APC
//            // Just the sides without corners.
//            // Assuming perceptual information is continuous and may cross over blocksizes.
//            // If the change on the edges are high then they is likley asymmetric change in the block.
//            // For Hadamard symmetry is used to cancel accumulated differences.
//            // While asymmetric differences do not cancel out.
//            // This means APC on Had is best applied when asymmetric changes are high
//            // The use of this Pre-Assessment is devised to initially detect if asymmetric differences exist.
//            // If not the remaining process reverts back to the existing Hadamard method.
//            // The proposed method is expected to applible about 10% of the time, though this will vary depending upon video/frame content.

//            // Distance
//            int dist4 = 5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
//            int dist2 = 3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
//            int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value

//            //int TopLeftPx = 0;  // Shared by Left and Top
//            int Top = 0, Left = 0;

//              // Ignore Corner, this leaves 1-6

//            Top += multiscaleAPC[1] = TComRdCost::RCHadAPC((int)diff[1], (int)diff[5], dist4) + TComRdCost::RCHadAPC((int)diff[1], (int)diff[3], dist2);
//            Top += multiscaleAPC[2] = TComRdCost::RCHadAPC((int)diff[2], (int)diff[6], dist4) + TComRdCost::RCHadAPC((int)diff[2], (int)diff[3], dist1);
//            Top += multiscaleAPC[3] = TComRdCost::RCHadAPC((int)diff[3], (int)diff[7], dist4);
//            Top += multiscaleAPC[4] = TComRdCost::RCHadAPC((int)diff[4], (int)diff[6], dist2) + TComRdCost::RCHadAPC((int)diff[4], (int)diff[5], dist1);
//            Top += multiscaleAPC[5] = TComRdCost::RCHadAPC((int)diff[5], (int)diff[7], dist2);
//            Top += multiscaleAPC[6] = TComRdCost::RCHadAPC((int)diff[6], (int)diff[7], dist1);
//            //---


//          // Since the first row (0) is done, and the last row (56) will be done later, just do the intervening rows (8, 16, 32, 40, 48)
//          for( k = 8; k < 56; k += 8 )
//          {
//            Left += multiscaleAPC[k] = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+4], dist4)
//                                    +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+2], dist2)
//                                    +   TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+1], dist1);
//          }

//          //int BottomLeft = 0; // Shared by Left and Bottom
//          int Bottom = 0;
//          //---

//          // Ignore Corner, this leaves 57-62

//          Bottom += multiscaleAPC[57] = TComRdCost::RCHadAPC((int)diff[57], (int)diff[61], dist4) + TComRdCost::RCHadAPC((int)diff[57], (int)diff[59], dist2);
//          Bottom += multiscaleAPC[58] = TComRdCost::RCHadAPC((int)diff[58], (int)diff[62], dist4) + TComRdCost::RCHadAPC((int)diff[58], (int)diff[59], dist1);
//          Bottom += multiscaleAPC[59] = TComRdCost::RCHadAPC((int)diff[59], (int)diff[63], dist4);
//          Bottom += multiscaleAPC[60] = TComRdCost::RCHadAPC((int)diff[60], (int)diff[62], dist2) + TComRdCost::RCHadAPC((int)diff[60], (int)diff[61], dist1);
//          Bottom += multiscaleAPC[61] = TComRdCost::RCHadAPC((int)diff[61], (int)diff[63], dist2);
//          Bottom += multiscaleAPC[62] = TComRdCost::RCHadAPC((int)diff[62], (int)diff[63], dist1);

//          //---

//          // ----------
//          // Vertical

//        //  //---

//          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//          int iTemp;

//          iTemp = TComRdCost::RCHadAPC((int)diff[8], (int)diff[40], dist4)  + TComRdCost::RCHadAPC((int)diff[8], (int)diff[24], dist2);  Left += iTemp; multiscaleAPC[8] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[16], (int)diff[48], dist4) + TComRdCost::RCHadAPC((int)diff[16], (int)diff[24], dist1); Left += iTemp; multiscaleAPC[16] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[24], (int)diff[56], dist4);                                               Left += iTemp; multiscaleAPC[24] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[32], (int)diff[48], dist2) + TComRdCost::RCHadAPC((int)diff[32], (int)diff[40], dist1); Left += iTemp; multiscaleAPC[32] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[40], (int)diff[56], dist2);                                               Left += iTemp; multiscaleAPC[40] += iTemp;
//          iTemp = TComRdCost::RCHadAPC((int)diff[48], (int)diff[56], dist1);                                               Left += iTemp; multiscaleAPC[48] += iTemp;

//          //---

//          // Similar to before since the top left (0) has been calc for Left and top right (7) will be calc afterwards for Right only those in between need to be calc. (1- 6)
//          for( k = 1; k < 7; k++ )
//          {
//            iTemp = TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+32], dist4)
//                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+16], dist2)
//                 +  TComRdCost::RCHadAPC((int)diff[k  ], (int)diff[k+8], dist1);

//            Top += iTemp; multiscaleAPC[k] += iTemp;
//          }

//          //---

//          int Right = 0;

//          // Ignore Corner, this leaves 15, 23, 31, 39, 47, 55
//          Right += multiscaleAPC[15] =  TComRdCost::RCHadAPC((int)diff[15], (int)diff[47], dist4) +  TComRdCost::RCHadAPC((int)diff[15], (int)diff[31], dist2);
//          Right += multiscaleAPC[23] =  TComRdCost::RCHadAPC((int)diff[23], (int)diff[55], dist4) +  TComRdCost::RCHadAPC((int)diff[23], (int)diff[31], dist1);
//          Right += multiscaleAPC[31] =  TComRdCost::RCHadAPC((int)diff[31], (int)diff[63], dist4);
//          Right += multiscaleAPC[39] =  TComRdCost::RCHadAPC((int)diff[39], (int)diff[55], dist2) +  TComRdCost::RCHadAPC((int)diff[39], (int)diff[47], dist1);
//          Right += multiscaleAPC[47] =  TComRdCost::RCHadAPC((int)diff[47], (int)diff[63], dist2);
//          Right += multiscaleAPC[55] =  TComRdCost::RCHadAPC((int)diff[55], (int)diff[63], dist1);
//          //---
//            //-------------------------
//            // Now to Test if the full multi-scale APC is required or not

//            //bool PerformMsAPC = abs(abs(Top-Bottom) - abs(Left-Right)) > 64 ? true : false;

//            // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//            UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));


//            //if (AbsAsymCost > 28)
//            //{

//            //    //================================================
//            //    //Log Threshold by CU and Frame number

//            //    //    ofstream CalcValues;

//            //    //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//            //     ofstream ThreshLog;
//            //     ThreshLog.open ("ThresholdLog_Dec_PreAssess_HAD_RC.txt", ios::out | ios::app);
//            //
//            //     UInt MaxCUx = width >> 6;
//            //     UInt MaxCUy = height >> 6;
//            //     UInt CUx = x >> 6;
//            //     UInt CUy = y >> 6;

//            //     ThreshLog << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//            //     ThreshLog.close();

//            //    //================================================
//            //}

//            // Sun 23rd Nov 2014
//            // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
//            // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//            // Over 48 million observations were logged, which represented 8.7 million unique records.
//            UInt Threshold = 48; //28; // Does a threshold of 28 sufficient as 16?

//            PerformMsAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//            switch(PerformMsAPC)
//            {

//                case true:
//                {

//                //Now the corners

//                  //---
//                  // Top Left (Horizontal and Vertical)
//                  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

//                  // Bottom Left only has Horizontal components only
//                  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
//                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
//                                    + TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


//                  // Top Right only has Vertical components only
//                  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
//                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
//                                   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

//                  // Bottom Right has no components
//                  multiscaleAPC[63] = 0; // Always Zero
//                //-------------------------

//                  // YGJ 3rd Dec 2014
//                  // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
//                  // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
//                  // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
//                  // Modelling showed that corner test should occur after thresholding, not before or alone.
//                  // This approach is the most effective at shifting and broadening the peak in Had away from zero.
//                  // From 30k sampled observations, 7k were affected, approx 23%.
//                  // In R threshold was 32, divide was done by 6 and count min was >1.
//                  // Here it is the same except that divide is 8.
//                  // When modelled

//                  int count = 0;
//                  count +=  ((abs(multiscaleAPC[0]) << 1) - ((abs(Top) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
//                  count +=  ((abs(multiscaleAPC[7]) << 1) - ((abs(Top) +  abs(Right)) >> 3)) > 0 ? 1 : 0;
//                  count +=  ((abs(multiscaleAPC[56]) << 1) - ((abs(Bottom) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
//                  //count +=  ((abs(multiscaleAPC[63]) << 1) - ((abs(Bottom) +  abs(Right)) >> 3)) > 0 ? 1 : 0; // Always zero

//                  PerformMsAPC = count > 1? true: false;

//                }

//            }

//            int *ptrAPCDiff;

//            switch(PerformMsAPC)
//            {

//            case false: ptrAPCDiff = HadAllZero64; break;

//            case true:
//                {

//                    //-------------------------
//                    // YGJ Fri 22nd Aug 2014 - Since the jump between pixels is 4 and APC is divided by 2 by default then the APC score should be divided by (4*2), 8, shift by 3.
//                    // Since APC LUT violates SSIM and other existing distortion measures use of symmetry, where pixel x vs y is the same as pixel y vs x, choice of which is the reference is important.
//                    // Use max for the two pixels to determine the reference point.

//                    // YGJ Sat 23rd Aug 2014 - MulitScaled APC Prior to Hadamard - accumulates the various weighted APC/2 scores by different intervals
//                    // APC/2, if space of 4, div by 4, if space of 2, div by 2, if space of 1, div by 1.
//                    // Repeat for Vertical and then accumulate.
//                    // When being used H1, div APC by 8.

//                    // Wrong (ignore)-> Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//                    // YGJ Wed 27th Aug 2014 - Correction: RCHadAPC divides by two before it returns the value, just divide by the spacing 4, 2 or 1.
//                    //H/V: x, 1/64, 1/16, 1/2
//                    // H: 0: (0,4),(0,2),(0,1)
//                    // H: 1: (1,5),(1,3),--
//                    // H: 2: (2,6),--, (2,3)
//                    // H: 3: (3,7),--,--
//                    // H: 4: --,(4,6),(4,5)
//                    // H: 5: --,(5,7),--
//                    // H: 6: --,--,(6,7)
//                    // H:7: Always  Zero

//                    // First the inner square (block without the edges or corners)



//                // Horizontal
//                for( k = 8; k < 56; k += 8 )
//                {
//                  multiscaleAPC[k+1] = TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+5], dist4) + TComRdCost::RCHadAPC((int)diff[k+1], (int)diff[k+3], dist2);
//                  multiscaleAPC[k+2] = TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+6], dist4) + TComRdCost::RCHadAPC((int)diff[k+2], (int)diff[k+3], dist1);
//                  multiscaleAPC[k+3] = TComRdCost::RCHadAPC((int)diff[k+3], (int)diff[k+7], dist4);
//                  multiscaleAPC[k+4] = TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+6], dist2) +  TComRdCost::RCHadAPC((int)diff[k+4], (int)diff[k+5], dist1);
//                  multiscaleAPC[k+5] = TComRdCost::RCHadAPC((int)diff[k+5], (int)diff[k+7], dist2);
//                  multiscaleAPC[k+6] = TComRdCost::RCHadAPC((int)diff[k+6], (int)diff[k+7], dist1);
//                }


//                //Since  APC/2 is used this means APC/8, APC/4 and APC/2 is applied for spacing of 4, 2 and 1.
//                //H/V: x, 1/8, 1/4, 1/2
//                // V: 0: (0,4),(0,2),(0,1)
//                // V: 1: (1,5),(1,3),--
//                // V: 2: (2,6),--, (2,3)
//                // V: 3: (3,7),--,--
//                // V: 4: --,(4,6),(4,5)
//                // V: 5: --,(5,7),--
//                // V: 6: --,--,(6,7)
//                // V:7: Always  Zero

//                // Vertical
//                // Same as Horizontal but now k is from 0 to 7 and k+1/2/3/4/5/6/7 are now k+(1/2/3/4/5/6/7 x 8)
//                // Hence it is the same as Horizontal but rotated

//                // Remember to increment and not assign/replace existing value

//                for( k = 1; k < 7; k++ )
//                {
//                  multiscaleAPC[k+8] += TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+40], dist4) + TComRdCost::RCHadAPC((int)diff[k+8], (int)diff[k+24], dist2);
//                  multiscaleAPC[k+16] += TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+48], dist4) + TComRdCost::RCHadAPC((int)diff[k+16], (int)diff[k+24], dist1);
//                  multiscaleAPC[k+24] += TComRdCost::RCHadAPC((int)diff[k+24], (int)diff[k+56], dist4);
//                  multiscaleAPC[k+32] += TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+48], dist2) + TComRdCost::RCHadAPC((int)diff[k+32], (int)diff[k+40], dist1);
//                  multiscaleAPC[k+40] += TComRdCost::RCHadAPC((int)diff[k+40], (int)diff[k+56], dist2);
//                  multiscaleAPC[k+48] += TComRdCost::RCHadAPC((int)diff[k+48], (int)diff[k+56], dist1);
//                }

////				//Now the corners

////				  //---
////				  // Top Left (Horizontal and Vertical)
////				  multiscaleAPC[0] = TComRdCost::RCHadAPC((int)diff[0], (int)diff[4], dist4)
////								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[2], dist2)
////								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[1], dist1)
////								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[32], dist4)
////								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[16], dist2)
////								   + TComRdCost::RCHadAPC((int)diff[0], (int)diff[8], dist1);

////				  // Bottom Left only has Horizontal components only
////				  multiscaleAPC[56] = TComRdCost::RCHadAPC((int)diff[56], (int)diff[60], dist4)
////									+ TComRdCost::RCHadAPC((int)diff[56], (int)diff[58], dist2)
////									+ TComRdCost::RCHadAPC((int)diff[56], (int)diff[57], dist1);


////				  // Top Right only has Vertical components only
////				  multiscaleAPC[7] = TComRdCost::RCHadAPC((int)diff[7], (int)diff[39], dist4)
////								   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[23], dist2)
////								   + TComRdCost::RCHadAPC((int)diff[7], (int)diff[15], dist1);

////				  // Bottom Right has no components
////				  multiscaleAPC[63] = 0; // Always Zero
////				//-------------------------

//                      //----
//                  ptrAPCDiff = multiscaleAPC;

//                  //-----------------------------------

//                  // YGJ 5th Jan 2015
//                  // Edge Detection like SASD with APC values

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[9] << 1) - multiscaleAPC[8] - multiscaleAPC[1]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[3] << 1) - multiscaleAPC[2] - multiscaleAPC[11]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[24] << 1) - multiscaleAPC[25] - multiscaleAPC[16]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[18] << 1) - multiscaleAPC[19] - multiscaleAPC[26]) >  0 ? 1 : 0; // NW

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[13] << 1) - multiscaleAPC[12] - multiscaleAPC[5]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[7] << 1) - multiscaleAPC[6] - multiscaleAPC[15]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[28] << 1) - multiscaleAPC[29] - multiscaleAPC[20]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[22] << 1) - multiscaleAPC[23] - multiscaleAPC[30]) >  0 ? 1 : 0; // NW

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[41] << 1) - multiscaleAPC[40] - multiscaleAPC[33]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[35] << 1) - multiscaleAPC[34] - multiscaleAPC[43]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[56] << 1) - multiscaleAPC[57] - multiscaleAPC[48]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[50] << 1) - multiscaleAPC[51] - multiscaleAPC[58]) >  0 ? 1 : 0; // NW

//                  SumAPCmsEdgeCost += ( (multiscaleAPC[45] << 1) - multiscaleAPC[44] - multiscaleAPC[37]) >  0 ? 1 : 0; // SE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[39] << 1) - multiscaleAPC[38] - multiscaleAPC[47]) >  0 ? 1 : 0; //NE
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[60] << 1) - multiscaleAPC[61] - multiscaleAPC[52]) >  0 ? 1 : 0; // SW
//                  SumAPCmsEdgeCost += ( (multiscaleAPC[54] << 1) - multiscaleAPC[55] - multiscaleAPC[62]) >  0 ? 1 : 0; // NW



//                }
//                break; // End of (if (PerformMsAPC = true))
//            }

//            // End of Multi-Scale APC
//            //=============================
//            // Beginning of Hadamard with APC

//            //Now to add/subtract to the Hadamard Diff.
//            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
//            //int APCscale = 0;

//            //horizontal
//            for (j=0; j < 8; j++)
//            {
//              jj = j << 3;

//              // Additional Pixel Cost (APC) - Add APC to the difference
////			  m2[j][0] = diff[jj  ] + diff[jj+4] + ptrAPCDiff[jj  ];
////			  m2[j][1] = diff[jj+1] + diff[jj+5] + ptrAPCDiff[jj+1];
////			  m2[j][2] = diff[jj+2] + diff[jj+6] + ptrAPCDiff[jj+2];
////			  m2[j][3] = diff[jj+3] + diff[jj+7] + ptrAPCDiff[jj+3];
////			  m2[j][4] = diff[jj  ] - diff[jj+4] + ptrAPCDiff[jj+4];
////			  m2[j][5] = diff[jj+1] - diff[jj+5] + ptrAPCDiff[jj+5];
////			  m2[j][6] = diff[jj+2] - diff[jj+6] + ptrAPCDiff[jj+6];
////			  m2[j][7] = diff[jj+3] - diff[jj+7] + ptrAPCDiff[jj+7];

//              m2[j][0] = diff[jj  ] + diff[jj+4];
//              m2[j][1] = diff[jj+1] + diff[jj+5];
//              m2[j][2] = diff[jj+2] + diff[jj+6];
//              m2[j][3] = diff[jj+3] + diff[jj+7];
//              m2[j][4] = diff[jj  ] - diff[jj+4];
//              m2[j][5] = diff[jj+1] - diff[jj+5];
//              m2[j][6] = diff[jj+2] - diff[jj+6];
//              m2[j][7] = diff[jj+3] - diff[jj+7];


//              m1[j][0] = m2[j][0] + m2[j][2];
//              m1[j][1] = m2[j][1] + m2[j][3];
//              m1[j][2] = m2[j][0] - m2[j][2];
//              m1[j][3] = m2[j][1] - m2[j][3];
//              m1[j][4] = m2[j][4] + m2[j][6];
//              m1[j][5] = m2[j][5] + m2[j][7];
//              m1[j][6] = m2[j][4] - m2[j][6];
//              m1[j][7] = m2[j][5] - m2[j][7];

//              m2[j][0] = m1[j][0] + m1[j][1];
//              m2[j][1] = m1[j][0] - m1[j][1];
//              m2[j][2] = m1[j][2] + m1[j][3];
//              m2[j][3] = m1[j][2] - m1[j][3];
//              m2[j][4] = m1[j][4] + m1[j][5];
//              m2[j][5] = m1[j][4] - m1[j][5];
//              m2[j][6] = m1[j][6] + m1[j][7];
//              m2[j][7] = m1[j][6] - m1[j][7];

//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {

//                      m2APC[j][0] = ptrAPCDiff[jj  ] ;
//                      m2APC[j][1] = ptrAPCDiff[jj+1] ;
//                      m2APC[j][2] = ptrAPCDiff[jj+2] ;
//                      m2APC[j][3] = ptrAPCDiff[jj+3] ;
//                      m2APC[j][4] = - (ptrAPCDiff[jj+4] );
//                      m2APC[j][5] = - (ptrAPCDiff[jj+5] );
//                      m2APC[j][6] = - (ptrAPCDiff[jj+6] );
//                      m2APC[j][7] = - (ptrAPCDiff[jj+7] );

//                      m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
//                      m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
//                      m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
//                      m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
//                      m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
//                      m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
//                      m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
//                      m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

//                      m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
//                      m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
//                      m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
//                      m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
//                      m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
//                      m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
//                      m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
//                      m2APC[j][7] = m1APC[j][6] - m1APC[j][7];

//                      }
//              }


//            }

//            //vertical
//            for (i=0; i < 8; i++)
//            {
//              m3[0][i] = m2[0][i] + m2[4][i];
//              m3[1][i] = m2[1][i] + m2[5][i];
//              m3[2][i] = m2[2][i] + m2[6][i];
//              m3[3][i] = m2[3][i] + m2[7][i];
//              m3[4][i] = m2[0][i] - m2[4][i];
//              m3[5][i] = m2[1][i] - m2[5][i];
//              m3[6][i] = m2[2][i] - m2[6][i];
//              m3[7][i] = m2[3][i] - m2[7][i];

//              m1[0][i] = m3[0][i] + m3[2][i];
//              m1[1][i] = m3[1][i] + m3[3][i];
//              m1[2][i] = m3[0][i] - m3[2][i];
//              m1[3][i] = m3[1][i] - m3[3][i];
//              m1[4][i] = m3[4][i] + m3[6][i];
//              m1[5][i] = m3[5][i] + m3[7][i];
//              m1[6][i] = m3[4][i] - m3[6][i];
//              m1[7][i] = m3[5][i] - m3[7][i];

//              m2[0][i] = m1[0][i] + m1[1][i];
//              m2[1][i] = m1[0][i] - m1[1][i];
//              m2[2][i] = m1[2][i] + m1[3][i];
//              m2[3][i] = m1[2][i] - m1[3][i];
//              m2[4][i] = m1[4][i] + m1[5][i];
//              m2[5][i] = m1[4][i] - m1[5][i];
//              m2[6][i] = m1[6][i] + m1[7][i];
//              m2[7][i] = m1[6][i] - m1[7][i];


//              //---------------------
//              // Now for Had on APC
//              switch(PerformMsAPC)
//              {
//              case true:
//                      {
//                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
//                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
//                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
//                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
//                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
//                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
//                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
//                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

//                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
//                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
//                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
//                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
//                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
//                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
//                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
//                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

//                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
//                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
//                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
//                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
//                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
//                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
//                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
//                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];

//                      }
//              }



//            }

//            for (i = 0; i < 8; i++)
//            {
//              for (j = 0; j < 8; j++)
//              {
//                iSumHad += abs(m2[i][j]);
//                iSumHadAPC += PerformMsAPC == true? abs(m2APC[i][j]) : 0;
//              }
//            }
//            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
//            iSumHad =(iSumHad+2)>>2;

//            iSumHadAPC -= PerformMsAPC == true? abs(m2APC[0][0]) : 0;
//            iSumHadAPC =(iSumHadAPC+2)>>2;


//        }

//        yInt = yInt_Org;


//         int r=0, g=0, b=0;

//        //if (HadRegion == true)
//        if (PerformMsAPC == true)
//        {


//            //------------------

//            int blkwidth = 8;

//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = (int)log2((double)blkwidth) - 3;

//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            //float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); //Not applicable

//            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//            // For Rate-Control
//            halfMaxThreshold <<= 1; // Double

//            //int blksz = 64;

//            // Divide APC cost by 1/2 Blk size before adding to Had cost
//            //iSumHadAPC = iSumHadAPC/(blksz >> 1);

//            //iSumHadAPC = iSumHadAPC/(4 - (SumAPCmsEdgeCost >> 2));
//            //iSumHadAPC = iSumHadAPC/(8 - (SumAPCmsEdgeCost >> 1));

//            //iSumHadAPC = iSumHadAPC/(4 - (SumAPCmsEdgeCost >> 2)) - iSumHadAPC/(8 - (SumAPCmsEdgeCost >> 1));
//            iSumHadAPC = iSumHadAPC/(16 - SumAPCmsEdgeCost);

//            iSumHad += iSumHadAPC;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////            int val = dist < (halfMaxThreshold >> 2) ? 0
////                : dist < (halfMaxThreshold >> 1) ? 1
////                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("RateControl Pre Assess Had with Multiscale-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);

//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;

//            //------------------


//            //switch (val)
//            //{
//            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//            //		break;
//            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//            //		break;
//            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //}

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt;
//        }


//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//        // Partitioning -- Working
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0; //yInt_RmO;
//          g = 0; //yInt_RmO;
//          b = 0; //yInt_RmO;
//        }



//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      piY_Org += YStride;
//      piY_Part += YStrideRec;

//    }

//    free(ptrY_Org8x8);

//    free(ptrY_Org);

//    free(ptrY_Part);

//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//}


// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
// YGJ 15th Sept 2014
// Like saveFrameAsPNG_RCHadw_MS_APC, but here the reconstructed video is used.
// Note that since the Had technique is slightly different therefore so is the range of scores and so the scaling must be adjusted.



//Void TAppDecTop::saveFrameAsPNG_Had4x4wAPC(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_Had4x4wAPC_DistortionHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0; //, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//		bool HadRegion = false;
//		Distortion iSumHad =0;

//		if ((y < (height-4)) && (x < (width-4)))
//		{
//		  HadRegion = true;


//		  for ( unsigned n = 0; n < 4; n++ )
//		  {
//			  for ( unsigned m = 0; m < 4; m++ )
//			  {
//				  // y*width + x
//				  unsigned yloc4x4 = n*4+m;

//				  //Distortion y_Org =
//				  ptrY_Org8x8[yloc4x4] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//				  //Distortion y_Rec =
//				  ptrY_Rec8x8[yloc4x4] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//				  ////------------------
//				  //// YGJ 12th July 2014
//				  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
//				  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//				  //// a -- set up and initialise variables

//				  ////------------------

//			  }
//		  }


//		  //int HadDiff[64];
//		  //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
//		  //TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//		  //Int APCVal[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//		  //Int OrgPx[64], RecPx[64];

//		  // Here Had with integrated APC is applied based upon a pre-assessment.
//		  // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
//		  // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
//		  // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
//		  // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.

//		  Int iStrideOrg = 4;
//		  Int iStrideCur = 4;

//		  Int k; //, i, j, jj;
//		  // Used now
//		  Pel* piOrg = ptrY_Org8x8; //piOrg;
//		  Pel* piCur = ptrY_Rec8x8; //piCur;
//		  // Used later
//		  Pel* myOrg = ptrY_Org8x8; //piOrg;
//		  Pel* myCur = ptrY_Rec8x8; //piCur;
//		  //
//		  Int APCVal[16];
//		  Int iTemp = 0;  // Usomg Int here as difference may be negative.
//		  //UInt BitDiff = (g_bitDepth[0]-8); // Used in scaling down SAD when higher bit depths are used, applied at the total. Similar to SSE to support higher bit depths

//		  // YGJ 21st Aug 2014
//		  Int HadDiff[16];

//		  //---------
//		  // YGJ Mon 25th Aug 2014
//		  // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
//		  // If asymmetrical then proceed with APCwHad else just perform Had.
//		  // Note the plus 255 is required to centre it at zero

//		  // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
//		  //---

//		  // piCur and piOrg Already initialised to the first row
//		  int Top = 0; // Excluding the corners (1-6)
//		  HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//		  HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);


//		  int Left = 0; // Excluding the corners (1-6) (Left Hand Side) (8, 16, 24, 32, 40 ,48)
//		  int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)

//		  piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)

//		  HadDiff[4]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[4]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[7] = iTemp = piOrg[3] - piCur[3];  Right += APCVal[7] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[8] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[11] = iTemp = piOrg[3] - piCur[3];  Right += APCVal[11] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);


//		  //---
//		  piCur += iStrideCur; piOrg += iStrideOrg;

//		  int Bottom = 0;  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//		  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//		  HadDiff[13] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[13] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//		  HadDiff[14] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[14] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);

//		  //---

//		  //---------
//		  // Top, Bottom, Left and Right contain APC socre , no need to divide result by  2, to get APC/2, APC_NegAndPos_1D is APC/2 as standard
//		  // Note: this is done without corner information, which will be done later with the inner square/block.
//		  // This approach without corners avoids duplication of values and ensures the test is simple.
//		  // Testing on random sample vector observations of 30k which contained pixel and APC info, 10k were selected, similar to the approach with corners, 11k, 2/3 reduction.
//		  // This means that a simple test can then decide if a more complex process should occur, which is only needed 1/3 of the time.
//		  // This is dependent on video source/content and encoding settings, but it indicates that the encoding will dynamically change, hence be adaptive.

//		  // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//		  //UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//		  // Test - Conditional
//		  // When Always False  (as in perform Had Only) it is the fastest (least additional processing required.
//		  //bool ProceedwAPC = AbsAsymCost > 64? true : false; // Currently
//		  //bool ProceedwAPC = AbsAsymCost > 0? true : false;  // Control - yes it does make it the same as HadwAPC (w/o PreAssess)
//		  //bool ProceedwAPC = AbsAsymCost > 2? true : false;  // Tested out 4, 8, 16, 32, (2 is like 4)

//		  //UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?

//		  //bool ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//		  //---------
//		  // Depending if the condition is met, different levels of processing is applied.
//		  // False means Had only. (existing)
//		  // True means Had with APC (proposed).

//		  // Step 3) Use a case statement on the bool of the threshold.
//		  //         For false, use existing method of SAD only on the inner block.
//		  //         For true, apply proposed method on inner block.
//		  // This means that processing load adapts dynamically to the conditions of the content.

//		  // reset piCur and piOrg
//		  piCur = myCur;
//		  piOrg = myOrg;

//		  // create pointer to an array and set it in ProceedwAPC.
//		  // Set the pointer to point to the HadDiff or HadwAPCDiff.
//		  // Refer to the pointer in the Hadamard Calculation.

//		  Int *ptrDiff;



//				  // Top corners first (Top Left and Top Right), then inner square.
//				  HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//				  HadDiff[3] = iTemp = piOrg[3] - piCur[3]; APCVal[3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//				  for( k = 4; k < 12; k += 4 ) // Just the remaining inner square, between the edge rows and columns
//				  {
//					  // Remember start from the second row, since the first row  has already been done
//					  piCur += iStrideCur;
//					  piOrg += iStrideOrg;

//					  //The inner square
//					  // No Zero
//					  HadDiff[k+1] = iTemp = piOrg[1] - piCur[1]; APCVal[k+1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//					  HadDiff[k+2] = iTemp = piOrg[2] - piCur[2]; APCVal[k+2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);

//				  }

//				  // Bottom Corners
//				  piCur += iStrideCur;
//				  piOrg += iStrideOrg;

//				  HadDiff[12] = iTemp = piOrg[0] - piCur[0]; APCVal[56] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//				  HadDiff[15] = iTemp = piOrg[3] - piCur[3]; APCVal[63] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//				  ptrDiff = APCVal;
//			 // }
//			 // break;
//		  //}

//		////----------------------------

//          //Int k;
//          Distortion satd = 0;
//          //TCoeff diff[16], m[16], d[16];
//          TCoeff m[16], d[16];

//          /*===== hadamard transform =====*/

//          m[ 0] = HadDiff[ 0] + ptrDiff[ 0] + HadDiff[12] + ptrDiff[12];
//          m[ 1] = HadDiff[ 1] + ptrDiff[ 1] + HadDiff[13] + ptrDiff[13];
//          m[ 2] = HadDiff[ 2] + ptrDiff[ 2] + HadDiff[14] + ptrDiff[14];
//          m[ 3] = HadDiff[ 3] + ptrDiff[ 3] + HadDiff[15] + ptrDiff[15];
//          m[ 4] = HadDiff[ 4] + ptrDiff[ 4] + HadDiff[ 8] + ptrDiff[ 8];
//          m[ 5] = HadDiff[ 5] + ptrDiff[ 5] + HadDiff[ 9] + ptrDiff[ 9];
//          m[ 6] = HadDiff[ 6] + ptrDiff[ 6] + HadDiff[10] + ptrDiff[10];
//          m[ 7] = HadDiff[ 7] + ptrDiff[ 7] + HadDiff[11] + ptrDiff[11];
//          m[ 8] = HadDiff[ 4] + ptrDiff[ 4] - HadDiff[ 8] + ptrDiff[ 8];
//          m[ 9] = HadDiff[ 5] + ptrDiff[ 5] - HadDiff[ 9] + ptrDiff[ 9];
//          m[10] = HadDiff[ 6] + ptrDiff[ 6] - HadDiff[10] + ptrDiff[10];
//          m[11] = HadDiff[ 7] + ptrDiff[ 7] - HadDiff[11] + ptrDiff[11];
//          m[12] = HadDiff[ 0] + ptrDiff[ 0] - HadDiff[12] + ptrDiff[12];
//          m[13] = HadDiff[ 1] + ptrDiff[ 1] - HadDiff[13] + ptrDiff[13];
//          m[14] = HadDiff[ 2] + ptrDiff[ 2] - HadDiff[14] + ptrDiff[14];
//          m[15] = HadDiff[ 3] + ptrDiff[ 3] - HadDiff[15] + ptrDiff[15];

//          d[ 0] = m[ 0] + m[ 4];
//          d[ 1] = m[ 1] + m[ 5];
//          d[ 2] = m[ 2] + m[ 6];
//          d[ 3] = m[ 3] + m[ 7];
//          d[ 4] = m[ 8] + m[12];
//          d[ 5] = m[ 9] + m[13];
//          d[ 6] = m[10] + m[14];
//          d[ 7] = m[11] + m[15];
//          d[ 8] = m[ 0] - m[ 4];
//          d[ 9] = m[ 1] - m[ 5];
//          d[10] = m[ 2] - m[ 6];
//          d[11] = m[ 3] - m[ 7];
//          d[12] = m[12] - m[ 8];
//          d[13] = m[13] - m[ 9];
//          d[14] = m[14] - m[10];
//          d[15] = m[15] - m[11];

//          m[ 0] = d[ 0] + d[ 3];
//          m[ 1] = d[ 1] + d[ 2];
//          m[ 2] = d[ 1] - d[ 2];
//          m[ 3] = d[ 0] - d[ 3];
//          m[ 4] = d[ 4] + d[ 7];
//          m[ 5] = d[ 5] + d[ 6];
//          m[ 6] = d[ 5] - d[ 6];
//          m[ 7] = d[ 4] - d[ 7];
//          m[ 8] = d[ 8] + d[11];
//          m[ 9] = d[ 9] + d[10];
//          m[10] = d[ 9] - d[10];
//          m[11] = d[ 8] - d[11];
//          m[12] = d[12] + d[15];
//          m[13] = d[13] + d[14];
//          m[14] = d[13] - d[14];
//          m[15] = d[12] - d[15];

//          d[ 0] = m[ 0] + m[ 1];
//          d[ 1] = m[ 0] - m[ 1];
//          d[ 2] = m[ 2] + m[ 3];
//          d[ 3] = m[ 3] - m[ 2];
//          d[ 4] = m[ 4] + m[ 5];
//          d[ 5] = m[ 4] - m[ 5];
//          d[ 6] = m[ 6] + m[ 7];
//          d[ 7] = m[ 7] - m[ 6];
//          d[ 8] = m[ 8] + m[ 9];
//          d[ 9] = m[ 8] - m[ 9];
//          d[10] = m[10] + m[11];
//          d[11] = m[11] - m[10];
//          d[12] = m[12] + m[13];
//          d[13] = m[12] - m[13];
//          d[14] = m[14] + m[15];
//          d[15] = m[15] - m[14];

//          for (k=0; k<16; ++k)
//          {
//            satd += abs(d[k]);
//          }
//          iSumHad = satd = ((satd+1)>>1);

//		}

//		yInt = yInt_Rec;

////        // Convert YUV to RGB

//		int r=0, g=0, b=0;


//		if (HadRegion == true)
//		{

////			int blkwidth = 8;

//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = 0; //(int)log2((double)blkwidth) - 3;
//            // Take blk width = 8 then divide by 4
//			int maxUnscaled = ((maxLimitSAD_k[loc] >> 2) * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("Had4x4wAPC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);
			
//			//------------------

//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//        else
//        {
//            r = g = b = yInt;
//        }

//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working?
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}



//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}



//Void TAppDecTop::saveFrameAsPNG_Had4x4PreAssess_APC(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_Had4x4PreAssessAPC_DistortionHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0; //, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//		bool HadRegion = false;
//		Distortion iSumHad =0;

//		if ((y < (height-4)) && (x < (width-4)))
//		{
//		  HadRegion = true;


//		  for ( unsigned n = 0; n < 4; n++ )
//		  {
//			  for ( unsigned m = 0; m < 4; m++ )
//			  {
//				  // y*width + x
//				  unsigned yloc4x4 = n*4+m;

//				  //Distortion y_Org =
//				  ptrY_Org8x8[yloc4x4] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//				  //Distortion y_Rec =
//				  ptrY_Rec8x8[yloc4x4] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//				  ////------------------
//				  //// YGJ 12th July 2014
//				  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
//				  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//				  //// a -- set up and initialise variables

//				  ////------------------

//			  }
//		  }


//		  //int HadDiff[64];
//		  //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
//		  //TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//		  //Int APCVal[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//		  //Int OrgPx[64], RecPx[64];

//		  // Here Had with integrated APC is applied based upon a pre-assessment.
//		  // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
//		  // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
//		  // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
//		  // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.

//		  Int iStrideOrg = 4;
//		  Int iStrideCur = 4;

//		  Int k; //, i, j, jj;
//		  // Used now
//		  Pel* piOrg = ptrY_Org8x8; //piOrg;
//		  Pel* piCur = ptrY_Rec8x8; //piCur;
//		  // Used later
//		  Pel* myOrg = ptrY_Org8x8; //piOrg;
//		  Pel* myCur = ptrY_Rec8x8; //piCur;
//		  //
//		  Int APCVal[16];
//		  Int iTemp = 0;  // Usomg Int here as difference may be negative.
//		  //UInt BitDiff = (g_bitDepth[0]-8); // Used in scaling down SAD when higher bit depths are used, applied at the total. Similar to SSE to support higher bit depths

//		  // YGJ 21st Aug 2014
//		  Int HadDiff[16];

//		  //---------
//		  // YGJ Mon 25th Aug 2014
//		  // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
//		  // If asymmetrical then proceed with APCwHad else just perform Had.
//		  // Note the plus 255 is required to centre it at zero

//		  // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
//		  //---

//		  // piCur and piOrg Already initialised to the first row
//		  int Top = 0; // Excluding the corners (1-6)
//		  HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//		  HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//		  //HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//		  //HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//		  //HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//		  //HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);


//		  int Left = 0; // Excluding the corners (1-6) (Left Hand Side) (8, 16, 24, 32, 40 ,48)
//		  int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)

//		  piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)

//		  HadDiff[4]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[4]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[7] = iTemp = piOrg[3] - piCur[3];  Right += APCVal[7] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[8] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[11] = iTemp = piOrg[3] - piCur[3];  Right += APCVal[11] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//		  //piCur += iStrideCur; piOrg += iStrideOrg;
//		  //HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  //HadDiff[31] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  //piCur += iStrideCur; piOrg += iStrideOrg;
//		  //HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  //HadDiff[39] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  //piCur += iStrideCur; piOrg += iStrideOrg;
//		  //HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  //HadDiff[47] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  //piCur += iStrideCur; piOrg += iStrideOrg;
//		  //HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  //HadDiff[55] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  //---
//		  piCur += iStrideCur; piOrg += iStrideOrg;

//		  int Bottom = 0;  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//		  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//		  HadDiff[13] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[13] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//		  HadDiff[14] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[14] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//		  //HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//		  //HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//		  //HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//		  //HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);

//		  //---

//		  //---------
//		  // Top, Bottom, Left and Right contain APC socre , no need to divide result by  2, to get APC/2, APC_NegAndPos_1D is APC/2 as standard
//		  // Note: this is done without corner information, which will be done later with the inner square/block.
//		  // This approach without corners avoids duplication of values and ensures the test is simple.
//		  // Testing on random sample vector observations of 30k which contained pixel and APC info, 10k were selected, similar to the approach with corners, 11k, 2/3 reduction.
//		  // This means that a simple test can then decide if a more complex process should occur, which is only needed 1/3 of the time.
//		  // This is dependent on video source/content and encoding settings, but it indicates that the encoding will dynamically change, hence be adaptive.

//		  // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//		  UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//          //if (AbsAsymCost > 28)
//          //{
//          //  //================================================
//          //  //Log Threshold by CU and Frame number

//          //  //    ofstream CalcValues;

//          //  //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//          //   ofstream ThreshLog;
//          //   ThreshLog.open ("ThresholdLog_Dec_PreAssess_HAD4x4.txt", ios::out | ios::app);
//          //
//          //   UInt MaxCUx = width >> 6;
//          //   UInt MaxCUy = height >> 6;
//          //   UInt CUx = x >> 6;
//          //   UInt CUy = y >> 6;

//          //   ThreshLog << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//          //   ThreshLog.close();

//          //  //================================================
//          //}
             

//		  // Test - Conditional
//		  // When Always False  (as in perform Had Only) it is the fastest (least additional processing required.
//		  //bool ProceedwAPC = AbsAsymCost > 64? true : false; // Currently
//		  //bool ProceedwAPC = AbsAsymCost > 0? true : false;  // Control - yes it does make it the same as HadwAPC (w/o PreAssess)
//		  //bool ProceedwAPC = AbsAsymCost > 2? true : false;  // Tested out 4, 8, 16, 32, (2 is like 4)

//		  UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?

//		  bool ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//		  //---------
//		  // Depending if the condition is met, different levels of processing is applied.
//		  // False means Had only. (existing)
//		  // True means Had with APC (proposed).

//		  // Step 3) Use a case statement on the bool of the threshold.
//		  //         For false, use existing method of SAD only on the inner block.
//		  //         For true, apply proposed method on inner block.
//		  // This means that processing load adapts dynamically to the conditions of the content.

//		  // reset piCur and piOrg
//		  piCur = myCur;
//		  piOrg = myOrg;

//		  // create pointer to an array and set it in ProceedwAPC.
//		  // Set the pointer to point to the HadDiff or HadwAPCDiff.
//		  // Refer to the pointer in the Hadamard Calculation.

//		  Int *ptrDiff;

//		  switch(ProceedwAPC)
//		  {
//		  case false:
//			  {
//				  // Top corners first (Top Left and Top Right), then inner square.
//				  HadDiff[0] = piOrg[0] - piCur[0];
//				  HadDiff[3] = piOrg[3] - piCur[3];

//				  for( k = 4; k < 12; k += 4 ) // Just the remaining inner square, between the edge rows and columns
//				  {

//					  // Remember start from the second row, since the first row  has already been done
//					  piCur += iStrideCur;
//					  piOrg += iStrideOrg;

//					  //The inner square
//					  // No Zero
//					  HadDiff[k+1] = piOrg[1] - piCur[1];
//					  HadDiff[k+2] = piOrg[2] - piCur[2];
//					  //HadDiff[k+3] = piOrg[3] - piCur[3];
//					  //HadDiff[k+4] = piOrg[4] - piCur[4];
//					  //HadDiff[k+5] = piOrg[5] - piCur[5];
//					  //HadDiff[k+6] = piOrg[6] - piCur[6];
//					  // No Seven
//				  }

//				  // Bottom Corners
//				  piCur += iStrideCur;
//				  piOrg += iStrideOrg;

//				  HadDiff[12] = piOrg[0] - piCur[0];
//				  HadDiff[15] = piOrg[3] - piCur[3];

//				  // Assign ptr to Hadamard difference
//				  ptrDiff = HadAllZero16; // Array of Zeros
//			  }
//			  break;

//		  case true:
//			  {

//				  // Top corners first (Top Left and Top Right), then inner square.
//				  HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//				  HadDiff[3] = iTemp = piOrg[3] - piCur[3]; APCVal[3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//				  for( k = 4; k < 12; k += 4 ) // Just the remaining inner square, between the edge rows and columns
//				  {
//					  // Remember start from the second row, since the first row  has already been done
//					  piCur += iStrideCur;
//					  piOrg += iStrideOrg;

//					  //The inner square
//					  // No Zero
//					  HadDiff[k+1] = iTemp = piOrg[1] - piCur[1]; APCVal[k+1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//					  HadDiff[k+2] = iTemp = piOrg[2] - piCur[2]; APCVal[k+2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//					  //HadDiff[k+3] = iTemp = piOrg[3] - piCur[3]; APCVal[k+3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//					  //HadDiff[k+4] = iTemp = piOrg[4] - piCur[4]; APCVal[k+4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//					  //HadDiff[k+5] = iTemp = piOrg[5] - piCur[5]; APCVal[k+5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//					  //HadDiff[k+6] = iTemp = piOrg[6] - piCur[6]; APCVal[k+6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);
//					  // No Seven
//				  }

//				  // Bottom Corners
//				  piCur += iStrideCur;
//				  piOrg += iStrideOrg;

//                  HadDiff[12] = iTemp = piOrg[0] - piCur[0]; APCVal[12] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//                  HadDiff[15] = iTemp = piOrg[3] - piCur[3]; APCVal[15] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);

//				  ptrDiff = APCVal;
//			  }
//			  break;
//		  }

//		////----------------------------

//          //Int k;
//          Distortion satd = 0;
//          //TCoeff diff[16], m[16], d[16];
//          TCoeff m[16], d[16];

//          /*===== hadamard transform =====*/
//          //m[ 0] = diff[ 0] + diff[12];
//          //m[ 1] = diff[ 1] + diff[13];
//          //m[ 2] = diff[ 2] + diff[14];
//          //m[ 3] = diff[ 3] + diff[15];
//          //m[ 4] = diff[ 4] + diff[ 8];
//          //m[ 5] = diff[ 5] + diff[ 9];
//          //m[ 6] = diff[ 6] + diff[10];
//          //m[ 7] = diff[ 7] + diff[11];
//          //m[ 8] = diff[ 4] - diff[ 8];
//          //m[ 9] = diff[ 5] - diff[ 9];
//          //m[10] = diff[ 6] - diff[10];
//          //m[11] = diff[ 7] - diff[11];
//          //m[12] = diff[ 0] - diff[12];
//          //m[13] = diff[ 1] - diff[13];
//          //m[14] = diff[ 2] - diff[14];
//          //m[15] = diff[ 3] - diff[15];

//     //     			  m2[j][0] = (HadDiff[jj  ] + ptrDiff[jj  ]) + (HadDiff[jj+4] + ptrDiff[jj+4]);
//			  //m2[j][1] = (HadDiff[jj+1] + ptrDiff[jj+1]) + (HadDiff[jj+5] + ptrDiff[jj+5]);
//			  //m2[j][2] = (HadDiff[jj+2] + ptrDiff[jj+2]) + (HadDiff[jj+6] + ptrDiff[jj+6]);
//			  //m2[j][3] = (HadDiff[jj+3] + ptrDiff[jj+3]) + (HadDiff[jj+7] + ptrDiff[jj+7]);
//			  //m2[j][4] = (HadDiff[jj  ] + ptrDiff[jj  ]) - (HadDiff[jj+4] + ptrDiff[jj+4]);
//			  //m2[j][5] = (HadDiff[jj+1] + ptrDiff[jj+1]) - (HadDiff[jj+5] + ptrDiff[jj+5]);
//			  //m2[j][6] = (HadDiff[jj+2] + ptrDiff[jj+2]) - (HadDiff[jj+6] + ptrDiff[jj+6]);
//			  //m2[j][7] = (HadDiff[jj+3] + ptrDiff[jj+3]) - (HadDiff[jj+7] + ptrDiff[jj+7]);

//          m[ 0] = HadDiff[ 0] + ptrDiff[ 0] + HadDiff[12] + ptrDiff[12];
//          m[ 1] = HadDiff[ 1] + ptrDiff[ 1] + HadDiff[13] + ptrDiff[13];
//          m[ 2] = HadDiff[ 2] + ptrDiff[ 2] + HadDiff[14] + ptrDiff[14];
//          m[ 3] = HadDiff[ 3] + ptrDiff[ 3] + HadDiff[15] + ptrDiff[15];
//          m[ 4] = HadDiff[ 4] + ptrDiff[ 4] + HadDiff[ 8] + ptrDiff[ 8];
//          m[ 5] = HadDiff[ 5] + ptrDiff[ 5] + HadDiff[ 9] + ptrDiff[ 9];
//          m[ 6] = HadDiff[ 6] + ptrDiff[ 6] + HadDiff[10] + ptrDiff[10];
//          m[ 7] = HadDiff[ 7] + ptrDiff[ 7] + HadDiff[11] + ptrDiff[11];
//          m[ 8] = HadDiff[ 4] + ptrDiff[ 4] - HadDiff[ 8] + ptrDiff[ 8];
//          m[ 9] = HadDiff[ 5] + ptrDiff[ 5] - HadDiff[ 9] + ptrDiff[ 9];
//          m[10] = HadDiff[ 6] + ptrDiff[ 6] - HadDiff[10] + ptrDiff[10];
//          m[11] = HadDiff[ 7] + ptrDiff[ 7] - HadDiff[11] + ptrDiff[11];
//          m[12] = HadDiff[ 0] + ptrDiff[ 0] - HadDiff[12] + ptrDiff[12];
//          m[13] = HadDiff[ 1] + ptrDiff[ 1] - HadDiff[13] + ptrDiff[13];
//          m[14] = HadDiff[ 2] + ptrDiff[ 2] - HadDiff[14] + ptrDiff[14];
//          m[15] = HadDiff[ 3] + ptrDiff[ 3] - HadDiff[15] + ptrDiff[15];

//          d[ 0] = m[ 0] + m[ 4];
//          d[ 1] = m[ 1] + m[ 5];
//          d[ 2] = m[ 2] + m[ 6];
//          d[ 3] = m[ 3] + m[ 7];
//          d[ 4] = m[ 8] + m[12];
//          d[ 5] = m[ 9] + m[13];
//          d[ 6] = m[10] + m[14];
//          d[ 7] = m[11] + m[15];
//          d[ 8] = m[ 0] - m[ 4];
//          d[ 9] = m[ 1] - m[ 5];
//          d[10] = m[ 2] - m[ 6];
//          d[11] = m[ 3] - m[ 7];
//          d[12] = m[12] - m[ 8];
//          d[13] = m[13] - m[ 9];
//          d[14] = m[14] - m[10];
//          d[15] = m[15] - m[11];

//          m[ 0] = d[ 0] + d[ 3];
//          m[ 1] = d[ 1] + d[ 2];
//          m[ 2] = d[ 1] - d[ 2];
//          m[ 3] = d[ 0] - d[ 3];
//          m[ 4] = d[ 4] + d[ 7];
//          m[ 5] = d[ 5] + d[ 6];
//          m[ 6] = d[ 5] - d[ 6];
//          m[ 7] = d[ 4] - d[ 7];
//          m[ 8] = d[ 8] + d[11];
//          m[ 9] = d[ 9] + d[10];
//          m[10] = d[ 9] - d[10];
//          m[11] = d[ 8] - d[11];
//          m[12] = d[12] + d[15];
//          m[13] = d[13] + d[14];
//          m[14] = d[13] - d[14];
//          m[15] = d[12] - d[15];

//          d[ 0] = m[ 0] + m[ 1];
//          d[ 1] = m[ 0] - m[ 1];
//          d[ 2] = m[ 2] + m[ 3];
//          d[ 3] = m[ 3] - m[ 2];
//          d[ 4] = m[ 4] + m[ 5];
//          d[ 5] = m[ 4] - m[ 5];
//          d[ 6] = m[ 6] + m[ 7];
//          d[ 7] = m[ 7] - m[ 6];
//          d[ 8] = m[ 8] + m[ 9];
//          d[ 9] = m[ 8] - m[ 9];
//          d[10] = m[10] + m[11];
//          d[11] = m[11] - m[10];
//          d[12] = m[12] + m[13];
//          d[13] = m[12] - m[13];
//          d[14] = m[14] + m[15];
//          d[15] = m[15] - m[14];

//          for (k=0; k<16; ++k)
//          {
//            satd += abs(d[k]);
//          }
//          iSumHad = satd = ((satd+1)>>1);


//			////int i, j, jj;//, k;


//			//// End of Multi-Scale APC
//			////=============================
//			//// Beginning of Hadamard with APC

//			////Now to add/subtract to the Hadamard Diff.
//			////Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
//			////int APCscale = 0;

//			////iSumHad =0;

//			////horizontal
//			//for (j=0; j < 8; j++)
//			//{
//			//  jj = j << 3;
//			//  //---------------------
//			//  // Changed to support Had with Integrated APC subject to meeting threshold.

//			//  // Additional Pixel Cost (APC) - Add APC to the difference
//			//  m2[j][0] = (HadDiff[jj  ] + ptrDiff[jj  ]) + (HadDiff[jj+4] + ptrDiff[jj+4]);
//			//  m2[j][1] = (HadDiff[jj+1] + ptrDiff[jj+1]) + (HadDiff[jj+5] + ptrDiff[jj+5]);
//			//  m2[j][2] = (HadDiff[jj+2] + ptrDiff[jj+2]) + (HadDiff[jj+6] + ptrDiff[jj+6]);
//			//  m2[j][3] = (HadDiff[jj+3] + ptrDiff[jj+3]) + (HadDiff[jj+7] + ptrDiff[jj+7]);
//			//  m2[j][4] = (HadDiff[jj  ] + ptrDiff[jj  ]) - (HadDiff[jj+4] + ptrDiff[jj+4]);
//			//  m2[j][5] = (HadDiff[jj+1] + ptrDiff[jj+1]) - (HadDiff[jj+5] + ptrDiff[jj+5]);
//			//  m2[j][6] = (HadDiff[jj+2] + ptrDiff[jj+2]) - (HadDiff[jj+6] + ptrDiff[jj+6]);
//			//  m2[j][7] = (HadDiff[jj+3] + ptrDiff[jj+3]) - (HadDiff[jj+7] + ptrDiff[jj+7]);

//			//  m1[j][0] = m2[j][0] + m2[j][2];
//			//  m1[j][1] = m2[j][1] + m2[j][3];
//			//  m1[j][2] = m2[j][0] - m2[j][2];
//			//  m1[j][3] = m2[j][1] - m2[j][3];
//			//  m1[j][4] = m2[j][4] + m2[j][6];
//			//  m1[j][5] = m2[j][5] + m2[j][7];
//			//  m1[j][6] = m2[j][4] - m2[j][6];
//			//  m1[j][7] = m2[j][5] - m2[j][7];

//			//  m2[j][0] = m1[j][0] + m1[j][1];
//			//  m2[j][1] = m1[j][0] - m1[j][1];
//			//  m2[j][2] = m1[j][2] + m1[j][3];
//			//  m2[j][3] = m1[j][2] - m1[j][3];
//			//  m2[j][4] = m1[j][4] + m1[j][5];
//			//  m2[j][5] = m1[j][4] - m1[j][5];
//			//  m2[j][6] = m1[j][6] + m1[j][7];
//			//  m2[j][7] = m1[j][6] - m1[j][7];
//			//}

//			////vertical
//			//for (i=0; i < 8; i++)
//			//{
//			//  m3[0][i] = m2[0][i] + m2[4][i];
//			//  m3[1][i] = m2[1][i] + m2[5][i];
//			//  m3[2][i] = m2[2][i] + m2[6][i];
//			//  m3[3][i] = m2[3][i] + m2[7][i];
//			//  m3[4][i] = m2[0][i] - m2[4][i];
//			//  m3[5][i] = m2[1][i] - m2[5][i];
//			//  m3[6][i] = m2[2][i] - m2[6][i];
//			//  m3[7][i] = m2[3][i] - m2[7][i];

//			//  m1[0][i] = m3[0][i] + m3[2][i];
//			//  m1[1][i] = m3[1][i] + m3[3][i];
//			//  m1[2][i] = m3[0][i] - m3[2][i];
//			//  m1[3][i] = m3[1][i] - m3[3][i];
//			//  m1[4][i] = m3[4][i] + m3[6][i];
//			//  m1[5][i] = m3[5][i] + m3[7][i];
//			//  m1[6][i] = m3[4][i] - m3[6][i];
//			//  m1[7][i] = m3[5][i] - m3[7][i];

//			//  m2[0][i] = m1[0][i] + m1[1][i];
//			//  m2[1][i] = m1[0][i] - m1[1][i];
//			//  m2[2][i] = m1[2][i] + m1[3][i];
//			//  m2[3][i] = m1[2][i] - m1[3][i];
//			//  m2[4][i] = m1[4][i] + m1[5][i];
//			//  m2[5][i] = m1[4][i] - m1[5][i];
//			//  m2[6][i] = m1[6][i] + m1[7][i];
//			//  m2[7][i] = m1[6][i] - m1[7][i];
//			//}

//			//for (i = 0; i < 8; i++)
//			//{
//			//  for (j = 0; j < 8; j++)
//			//  {
//			//	iSumHad += abs(m2[i][j]);
//			//  }
//			//}

//			//iSumHad=((iSumHad+2)>>2);

//		}

//		yInt = yInt_Rec;

////        // Convert YUV to RGB

//		int r=0, g=0, b=0;


//		if (HadRegion == true)
//		{

//			int blkwidth = 8;

//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = (int)log2((double)blkwidth) - 3;

//			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0
//				: dist < (halfMaxThreshold >> 1) ? 1
//				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("Pre Assess Had4x4w-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//				halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//			float normHad = ((float)dist)/((float)halfMaxThreshold);
			
//			//------------------

//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//        else
//        {
//            r = g = b = yInt;
//        }

//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working?
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}



//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	}


//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}

////
////Void TAppDecTop::saveFrameAsPNG_HadPreAssess_APC(TComPic* pcPic)
////{
////
////  unsigned height = m_iSourceHeight;
////  unsigned width = m_iSourceWidth;
////  unsigned FrameRes = (height*width);
////
////  // Used to produce Heatmaps
////  TComPicYuv* imageOrg = m_pcPicYuvOrg;
////  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
////  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();
////
////  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.
////
////  int poc = pcPic->getPOC();
////
////  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);
////
////  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);
////
////  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);
////
////  unsigned YStride = imageOrg->getStride(COMPONENT_Y);
////
////  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);
////
////  // Orig
////  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");
////
////  // Recon Minus Orig
////  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");
////
////  // Partitioning
////  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");
////
////	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
////	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");
////
////   // To Do:
////
////  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.
////
////  //unsigned poc = ;
////  char strpoc[6];
////  char strRange[8];
////  char strFactor[8];
////
////
////  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
////  #if _MSC_VER
////  #define snprintf _snprintf
////  #endif
////
////  // Set up file names
////
////  if (poc < 10)
////	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
////  else if (poc < 100)
////	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);
////
////  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
////  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);
////
////  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
////  strcat(SSIMHeatmap, "DecFrm_HadPreAssessAPC_DistortionHeatMap_");
////  strcat(SSIMHeatmap, strpoc);
////  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
////  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
////  strcat(SSIMHeatmap, ".png");
////
////  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);
////
////  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
////	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
////
////	for ( unsigned y = 0; y < height; y++ )
////	{
////	  for ( unsigned x = 0; x < width; x++ )
////	  {
////		unsigned yloc = y*width+x;
////
////		// allocate YUV value
////		int yInt = 0; //, uInt = 0, vInt = 0;
////
////		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
////		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
////		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);
////
////		int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
////		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
////		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];
////
////		// seems fine here
////		if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
////			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);
////
////		bool HadRegion = false;
////		Distortion iSumHad =0;
////
////		if ((y < (height-8)) && (x < (width-8)))
////		{
////		  HadRegion = true;
////
////
////		  for ( unsigned n = 0; n < 8; n++ )
////		  {
////			  for ( unsigned m = 0; m < 8; m++ )
////			  {
////				  // y*width + x
////				  unsigned yloc8x8 = n*8+m;
////
////				  //Distortion y_Org =
////				  ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
////				  //Distortion y_Rec =
////				  ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);
////
////				  ////------------------
////				  //// YGJ 12th July 2014
////				  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
////				  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
////				  //// a -- set up and initialise variables
////
////				  ////------------------
////
////			  }
////		  }
////
////
////		  //int HadDiff[64];
////		  //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
////		  TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
////		  //Int APCVal[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
////		  //Int OrgPx[64], RecPx[64];
////
////		  // Here Had with integrated APC is applied based upon a pre-assessment.
////		  // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
////		  // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
////		  // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
////		  // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.
////
////		  Int iStrideOrg = 8;
////		  Int iStrideCur = 8;
////
////		  Int k, i, j, jj;
////		  // Used now
////		  Pel* piOrg = ptrY_Org8x8; //piOrg;
////		  Pel* piCur = ptrY_Rec8x8; //piCur;
////		  // Used later
////		  Pel* myOrg = ptrY_Org8x8; //piOrg;
////		  Pel* myCur = ptrY_Rec8x8; //piCur;
////		  //
////		  Int APCVal[64];
////		  Int iTemp = 0;  // Usomg Int here as difference may be negative.
////		  //UInt BitDiff = (g_bitDepth[0]-8); // Used in scaling down SAD when higher bit depths are used, applied at the total. Similar to SSE to support higher bit depths
////
////		  // YGJ 21st Aug 2014
////		  Int HadDiff[64];
////
////		  //---------
////		  // YGJ Mon 25th Aug 2014
////		  // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
////		  // If asymmetrical then proceed with APCwHad else just perform Had.
////		  // Note the plus 255 is required to centre it at zero
////
////		  // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
////		  //---
////
////		  // piCur and piOrg Already initialised to the first row
////		  int Top = 0; // Excluding the corners (1-6)
////		  HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
////		  HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
////		  HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
////		  HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
////		  HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
////		  HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);
////
////
////		  int Left = 0; // Excluding the corners (1-6) (Left Hand Side) (8, 16, 24, 32, 40 ,48)
////		  int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)
////
////		  piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)
////
////		  HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////		  HadDiff[15] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////		  piCur += iStrideCur; piOrg += iStrideOrg;
////		  HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////		  HadDiff[23] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////		  piCur += iStrideCur; piOrg += iStrideOrg;
////		  HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////		  HadDiff[31] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////		  piCur += iStrideCur; piOrg += iStrideOrg;
////		  HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////		  HadDiff[39] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////		  piCur += iStrideCur; piOrg += iStrideOrg;
////		  HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////		  HadDiff[47] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////		  piCur += iStrideCur; piOrg += iStrideOrg;
////		  HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////		  HadDiff[55] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////		  //---
////		  piCur += iStrideCur; piOrg += iStrideOrg;
////
////		  int Bottom = 0;  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
////		  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
////		  HadDiff[57] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[57] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
////		  HadDiff[58] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[58] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
////		  HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
////		  HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
////		  HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
////		  HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);
////
////		  //---
////
////		  //---------
////		  // Top, Bottom, Left and Right contain APC socre , no need to divide result by  2, to get APC/2, APC_NegAndPos_1D is APC/2 as standard
////		  // Note: this is done without corner information, which will be done later with the inner square/block.
////		  // This approach without corners avoids duplication of values and ensures the test is simple.
////		  // Testing on random sample vector observations of 30k which contained pixel and APC info, 10k were selected, similar to the approach with corners, 11k, 2/3 reduction.
////		  // This means that a simple test can then decide if a more complex process should occur, which is only needed 1/3 of the time.
////		  // This is dependent on video source/content and encoding settings, but it indicates that the encoding will dynamically change, hence be adaptive.
////
////		  // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.
////
////		  UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));
////
////		  // Test - Conditional
////		  // When Always False  (as in perform Had Only) it is the fastest (least additional processing required.
////		  //bool ProceedwAPC = AbsAsymCost > 64? true : false; // Currently
////		  //bool ProceedwAPC = AbsAsymCost > 0? true : false;  // Control - yes it does make it the same as HadwAPC (w/o PreAssess)
////		  //bool ProceedwAPC = AbsAsymCost > 2? true : false;  // Tested out 4, 8, 16, 32, (2 is like 4)
////
////		  UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?
////
////		  bool ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained
////
////		  //---------
////		  // Depending if the condition is met, different levels of processing is applied.
////		  // False means Had only. (existing)
////		  // True means Had with APC (proposed).
////
////		  // Step 3) Use a case statement on the bool of the threshold.
////		  //         For false, use existing method of SAD only on the inner block.
////		  //         For true, apply proposed method on inner block.
////		  // This means that processing load adapts dynamically to the conditions of the content.
////
////		  // reset piCur and piOrg
////		  piCur = myCur;
////		  piOrg = myOrg;
////
////		  // create pointer to an array and set it in ProceedwAPC.
////		  // Set the pointer to point to the HadDiff or HadwAPCDiff.
////		  // Refer to the pointer in the Hadamard Calculation.
////
////		  Int *ptrDiff;
////
////		  switch(ProceedwAPC)
////		  {
////		  case false:
////			  {
////				  // Top corners first (Top Left and Top Right), then inner square.
////				  HadDiff[0] = piOrg[0] - piCur[0];
////				  HadDiff[7] = piOrg[7] - piCur[7];
////
////				  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
////				  {
////
////					  // Remember start from the second row, since the first row  has already been done
////					  piCur += iStrideCur;
////					  piOrg += iStrideOrg;
////
////					  //The inner square
////					  // No Zero
////					  HadDiff[k+1] = piOrg[1] - piCur[1];
////					  HadDiff[k+2] = piOrg[2] - piCur[2];
////					  HadDiff[k+3] = piOrg[3] - piCur[3];
////					  HadDiff[k+4] = piOrg[4] - piCur[4];
////					  HadDiff[k+5] = piOrg[5] - piCur[5];
////					  HadDiff[k+6] = piOrg[6] - piCur[6];
////					  // No Seven
////				  }
////
////				  // Bottom Corners
////				  piCur += iStrideCur;
////				  piOrg += iStrideOrg;
////
////				  HadDiff[56] = piOrg[0] - piCur[0];
////				  HadDiff[63] = piOrg[7] - piCur[7];
////
////				  // Assign ptr to Hadamard difference
////				  ptrDiff = HadAllZero64; // Array of Zeros
////			  }
////			  break;
////
////		  case true:
////			  {
////
////				  // Top corners first (Top Left and Top Right), then inner square.
////				  HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////				  HadDiff[7] = iTemp = piOrg[7] - piCur[7]; APCVal[7] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////				  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
////				  {
////					  // Remember start from the second row, since the first row  has already been done
////					  piCur += iStrideCur;
////					  piOrg += iStrideOrg;
////
////					  //The inner square
////					  // No Zero
////					  HadDiff[k+1] = iTemp = piOrg[1] - piCur[1]; APCVal[k+1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
////					  HadDiff[k+2] = iTemp = piOrg[2] - piCur[2]; APCVal[k+2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
////					  HadDiff[k+3] = iTemp = piOrg[3] - piCur[3]; APCVal[k+3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
////					  HadDiff[k+4] = iTemp = piOrg[4] - piCur[4]; APCVal[k+4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
////					  HadDiff[k+5] = iTemp = piOrg[5] - piCur[5]; APCVal[k+5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
////					  HadDiff[k+6] = iTemp = piOrg[6] - piCur[6]; APCVal[k+6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);
////					  // No Seven
////				  }
////
////				  // Bottom Corners
////				  piCur += iStrideCur;
////				  piOrg += iStrideOrg;
////
////				  HadDiff[56] = iTemp = piOrg[0] - piCur[0]; APCVal[56] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
////				  HadDiff[63] = iTemp = piOrg[7] - piCur[7]; APCVal[63] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);
////
////				  ptrDiff = APCVal;
////			  }
////			  break;
////		  }
////
////		////----------------------------
////
////
////
////			//int i, j, jj;//, k;
////
////
////			// End of Multi-Scale APC
////			//=============================
////			// Beginning of Hadamard with APC
////
////			//Now to add/subtract to the Hadamard Diff.
////			//Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
////			//int APCscale = 0;
////
////			//iSumHad =0;
////
////			//horizontal
////			for (j=0; j < 8; j++)
////			{
////			  jj = j << 3;
////			  //---------------------
////			  // Changed to support Had with Integrated APC subject to meeting threshold.
////
////			  // Additional Pixel Cost (APC) - Add APC to the difference
////			  m2[j][0] = (HadDiff[jj  ] + ptrDiff[jj  ]) + (HadDiff[jj+4] + ptrDiff[jj+4]);
////			  m2[j][1] = (HadDiff[jj+1] + ptrDiff[jj+1]) + (HadDiff[jj+5] + ptrDiff[jj+5]);
////			  m2[j][2] = (HadDiff[jj+2] + ptrDiff[jj+2]) + (HadDiff[jj+6] + ptrDiff[jj+6]);
////			  m2[j][3] = (HadDiff[jj+3] + ptrDiff[jj+3]) + (HadDiff[jj+7] + ptrDiff[jj+7]);
////			  m2[j][4] = (HadDiff[jj  ] + ptrDiff[jj  ]) - (HadDiff[jj+4] + ptrDiff[jj+4]);
////			  m2[j][5] = (HadDiff[jj+1] + ptrDiff[jj+1]) - (HadDiff[jj+5] + ptrDiff[jj+5]);
////			  m2[j][6] = (HadDiff[jj+2] + ptrDiff[jj+2]) - (HadDiff[jj+6] + ptrDiff[jj+6]);
////			  m2[j][7] = (HadDiff[jj+3] + ptrDiff[jj+3]) - (HadDiff[jj+7] + ptrDiff[jj+7]);
////
////			  m1[j][0] = m2[j][0] + m2[j][2];
////			  m1[j][1] = m2[j][1] + m2[j][3];
////			  m1[j][2] = m2[j][0] - m2[j][2];
////			  m1[j][3] = m2[j][1] - m2[j][3];
////			  m1[j][4] = m2[j][4] + m2[j][6];
////			  m1[j][5] = m2[j][5] + m2[j][7];
////			  m1[j][6] = m2[j][4] - m2[j][6];
////			  m1[j][7] = m2[j][5] - m2[j][7];
////
////			  m2[j][0] = m1[j][0] + m1[j][1];
////			  m2[j][1] = m1[j][0] - m1[j][1];
////			  m2[j][2] = m1[j][2] + m1[j][3];
////			  m2[j][3] = m1[j][2] - m1[j][3];
////			  m2[j][4] = m1[j][4] + m1[j][5];
////			  m2[j][5] = m1[j][4] - m1[j][5];
////			  m2[j][6] = m1[j][6] + m1[j][7];
////			  m2[j][7] = m1[j][6] - m1[j][7];
////			}
////
////			//vertical
////			for (i=0; i < 8; i++)
////			{
////			  m3[0][i] = m2[0][i] + m2[4][i];
////			  m3[1][i] = m2[1][i] + m2[5][i];
////			  m3[2][i] = m2[2][i] + m2[6][i];
////			  m3[3][i] = m2[3][i] + m2[7][i];
////			  m3[4][i] = m2[0][i] - m2[4][i];
////			  m3[5][i] = m2[1][i] - m2[5][i];
////			  m3[6][i] = m2[2][i] - m2[6][i];
////			  m3[7][i] = m2[3][i] - m2[7][i];
////
////			  m1[0][i] = m3[0][i] + m3[2][i];
////			  m1[1][i] = m3[1][i] + m3[3][i];
////			  m1[2][i] = m3[0][i] - m3[2][i];
////			  m1[3][i] = m3[1][i] - m3[3][i];
////			  m1[4][i] = m3[4][i] + m3[6][i];
////			  m1[5][i] = m3[5][i] + m3[7][i];
////			  m1[6][i] = m3[4][i] - m3[6][i];
////			  m1[7][i] = m3[5][i] - m3[7][i];
////
////			  m2[0][i] = m1[0][i] + m1[1][i];
////			  m2[1][i] = m1[0][i] - m1[1][i];
////			  m2[2][i] = m1[2][i] + m1[3][i];
////			  m2[3][i] = m1[2][i] - m1[3][i];
////			  m2[4][i] = m1[4][i] + m1[5][i];
////			  m2[5][i] = m1[4][i] - m1[5][i];
////			  m2[6][i] = m1[6][i] + m1[7][i];
////			  m2[7][i] = m1[6][i] - m1[7][i];
////			}
////
////			for (i = 0; i < 8; i++)
////			{
////			  for (j = 0; j < 8; j++)
////			  {
////				iSumHad += abs(m2[i][j]);
////			  }
////			}
////
////			iSumHad=((iSumHad+2)>>2);
////
////		}
////
////		yInt = yInt_Rec;
////
//////        // Convert YUV to RGB
////
////		int r=0, g=0, b=0;
////
////
////		if (HadRegion == true)
////		{
////
////			int blkwidth = 8;
////
////			//------------------
////
////			// Using arrays as look up tables to ensure values set are consistent
////			int loc = 0; //(int)log2((double)blkwidth) - 3;
////
////			int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
////			float maxScaled = (float)((float)maxUnscaled * (0.1024));
////			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));
////
////			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;
////
////			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
////
////			int val = dist < (halfMaxThreshold >> 2) ? 0
////				: dist < (halfMaxThreshold >> 1) ? 1
////				: dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
////
////			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
////				printf("Pre Assess Had8x8w-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
////				halfMaxThreshold, iSumHad, halfMaxThreshold);
////
////			float normHad = ((float)dist)/((float)halfMaxThreshold);
////
////			//------------------
////
//////			switch (val)
//////			{
//////				case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//////					break;
//////				case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//////					break;
//////				case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//////					break;
//////				default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//////					break;
//////			}

//			////------------------
//   //         // YGJ 27th Oct 2014
//   //         // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//   //         // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			//switch (val)
//			//{
//			//	case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//			//		break;
//			//	case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//			//		break;
//			//	case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//			//		break;
//			//	default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//			//		break;
//			//}
//   //         //------------------

////		}
////        else
////        {
////            r = g = b = yInt;
////        }
////
////		// Rec - Org
////		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
////		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
////		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;
////
////
////		// Partitioning -- Not Working?
////		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
////		{
////		  r = 0; //yInt_RmO;
////		  g = 0; //yInt_RmO;
////		  b = 0; //yInt_RmO;
////		}
////
////
////
////		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
////		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
////		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
////		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now
////
////	  }
////	  //piY += YStride;
////	  piY_Org += YStride;
////	  piY_Rec += YStrideRec;
////	  piY_Part += YStrideRec;
////
////
////	}
////
////
////	free(ptrY_Org8x8);
////	free(ptrY_Rec8x8);
////
////	free(ptrY_Org);
////
////	free(ptrY_Rec);
////
////	free(ptrY_Part);
////
////
////	//-----------------------
////
////	if(m_outputSSIMHeatmaps)
////	{
////	  std::vector<unsigned char> png;
////
////	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);
////
////	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);
////
////	  //if there's an error, display it
////	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
////	}
////
////   //-----------------------
////
////}


Void TAppDecTop::saveFrameAsPNG_HadPreAssess_wCornerTest_APC(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight;
  unsigned width = m_iSourceWidth;
  unsigned FrameRes = (height*width);

  // Used to produce Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");
    Distortion *ptrDist_sadAPC;   ptrDist_sadAPC = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_sadAPC == NULL)   printf("calloc failed\n");
    bool *ptrbool_ProceedwAPC;   ptrbool_ProceedwAPC = (bool *)calloc((FrameRes >> 6), sizeof(bool));    if (ptrbool_ProceedwAPC == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  strcat(SSIMHeatmap, "DecFrm_Had8x8withPreAssessAPC_wCornerTest_DistortionHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

        //bool HadRegion = false;
        Distortion iSumHad =0;

        Distortion sadAPC = 0;
        bool ProceedwAPC = false;

        //if ((y < (height-8)) && (x < (width-8)))
        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          //HadRegion = true;

          for ( unsigned n = 0; n < 8; n++ )
          {
              for ( unsigned m = 0; m < 8; m++ )
              {
                  // y*width + x
                  unsigned yloc8x8 = n*8+m;

                  //Distortion y_Org =
                  ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                  //Distortion y_Rec =
                  ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

                  ////------------------
                  //// YGJ 12th July 2014
                  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                  //// a -- set up and initialise variables

                  ////------------------

              }
          }


          //int HadDiff[64];
          //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
          //Int APCVal[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
          //Int OrgPx[64], RecPx[64];
          TCoeff m1APC[8][8], m2APC[8][8], m3APC[8][8]; // YGJ 3rd Nov 2014 - APC version going through Hadamard process



          // Here Had with integrated APC is applied based upon a pre-assessment.
          // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
          // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
          // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
          // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.

          Int iStrideOrg = 8;
          Int iStrideCur = 8;

          Int k, i, j, jj;
          // Used now
          Pel* piOrg = ptrY_Org8x8; //piOrg;
          Pel* piCur = ptrY_Rec8x8; //piCur;
          // Used later
          Pel* myOrg = ptrY_Org8x8; //piOrg;
          Pel* myCur = ptrY_Rec8x8; //piCur;
          //
          Int APCVal[64];
          Int iTemp = 0;  // Usomg Int here as difference may be negative.
          //UInt BitDiff = (g_bitDepth[0]-8); // Used in scaling down SAD when higher bit depths are used, applied at the total. Similar to SSE to support higher bit depths

          // YGJ 21st Aug 2014
          Int HadDiff[64];

          //---------
          // YGJ Mon 25th Aug 2014
          // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
          // If asymmetrical then proceed with APCwHad else just perform Had.
          // Note the plus 255 is required to centre it at zero

          // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
          //---

          // These top corners used later in corner test.
          HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[7] = iTemp = piOrg[7] - piCur[7]; APCVal[7] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          // piCur and piOrg Already initialised to the first row
          int Top = 0; // Excluding the corners (1-6)


          HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] =TComRdCost::HadAPC((int)piOrg[1], (int)piCur[1], 0);
          HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] =TComRdCost::HadAPC((int)piOrg[2], (int)piCur[2], 0);
          HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] =TComRdCost::HadAPC((int)piOrg[3], (int)piCur[3], 0);
          HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] =TComRdCost::HadAPC((int)piOrg[4], (int)piCur[4], 0);
          HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] =TComRdCost::HadAPC((int)piOrg[5], (int)piCur[5], 0);
          HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] =TComRdCost::HadAPC((int)piOrg[6], (int)piCur[6], 0);


          int Left = 0; // Excluding the corners (1-6) (Left Hand Side) (8, 16, 24, 32, 40 ,48)
          int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)

          piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)


          HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[15] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          piCur += iStrideCur; piOrg += iStrideOrg;
          HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[23] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          piCur += iStrideCur; piOrg += iStrideOrg;
          HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[31] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          piCur += iStrideCur; piOrg += iStrideOrg;
          HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[39] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          piCur += iStrideCur; piOrg += iStrideOrg;
          HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[47] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          piCur += iStrideCur; piOrg += iStrideOrg;
          HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[55] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);


          //---
          piCur += iStrideCur; piOrg += iStrideOrg;

          // These bottom corners used later in corner test.
          HadDiff[56] = iTemp = piOrg[0] - piCur[0]; APCVal[56] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
          HadDiff[63] = iTemp = piOrg[7] - piCur[7]; APCVal[63] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

          int Bottom = 0;  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
          // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)

          HadDiff[57] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[57] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
          HadDiff[58] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[58] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
          HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
          HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
          HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
          HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);

          //---

          //---

        //  // ----------


          // Sun 23rd Nov 2014
          // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
          // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
          // Over 48 million observations were logged, which represented 8.7 million unique records.
          //UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?
          UInt Threshold = 32; // Does a threshold of 28 sufficient as 16?

          UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

          ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

          // Corner Test
          switch(ProceedwAPC)
          {
          case true:
                  {
                    // YGJ 3rd Dec 2014
                    // Based upon unpublished edge detection of by Myo. Modified to make it efficient and adapted for use here.
                    // 2 times corner minus averaged adjacent sides, in this case approximate average, should be div by 6 but using divide by 8.
                    // From modelling done in R this should reduce the no. of obs by ~1/2, focusing more on the ones with higher Had and 1-SSIM scores.
                    // Modelling showed that corner test should occur after thresholding, not before or alone.
                    // This approach is the most effective at shifting and broadening the peak in Had away from zero.
                    // From 30k sampled observations, 7k were affected, approx 23%.
                    // In R threshold was 32, divide was done by 6 and count min was >1.
                    // Here it is the same except that divide is 8.
                    // When modelled

                    int count = 0;
                    count +=  ((abs(APCVal[0]) << 1) - ((abs(Top) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
                    count +=  ((abs(APCVal[7]) << 1) - ((abs(Top) +  abs(Right)) >> 3)) > 0 ? 1 : 0;
                    count +=  ((abs(APCVal[56]) << 1) - ((abs(Bottom) +  abs(Left)) >> 3)) > 0 ? 1 : 0;
                    count +=  ((abs(APCVal[63]) << 1) - ((abs(Bottom) +  abs(Right)) >> 3)) > 0 ? 1 : 0;

                    ProceedwAPC = count > 1? true: false;

                  }

          //case false: // leave as false

          }


          //---------
          // Depending if the condition is met, different levels of processing is applied.
          // False means Had only. (existing)
          // True means Had with APC (proposed).

          // Step 3) Use a case statement on the bool of the threshold.
          //         For false, use existing method of SAD only on the inner block.
          //         For true, apply proposed method on inner block.
          // This means that processing load adapts dynamically to the conditions of the content.

          // reset piCur and piOrg
          piCur = myCur;
          piOrg = myOrg;

          // create pointer to an array and set it in ProceedwAPC.
          // Set the pointer to point to the HadDiff or HadwAPCDiff.
          // Refer to the pointer in the Hadamard Calculation.

          Int *ptrDiff;

          switch(ProceedwAPC)
          {
          case false:
              {
//                  // Top corners first (Top Left and Top Right), then inner square.
//                  HadDiff[0] = piOrg[0] - piCur[0];
//                  HadDiff[7] = piOrg[7] - piCur[7];

                  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
                  {

                      // Remember start from the second row, since the first row  has already been done
                      piCur += iStrideCur;
                      piOrg += iStrideOrg;

                      //The inner square
                      // No Zero
                      HadDiff[k+1] = piOrg[1] - piCur[1];
                      HadDiff[k+2] = piOrg[2] - piCur[2];
                      HadDiff[k+3] = piOrg[3] - piCur[3];
                      HadDiff[k+4] = piOrg[4] - piCur[4];
                      HadDiff[k+5] = piOrg[5] - piCur[5];
                      HadDiff[k+6] = piOrg[6] - piCur[6];
                      // No Seven
                  }

//                  // Bottom Corners
//                  piCur += iStrideCur;
//                  piOrg += iStrideOrg;

//                  HadDiff[56] = piOrg[0] - piCur[0];
//                  HadDiff[63] = piOrg[7] - piCur[7];

                  // Assign ptr to Hadamard difference
                  ptrDiff = HadAllZero64; // Array of Zeros
              }
              break;

          case true:
              {


                  // Top corners first (Top Left and Top Right), then inner square.
                  //HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
                  //HadDiff[7] = iTemp = piOrg[7] - piCur[7]; APCVal[7] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

                  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
                  {
                      // Remember start from the second row, since the first row  has already been done
                      piCur += iStrideCur;
                      piOrg += iStrideOrg;

                      //The inner square
                      // No Zero
                      HadDiff[k+1] = iTemp = piOrg[1] - piCur[1]; APCVal[k+1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
                      HadDiff[k+2] = iTemp = piOrg[2] - piCur[2]; APCVal[k+2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
                      HadDiff[k+3] = iTemp = piOrg[3] - piCur[3]; APCVal[k+3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
                      HadDiff[k+4] = iTemp = piOrg[4] - piCur[4]; APCVal[k+4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
                      HadDiff[k+5] = iTemp = piOrg[5] - piCur[5]; APCVal[k+5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
                      HadDiff[k+6] = iTemp = piOrg[6] - piCur[6]; APCVal[k+6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);
                      // No Seven
                  }

                  // Bottom Corners
                  //piCur += iStrideCur;
                  //piOrg += iStrideOrg;

                  //HadDiff[56] = iTemp = piOrg[0] - piCur[0]; APCVal[56] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
                  //HadDiff[63] = iTemp = piOrg[7] - piCur[7]; APCVal[63] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

                  ptrDiff = APCVal;
              }
              break;
          }

        ////----------------------------



            //int i, j, jj;//, k;


            // End of Multi-Scale APC
            //=============================
            // Beginning of Hadamard with APC

            //Now to add/subtract to the Hadamard Diff.
            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
            //int APCscale = 0;

            //iSumHad =0;

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;
              //---------------------
              // Changed to support Had with Integrated APC subject to meeting threshold.


              m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
              m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
              m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
              m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
              m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
              m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
              m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
              m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];

              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];

              //---------------------
              // Now for Had on APC
              switch(ProceedwAPC)
              {
              case true:
                      {
                          // Changed to support Had with Integrated APC subject to meeting threshold.
                          m2APC[j][0] = (ptrDiff[jj  ] ) + (ptrDiff[jj+4] );
                          m2APC[j][1] = (ptrDiff[jj+1] ) + (ptrDiff[jj+5] );
                          m2APC[j][2] = (ptrDiff[jj+2] ) + (ptrDiff[jj+6] );
                          m2APC[j][3] = (ptrDiff[jj+3] ) + (ptrDiff[jj+7] );
                          m2APC[j][4] = (ptrDiff[jj  ] ) - (ptrDiff[jj+4] );
                          m2APC[j][5] = (ptrDiff[jj+1] ) - (ptrDiff[jj+5] );
                          m2APC[j][6] = (ptrDiff[jj+2] ) - (ptrDiff[jj+6] );
                          m2APC[j][7] = (ptrDiff[jj+3] ) - (ptrDiff[jj+7] );

                          m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
                          m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
                          m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
                          m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
                          m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
                          m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
                          m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
                          m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

                          m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
                          m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
                          m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
                          m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
                          m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
                          m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
                          m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
                          m2APC[j][7] = m1APC[j][6] - m1APC[j][7];
                      }
              }

            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];

              //---------------------
              // Now for Had on APC
              switch(ProceedwAPC)
              {
              case true:
                      {
                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];
                      }
              }

            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
                sadAPC += ProceedwAPC == true? abs(m2APC[i][j]) : 0;
              }
            }

            iSumHad=((iSumHad+2)>>2);
            sadAPC=((sadAPC+2)>>2);

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;
            ptrDist_sadAPC[(x >> 3) + (y >> 3)*(width>>3)] = sadAPC;
            ptrbool_ProceedwAPC[(x >> 3) + (y >> 3)*(width>>3)] = ProceedwAPC;

        }
        else if ((y%8 != 0) || (x%8 != 0))
        {
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Use previous values

//            iSumHad = PrevHad;
//            iSumHadAPC = PrevAPCms;
//            PerformMsAPC = PrevBoolPerformAPCms;

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            sadAPC = ptrDist_sadAPC[(x >> 3) + (y >> 3)*(width>>3)];
            ProceedwAPC = ptrbool_ProceedwAPC[(x >> 3) + (y >> 3)*(width>>3)];
        }


        yInt = yInt_Rec;

//        // Convert YUV to RGB

        int r=0, g=0, b=0;


        //if (HadRegion == true)
        if (ProceedwAPC == true)
        {

//			int blkwidth = 8;

            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = 0; //(int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            //APC fixed down scale of 1/16
            iSumHad += ProceedwAPC == true? (sadAPC >> 4) : 0;

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//            int val = dist < (halfMaxThreshold >> 2) ? 0
//                : dist < (halfMaxThreshold >> 1) ? 1
//                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("Pre Assess Had8x8w-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
                halfMaxThreshold, iSumHad, halfMaxThreshold);

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

            //------------------

            //switch (val)
            //{
            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
            //		break;
            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
            //		break;
            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //}

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }

        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;


    }


    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}





//Void TAppDecTop::saveFrameAsPNG_HadPreAssess_APC(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_Had8x8withPreAssessAPC_DistortionHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0; //, uInt = 0, vInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//        //bool HadRegion = false;
//        Distortion iSumHad =0;

//        Distortion sadAPC = 0;
//        bool ProceedwAPC = false;

//        if ((y < (height-8)) && (x < (width-8)))
//        {
//          //HadRegion = true;


//          for ( unsigned n = 0; n < 8; n++ )
//          {
//              for ( unsigned m = 0; m < 8; m++ )
//              {
//                  // y*width + x
//                  unsigned yloc8x8 = n*8+m;

//                  //Distortion y_Org =
//                  ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//                  //Distortion y_Rec =
//                  ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//                  ////------------------
//                  //// YGJ 12th July 2014
//                  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
//                  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//                  //// a -- set up and initialise variables

//                  ////------------------

//              }
//          }


//          //int HadDiff[64];
//          //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
//          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//          //Int APCVal[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//          //Int OrgPx[64], RecPx[64];
//          TCoeff m1APC[8][8], m2APC[8][8], m3APC[8][8]; // YGJ 3rd Nov 2014 - APC version going through Hadamard process



//          // Here Had with integrated APC is applied based upon a pre-assessment.
//          // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
//          // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
//          // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
//          // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.

//          Int iStrideOrg = 8;
//          Int iStrideCur = 8;

//          Int k, i, j, jj;
//          // Used now
//          Pel* piOrg = ptrY_Org8x8; //piOrg;
//          Pel* piCur = ptrY_Rec8x8; //piCur;
//          // Used later
//          Pel* myOrg = ptrY_Org8x8; //piOrg;
//          Pel* myCur = ptrY_Rec8x8; //piCur;
//          //
//          Int APCVal[64];
//          Int iTemp = 0;  // Usomg Int here as difference may be negative.
//          //UInt BitDiff = (g_bitDepth[0]-8); // Used in scaling down SAD when higher bit depths are used, applied at the total. Similar to SSE to support higher bit depths

//          // YGJ 21st Aug 2014
//          Int HadDiff[64];

//          //---------
//          // YGJ Mon 25th Aug 2014
//          // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
//          // If asymmetrical then proceed with APCwHad else just perform Had.
//          // Note the plus 255 is required to centre it at zero

//          // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
//          //---

////          // Distance
////          int dist4 = 2; //5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
////          int dist2 = 1; //3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
////          int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value


//          // piCur and piOrg Already initialised to the first row
//          int Top = 0; // Excluding the corners (1-6)
//          //HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[5], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[3], dist2);
//          //HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[6], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[3], dist1);
//          //HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[7], dist4);
//          //HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[6], dist2) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[5], dist1);
//          //HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[7], dist2);
//          //HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[7], dist1);

//          HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] =TComRdCost::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//          HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] =TComRdCost::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//          HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] =TComRdCost::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//          HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] =TComRdCost::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//          HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] =TComRdCost::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//          HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] =TComRdCost::HadAPC((int)piOrg[6], (int)piCur[6], 0);


//          int Left = 0; // Excluding the corners (1-6) (Left Hand Side) (8, 16, 24, 32, 40 ,48)
//          int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)

//          piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)

//          //HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          //HadDiff[15] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          //HadDiff[23] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          //HadDiff[31] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          //HadDiff[39] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          //HadDiff[47] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          //HadDiff[55] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[15] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[23] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[31] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[39] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[47] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//		  piCur += iStrideCur; piOrg += iStrideOrg;
//		  HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//		  HadDiff[55] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);


//          //piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)

//          //HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[15] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[23] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[31] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[39] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[47] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[55] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);


//          //---
//          piCur += iStrideCur; piOrg += iStrideOrg;

//          int Bottom = 0;  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//          // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//          //HadDiff[57] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[57] = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[5], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[3], dist2);
//          //HadDiff[58] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[58] = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[6], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[3], dist1);
//          //HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[7], dist4);
//          //HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[6], dist2) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[5], dist1);
//          //HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[7], dist2);
//          //HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[7], dist1);

//          HadDiff[57] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[57] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//          HadDiff[58] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[58] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//          HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//          HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//          HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//          HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);

//          //---

//          //---

//        //  // ----------
//        //  // Vertical

//        ////  //---
  
//        //  // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[8], (int)piCur[40], dist4) + TComRdCost::HadAPC((int)piOrg[8], (int)piCur[24], dist2);
//        //  Left += iTemp; APCVal[8] += iTemp;
//		  		  //
//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[16], (int)piCur[48], dist4) + TComRdCost::HadAPC((int)piOrg[16], (int)piCur[32], dist2);
//        //  Left += iTemp; APCVal[16] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[24], (int)piCur[56], dist4);
//        //  Left += iTemp; APCVal[24] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[32], (int)piCur[48], dist2) + TComRdCost::HadAPC((int)piOrg[32], (int)piCur[40], dist1);
//        //  Left += iTemp; APCVal[32] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[40], (int)piCur[56], dist2);
//        //  Left += iTemp; APCVal[40] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[48], (int)piCur[56], dist1);
//        //  Left += iTemp; APCVal[48] += iTemp;

		  
//        //  // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48
//		      //
//        //  // Top (like Left in horizonal mode)
//		  		  //
//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[33], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[17], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[9], dist1);
//        //  Top += iTemp; APCVal[1] += iTemp;
//		  		  //
//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[34], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[18], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[10], dist1);
//        //  Top += iTemp; APCVal[2] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[35], dist4) + TComRdCost::HadAPC((int)piOrg[3], (int)piCur[19], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[11], dist1);
//        //  Top += iTemp; APCVal[3] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[36], dist4) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[20], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[12], dist1);
//        //  Top += iTemp; APCVal[4] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[37], dist4) + TComRdCost::HadAPC((int)piOrg[5], (int)piCur[21], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[13], dist1);
//        //  Top += iTemp; APCVal[5] += iTemp;

//        //  iTemp  = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[38], dist4) + TComRdCost::HadAPC((int)piOrg[6], (int)piCur[22], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[14], dist1);
//        //  Top += iTemp; APCVal[6] += iTemp;


//        //     int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)
    
//        //     // Ignore Corners, this leaves 15, 23, 31, 39, 47, 55

//        //     Right += APCVal[15] = TComRdCost::HadAPC((int)piOrg[15], (int)piCur[47], dist4) + TComRdCost::HadAPC((int)piOrg[15], (int)piCur[31], dist2);
//        //     Right += APCVal[23] = TComRdCost::HadAPC((int)piOrg[23], (int)piCur[55], dist4) + TComRdCost::HadAPC((int)piOrg[23], (int)piCur[31], dist1);
//        //     Right += APCVal[31] = TComRdCost::HadAPC((int)piOrg[31], (int)piCur[63], dist4);
//        //     Right += APCVal[39] = TComRdCost::HadAPC((int)piOrg[39], (int)piCur[55], dist2) + TComRdCost::HadAPC((int)piOrg[23], (int)piCur[47], dist1);
//        //     Right += APCVal[47] = TComRdCost::HadAPC((int)piOrg[47], (int)piCur[63], dist2);
//        //     Right += APCVal[55] = TComRdCost::HadAPC((int)piOrg[55], (int)piCur[63], dist1);


//          //---------
//          // Top, Bottom, Left and Right contain APC socre , no need to divide result by  2, to get APC/2, APC_NegAndPos_1D is APC/2 as standard
//          // Note: this is done without corner information, which will be done later with the inner square/block.
//          // This approach without corners avoids duplication of values and ensures the test is simple.
//          // Testing on random sample vector observations of 30k which contained pixel and APC info, 10k were selected, similar to the approach with corners, 11k, 2/3 reduction.
//          // This means that a simple test can then decide if a more complex process should occur, which is only needed 1/3 of the time.
//          // This is dependent on video source/content and encoding settings, but it indicates that the encoding will dynamically change, hence be adaptive.

//          // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//          UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//          //if (AbsAsymCost > 28)
//          //{
//          //  //================================================
//          //  //Log Threshold by CU and Frame number

//          //  //    ofstream CalcValues;

//          //  //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//          //   ofstream ThreshLog;
//          //   ThreshLog.open ("ThresholdLog_Dec_PreAssess_HAD8x8.txt", ios::out | ios::app);
//          //
//          //   UInt MaxCUx = width >> 6;
//          //   UInt MaxCUy = height >> 6;
//          //   UInt CUx = x >> 6;
//          //   UInt CUy = y >> 6;

//          //   ThreshLog << poc << " ," << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//          //   ThreshLog.close();

//          //  //================================================
//          //}

//          // Test - Conditional
//          // When Always False  (as in perform Had Only) it is the fastest (least additional processing required.
//          //bool ProceedwAPC = AbsAsymCost > 64? true : false; // Currently
//          //bool ProceedwAPC = AbsAsymCost > 0? true : false;  // Control - yes it does make it the same as HadwAPC (w/o PreAssess)
//          //bool ProceedwAPC = AbsAsymCost > 2? true : false;  // Tested out 4, 8, 16, 32, (2 is like 4)

//          // Sun 23rd Nov 2014
//          // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
//          // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//          // Over 48 million observations were logged, which represented 8.7 million unique records.
//          //UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?
//          UInt Threshold = 32; // Does a threshold of 28 sufficient as 16?

//          ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//          //---------
//          // Depending if the condition is met, different levels of processing is applied.
//          // False means Had only. (existing)
//          // True means Had with APC (proposed).

//          // Step 3) Use a case statement on the bool of the threshold.
//          //         For false, use existing method of SAD only on the inner block.
//          //         For true, apply proposed method on inner block.
//          // This means that processing load adapts dynamically to the conditions of the content.

//          // reset piCur and piOrg
//          piCur = myCur;
//          piOrg = myOrg;

//          // create pointer to an array and set it in ProceedwAPC.
//          // Set the pointer to point to the HadDiff or HadwAPCDiff.
//          // Refer to the pointer in the Hadamard Calculation.

//          Int *ptrDiff;

//          switch(ProceedwAPC)
//          {
//          case false:
//              {
//                  // Top corners first (Top Left and Top Right), then inner square.
//                  HadDiff[0] = piOrg[0] - piCur[0];
//                  HadDiff[7] = piOrg[7] - piCur[7];

//                  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
//                  {

//                      // Remember start from the second row, since the first row  has already been done
//                      piCur += iStrideCur;
//                      piOrg += iStrideOrg;

//                      //The inner square
//                      // No Zero
//                      HadDiff[k+1] = piOrg[1] - piCur[1];
//                      HadDiff[k+2] = piOrg[2] - piCur[2];
//                      HadDiff[k+3] = piOrg[3] - piCur[3];
//                      HadDiff[k+4] = piOrg[4] - piCur[4];
//                      HadDiff[k+5] = piOrg[5] - piCur[5];
//                      HadDiff[k+6] = piOrg[6] - piCur[6];
//                      // No Seven
//                  }

//                  // Bottom Corners
//                  piCur += iStrideCur;
//                  piOrg += iStrideOrg;

//                  HadDiff[56] = piOrg[0] - piCur[0];
//                  HadDiff[63] = piOrg[7] - piCur[7];

//                  // Assign ptr to Hadamard difference
//                  ptrDiff = HadAllZero64; // Array of Zeros
//              }
//              break;

//          case true:
//              {

//                //  // Top corners first (Top Left and Top Right), then inner square.
//                //  HadDiff[0] = iTemp = piOrg[0] - piCur[0];
				  
//                //  APCVal[0] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) +
//                //              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) +
//                //              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1) +
//                //              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[32], dist4) +
//                //              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[16], dist2) +
//                //              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[8], dist1);
				  
//                //  HadDiff[7] = iTemp = piOrg[7] - piCur[7];
				  
//                //  APCVal[7] = TComRdCost::HadAPC((int)piOrg[7], (int)piCur[39], dist4) +
//                //              TComRdCost::HadAPC((int)piOrg[7], (int)piCur[23], dist2) +
//                //              TComRdCost::HadAPC((int)piOrg[7], (int)piCur[15], dist1);

//                //  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
//                //  {
//                //      // Remember start from the second row, since the first row  has already been done
//                //      piCur += iStrideCur;
//                //      piOrg += iStrideOrg;

//                //      //The inner square
//                //      // No Zero
//                //      HadDiff[k+1] = iTemp = piOrg[1] - piCur[1];
//                //      APCVal[k+1] = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[5], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[3], dist2);

//                //      HadDiff[k+2] = iTemp = piOrg[2] - piCur[2];
//                //      APCVal[k+2] = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[6], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[3], dist1);

//                //      HadDiff[k+3] = iTemp = piOrg[3] - piCur[3];
//                //      APCVal[k+3] = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[7], dist4);

//                //      HadDiff[k+4] = iTemp = piOrg[4] - piCur[4];
//                //      APCVal[k+4] = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[6], dist2) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[5], dist1);

//                //      HadDiff[k+5] = iTemp = piOrg[5] - piCur[5];
//                //      APCVal[k+5] = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[7], dist2);

//                //      HadDiff[k+6] = iTemp = piOrg[6] - piCur[6];
//                //      APCVal[k+6] = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[7], dist1);
//                //      // No Seven
//                //  }

//                //  // Bottom Corners
//                //  piCur += iStrideCur;
//                //  piOrg += iStrideOrg;

//                //  HadDiff[56] = iTemp = piOrg[0] - piCur[0];
//                //  APCVal[56] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
				  
//                //  HadDiff[63] = iTemp = piOrg[7] - piCur[7];
//                //  APCVal[63] = 0; //TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//                //// Rotate 90 degrees to perform vertical stage

//                //for( k = 1; k < 7; k ++ ) // Just the remaining inner square, between the edge rows and columns
//                //{
//                //    // Remember start from the second row, since the first row  has already been done

//                //    //The inner square
//                //    // No Zero

//                //    // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//                //    APCVal[k+ 8] +=   TComRdCost::HadAPC((int)piOrg[k + 8], (int)piCur[k + 40], dist4) + TComRdCost::HadAPC((int)piOrg[k + 8], (int)piCur[k + 24], dist2);
//                //    APCVal[k+ 16] +=  TComRdCost::HadAPC((int)piOrg[k + 16], (int)piCur[k + 48], dist4) + TComRdCost::HadAPC((int)piOrg[k + 16], (int)piCur[k + 24], dist1);
//                //    APCVal[k+ 24] +=  TComRdCost::HadAPC((int)piOrg[k + 3], (int)piCur[k + 7], dist4);
//                //    APCVal[k+ 32] +=  TComRdCost::HadAPC((int)piOrg[k + 4], (int)piCur[k + 6], dist2) + TComRdCost::HadAPC((int)piOrg[k + 4], (int)piCur[k + 5], dist1);
//                //    APCVal[k+ 40] +=  TComRdCost::HadAPC((int)piOrg[k + 5], (int)piCur[k + 7], dist2);
//                //    APCVal[k+ 48] +=  TComRdCost::HadAPC((int)piOrg[k + 6], (int)piCur[k + 7], dist1);
//                //}

//				  // Top corners first (Top Left and Top Right), then inner square.
//				  HadDiff[0] = iTemp = piOrg[0] - piCur[0]; APCVal[0] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//				  HadDiff[7] = iTemp = piOrg[7] - piCur[7]; APCVal[7] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//				  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
//				  {
//					  // Remember start from the second row, since the first row  has already been done
//					  piCur += iStrideCur;
//					  piOrg += iStrideOrg;

//					  //The inner square
//					  // No Zero
//					  HadDiff[k+1] = iTemp = piOrg[1] - piCur[1]; APCVal[k+1] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//					  HadDiff[k+2] = iTemp = piOrg[2] - piCur[2]; APCVal[k+2] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//					  HadDiff[k+3] = iTemp = piOrg[3] - piCur[3]; APCVal[k+3] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//					  HadDiff[k+4] = iTemp = piOrg[4] - piCur[4]; APCVal[k+4] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//					  HadDiff[k+5] = iTemp = piOrg[5] - piCur[5]; APCVal[k+5] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//					  HadDiff[k+6] = iTemp = piOrg[6] - piCur[6]; APCVal[k+6] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);
//					  // No Seven
//				  }

//				  // Bottom Corners
//				  piCur += iStrideCur;
//				  piOrg += iStrideOrg;

//				  HadDiff[56] = iTemp = piOrg[0] - piCur[0]; APCVal[56] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//				  HadDiff[63] = iTemp = piOrg[7] - piCur[7]; APCVal[63] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//                  ptrDiff = APCVal;
//              }
//              break;
//          }

//        ////----------------------------



//            //int i, j, jj;//, k;


//            // End of Multi-Scale APC
//            //=============================
//            // Beginning of Hadamard with APC

//            //Now to add/subtract to the Hadamard Diff.
//            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
//            //int APCscale = 0;

//            //iSumHad =0;

//            //horizontal
//            for (j=0; j < 8; j++)
//            {
//              jj = j << 3;
//              //---------------------
//              // Changed to support Had with Integrated APC subject to meeting threshold.

//              // Additional Pixel Cost (APC) - Add APC to the difference
////			  m2[j][0] = (HadDiff[jj  ] + ptrDiff[jj  ]) + (HadDiff[jj+4] + ptrDiff[jj+4]);
////			  m2[j][1] = (HadDiff[jj+1] + ptrDiff[jj+1]) + (HadDiff[jj+5] + ptrDiff[jj+5]);
////			  m2[j][2] = (HadDiff[jj+2] + ptrDiff[jj+2]) + (HadDiff[jj+6] + ptrDiff[jj+6]);
////			  m2[j][3] = (HadDiff[jj+3] + ptrDiff[jj+3]) + (HadDiff[jj+7] + ptrDiff[jj+7]);
////			  m2[j][4] = (HadDiff[jj  ] + ptrDiff[jj  ]) - (HadDiff[jj+4] + ptrDiff[jj+4]);
////			  m2[j][5] = (HadDiff[jj+1] + ptrDiff[jj+1]) - (HadDiff[jj+5] + ptrDiff[jj+5]);
////			  m2[j][6] = (HadDiff[jj+2] + ptrDiff[jj+2]) - (HadDiff[jj+6] + ptrDiff[jj+6]);
////			  m2[j][7] = (HadDiff[jj+3] + ptrDiff[jj+3]) - (HadDiff[jj+7] + ptrDiff[jj+7]);

//              m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
//              m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
//              m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
//              m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
//              m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
//              m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
//              m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
//              m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];

//              m1[j][0] = m2[j][0] + m2[j][2];
//              m1[j][1] = m2[j][1] + m2[j][3];
//              m1[j][2] = m2[j][0] - m2[j][2];
//              m1[j][3] = m2[j][1] - m2[j][3];
//              m1[j][4] = m2[j][4] + m2[j][6];
//              m1[j][5] = m2[j][5] + m2[j][7];
//              m1[j][6] = m2[j][4] - m2[j][6];
//              m1[j][7] = m2[j][5] - m2[j][7];

//              m2[j][0] = m1[j][0] + m1[j][1];
//              m2[j][1] = m1[j][0] - m1[j][1];
//              m2[j][2] = m1[j][2] + m1[j][3];
//              m2[j][3] = m1[j][2] - m1[j][3];
//              m2[j][4] = m1[j][4] + m1[j][5];
//              m2[j][5] = m1[j][4] - m1[j][5];
//              m2[j][6] = m1[j][6] + m1[j][7];
//              m2[j][7] = m1[j][6] - m1[j][7];

//              //---------------------
//              // Now for Had on APC
//              switch(ProceedwAPC)
//              {
//              case true:
//                      {
//                          // Changed to support Had with Integrated APC subject to meeting threshold.
//                          m2APC[j][0] = (ptrDiff[jj  ] ) + (ptrDiff[jj+4] );
//                          m2APC[j][1] = (ptrDiff[jj+1] ) + (ptrDiff[jj+5] );
//                          m2APC[j][2] = (ptrDiff[jj+2] ) + (ptrDiff[jj+6] );
//                          m2APC[j][3] = (ptrDiff[jj+3] ) + (ptrDiff[jj+7] );
//                          m2APC[j][4] = (ptrDiff[jj  ] ) - (ptrDiff[jj+4] );
//                          m2APC[j][5] = (ptrDiff[jj+1] ) - (ptrDiff[jj+5] );
//                          m2APC[j][6] = (ptrDiff[jj+2] ) - (ptrDiff[jj+6] );
//                          m2APC[j][7] = (ptrDiff[jj+3] ) - (ptrDiff[jj+7] );

//                          m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
//                          m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
//                          m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
//                          m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
//                          m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
//                          m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
//                          m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
//                          m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

//                          m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
//                          m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
//                          m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
//                          m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
//                          m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
//                          m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
//                          m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
//                          m2APC[j][7] = m1APC[j][6] - m1APC[j][7];
//                      }
//              }

//            }

//            //vertical
//            for (i=0; i < 8; i++)
//            {
//              m3[0][i] = m2[0][i] + m2[4][i];
//              m3[1][i] = m2[1][i] + m2[5][i];
//              m3[2][i] = m2[2][i] + m2[6][i];
//              m3[3][i] = m2[3][i] + m2[7][i];
//              m3[4][i] = m2[0][i] - m2[4][i];
//              m3[5][i] = m2[1][i] - m2[5][i];
//              m3[6][i] = m2[2][i] - m2[6][i];
//              m3[7][i] = m2[3][i] - m2[7][i];

//              m1[0][i] = m3[0][i] + m3[2][i];
//              m1[1][i] = m3[1][i] + m3[3][i];
//              m1[2][i] = m3[0][i] - m3[2][i];
//              m1[3][i] = m3[1][i] - m3[3][i];
//              m1[4][i] = m3[4][i] + m3[6][i];
//              m1[5][i] = m3[5][i] + m3[7][i];
//              m1[6][i] = m3[4][i] - m3[6][i];
//              m1[7][i] = m3[5][i] - m3[7][i];

//              m2[0][i] = m1[0][i] + m1[1][i];
//              m2[1][i] = m1[0][i] - m1[1][i];
//              m2[2][i] = m1[2][i] + m1[3][i];
//              m2[3][i] = m1[2][i] - m1[3][i];
//              m2[4][i] = m1[4][i] + m1[5][i];
//              m2[5][i] = m1[4][i] - m1[5][i];
//              m2[6][i] = m1[6][i] + m1[7][i];
//              m2[7][i] = m1[6][i] - m1[7][i];

//              //---------------------
//              // Now for Had on APC
//              switch(ProceedwAPC)
//              {
//              case true:
//                      {
//                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
//                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
//                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
//                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
//                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
//                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
//                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
//                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

//                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
//                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
//                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
//                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
//                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
//                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
//                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
//                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

//                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
//                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
//                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
//                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
//                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
//                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
//                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
//                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];
//                      }
//              }

//            }

//            for (i = 0; i < 8; i++)
//            {
//              for (j = 0; j < 8; j++)
//              {
//                iSumHad += abs(m2[i][j]);
//                sadAPC += ProceedwAPC == true? abs(m2APC[i][j]) : 0;
//              }
//            }

//            iSumHad=((iSumHad+2)>>2);
//            sadAPC=((sadAPC+2)>>2);

//        }

//        yInt = yInt_Rec;

////        // Convert YUV to RGB

//        int r=0, g=0, b=0;


//        //if (HadRegion == true)
//        if (ProceedwAPC == true)
//        {

////			int blkwidth = 8;

//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = 0; //(int)log2((double)blkwidth) - 3;
            
//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//            //APC fixed down scale of 1/16
//            iSumHad += ProceedwAPC == true? (sadAPC >> 4) : 0;

//            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////            int val = dist < (halfMaxThreshold >> 2) ? 0
////                : dist < (halfMaxThreshold >> 1) ? 1
////                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("Pre Assess Had8x8w-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;
			
//            //------------------

//            //switch (val)
//            //{
//            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//            //		break;
//            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//            //		break;
//            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //}

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt;
//        }

//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//        // Partitioning -- Not Working?
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0; //yInt_RmO;
//          g = 0; //yInt_RmO;
//          b = 0; //yInt_RmO;
//        }



//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      //piY += YStride;
//      piY_Org += YStride;
//      piY_Rec += YStrideRec;
//      piY_Part += YStrideRec;


//    }


//    free(ptrY_Org8x8);
//    free(ptrY_Rec8x8);

//    free(ptrY_Org);

//    free(ptrY_Rec);

//    free(ptrY_Part);


//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//}




//Void TAppDecTop::saveFrameAsPNG_HadPreAssess_APCms(TComPic* pcPic)
//{

//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  //int pcPOC = pcPic1->getPOC(); // Decode order from reading from YUV file.

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
//  else
//      snprintf(strpoc, sizeof(strpoc), "%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_Had8x8withPreAssessAPCms_DistortionHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
//    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;

//    for ( unsigned y = 0; y < height; y++ )
//    {
//      for ( unsigned x = 0; x < width; x++ )
//      {
//        unsigned yloc = y*width+x;

//        // allocate YUV value
//        int yInt = 0; //, uInt = 0, vInt = 0;

//        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//        int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//        // seems fine here
//        if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
//            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);

//        //bool HadRegion = false;
//        Distortion iSumHad =0;

//        Distortion sadAPC = 0;
//        bool ProceedwAPC = false;

//        if ((y < (height-8)) && (x < (width-8)))
//        {
//          //HadRegion = true;


//          for ( unsigned n = 0; n < 8; n++ )
//          {
//              for ( unsigned m = 0; m < 8; m++ )
//              {
//                  // y*width + x
//                  unsigned yloc8x8 = n*8+m;

//                  //Distortion y_Org =
//                  ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
//                  //Distortion y_Rec =
//                  ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);

//                  ////------------------
//                  //// YGJ 12th July 2014
//                  //// Please note here the encoder assumes current/reconstructed block is `all zero block'
//                  //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//                  //// a -- set up and initialise variables

//                  ////------------------

//              }
//          }


//          //int HadDiff[64];
//          //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
//          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//          //Int APCVal[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
//          //Int OrgPx[64], RecPx[64];
//          TCoeff m1APC[8][8], m2APC[8][8], m3APC[8][8]; // YGJ 3rd Nov 2014 - APC version going through Hadamard process



//          // Here Had with integrated APC is applied based upon a pre-assessment.
//          // Inspired from the investigation of Hadamard with multi-scale APC under rate control.
//          // Under rate control the perceptual cost activity (via APC) remained high for asymmetric distributed observations
//          // Having a pre-assessment which measures the APC for the block edges can determine whether Had or Had with integrated APC should be performed.
//          // Unlike Hadamard with multi-scale APC under rate control, to save proccessing time Hadamard with integrated APC is performed.

//          Int iStrideOrg = 8;
//          Int iStrideCur = 8;

//          Int k, i, j, jj;
//          // Used now
//          Pel* piOrg = ptrY_Org8x8; //piOrg;
//          Pel* piCur = ptrY_Rec8x8; //piCur;
//          // Used later
//          Pel* myOrg = ptrY_Org8x8; //piOrg;
//          Pel* myCur = ptrY_Rec8x8; //piCur;
//          //
//          Int APCVal[64];
//          Int iTemp = 0;  // Usomg Int here as difference may be negative.
//          //UInt BitDiff = (g_bitDepth[0]-8); // Used in scaling down SAD when higher bit depths are used, applied at the total. Similar to SSE to support higher bit depths

//          // YGJ 21st Aug 2014
//          Int HadDiff[64];

//          //---------
//          // YGJ Mon 25th Aug 2014
//          // Like in Rate Control during Had8x8 test (and store) Top, Bottom (rows), Left and Right (columns) for asymmetry.
//          // If asymmetrical then proceed with APCwHad else just perform Had.
//          // Note the plus 255 is required to centre it at zero

//          // Step 1) gather APC cost for Top, Left, Right and Bottom edges (without corners).
//          //---

//          // Distance
//          int dist4 = 2; //5; // 1/32 * 1/2  = 1/64  - This avoids making the change very extreme
//          int dist2 = 1; //3; // 1/8 * 1/2 = 1/16 - This is used as a half-way point.
//          int dist1 = 0; // 1/2  = 1/2  - Must be zero as APC has already been halved. Also most crucial value


//          // piCur and piOrg Already initialised to the first row
//          int Top = 0; // Excluding the corners (1-6)
//          HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[5], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[3], dist2);
//          HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[6], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[3], dist1);
//          HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[7], dist4);
//          HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[6], dist2) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[5], dist1);
//          HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[7], dist2);
//          HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[7], dist1);

//          //HadDiff[1] = iTemp = piOrg[1] - piCur[1];  Top += APCVal[1] =TComRdCost::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//          //HadDiff[2] = iTemp = piOrg[2] - piCur[2];  Top += APCVal[2] =TComRdCost::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//          //HadDiff[3] = iTemp = piOrg[3] - piCur[3];  Top += APCVal[3] =TComRdCost::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//          //HadDiff[4] = iTemp = piOrg[4] - piCur[4];  Top += APCVal[4] =TComRdCost::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//          //HadDiff[5] = iTemp = piOrg[5] - piCur[5];  Top += APCVal[5] =TComRdCost::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//          //HadDiff[6] = iTemp = piOrg[6] - piCur[6];  Top += APCVal[6] =TComRdCost::HadAPC((int)piOrg[6], (int)piCur[6], 0);


//          int Left = 0; // Excluding the corners (1-6) (Left Hand Side) (8, 16, 24, 32, 40 ,48)
//          //int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)

//          piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)

//          HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          HadDiff[15] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          piCur += iStrideCur; piOrg += iStrideOrg;
//          HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          HadDiff[23] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          piCur += iStrideCur; piOrg += iStrideOrg;
//          HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          HadDiff[31] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          piCur += iStrideCur; piOrg += iStrideOrg;
//          HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          HadDiff[39] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          piCur += iStrideCur; piOrg += iStrideOrg;
//          HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          HadDiff[47] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          piCur += iStrideCur; piOrg += iStrideOrg;
//          HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
//          HadDiff[55] = iTemp = piOrg[7] - piCur[7];  //Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);


//          //piCur += iStrideCur; piOrg += iStrideOrg; // Skip first row (left & right corners)

//          //HadDiff[8]  = iTemp = piOrg[0] - piCur[0];  Left += APCVal[8]  =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[15] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[15] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[16] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[16] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[23] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[23] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[24] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[24] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[31] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[31] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[32] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[32] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[39] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[39] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[40] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[40] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[47] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[47] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//          //piCur += iStrideCur; piOrg += iStrideOrg;
//          //HadDiff[48] = iTemp = piOrg[0] - piCur[0];  Left += APCVal[48] =TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[0], 0);
//          //HadDiff[55] = iTemp = piOrg[7] - piCur[7];  Right += APCVal[55] =TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);


//          //---
//          piCur += iStrideCur; piOrg += iStrideOrg;

//          int Bottom = 0;  // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//          // Excluding the corners (1-6) on last row ( 57, 58, 59, 60, 61, 62)
//          HadDiff[57] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[57] = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[5], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[3], dist2);
//          HadDiff[58] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[58] = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[6], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[3], dist1);
//          HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[7], dist4);
//          HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[6], dist2) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[5], dist1);
//          HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[7], dist2);
//          HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[7], dist1);

//          //HadDiff[57] = iTemp = piOrg[1] - piCur[1];  Bottom += APCVal[57] =TComRdCost ::HadAPC((int)piOrg[1], (int)piCur[1], 0);
//          //HadDiff[58] = iTemp = piOrg[2] - piCur[2];  Bottom += APCVal[58] =TComRdCost ::HadAPC((int)piOrg[2], (int)piCur[2], 0);
//          //HadDiff[59] = iTemp = piOrg[3] - piCur[3];  Bottom += APCVal[59] =TComRdCost ::HadAPC((int)piOrg[3], (int)piCur[3], 0);
//          //HadDiff[60] = iTemp = piOrg[4] - piCur[4];  Bottom += APCVal[60] =TComRdCost ::HadAPC((int)piOrg[4], (int)piCur[4], 0);
//          //HadDiff[61] = iTemp = piOrg[5] - piCur[5];  Bottom += APCVal[61] =TComRdCost ::HadAPC((int)piOrg[5], (int)piCur[5], 0);
//          //HadDiff[62] = iTemp = piOrg[6] - piCur[6];  Bottom += APCVal[62] =TComRdCost ::HadAPC((int)piOrg[6], (int)piCur[6], 0);

//          //---

//          //---

//          // ----------
//          // Vertical

//        //  //---
  
//          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//          iTemp  = TComRdCost::HadAPC((int)piOrg[8], (int)piCur[40], dist4) + TComRdCost::HadAPC((int)piOrg[8], (int)piCur[24], dist2);
//          Left += iTemp; APCVal[8] += iTemp;
		  		  		  
//          iTemp  = TComRdCost::HadAPC((int)piOrg[16], (int)piCur[48], dist4) + TComRdCost::HadAPC((int)piOrg[16], (int)piCur[32], dist2);
//          Left += iTemp; APCVal[16] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[24], (int)piCur[56], dist4);
//          Left += iTemp; APCVal[24] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[32], (int)piCur[48], dist2) + TComRdCost::HadAPC((int)piOrg[32], (int)piCur[40], dist1);
//          Left += iTemp; APCVal[32] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[40], (int)piCur[56], dist2);
//          Left += iTemp; APCVal[40] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[48], (int)piCur[56], dist1);
//          Left += iTemp; APCVal[48] += iTemp;

		  
//          // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48
		      
//          // Top (like Left in horizonal mode)
		  		  
//          iTemp  = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[33], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[17], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[9], dist1);
//          Top += iTemp; APCVal[1] += iTemp;
		  		  		  
//          iTemp  = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[34], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[18], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[10], dist1);
//          Top += iTemp; APCVal[2] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[35], dist4) + TComRdCost::HadAPC((int)piOrg[3], (int)piCur[19], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[11], dist1);
//          Top += iTemp; APCVal[3] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[36], dist4) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[20], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[12], dist1);
//          Top += iTemp; APCVal[4] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[37], dist4) + TComRdCost::HadAPC((int)piOrg[5], (int)piCur[21], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[13], dist1);
//          Top += iTemp; APCVal[5] += iTemp;

//          iTemp  = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[38], dist4) + TComRdCost::HadAPC((int)piOrg[6], (int)piCur[22], dist2) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[14], dist1);
//          Top += iTemp; APCVal[6] += iTemp;


//             int Right = 0; // Excluding the corners (1-6) (Right Hand Side) (15, 23, 31, 39, 47 ,55)
    
//             // Ignore Corners, this leaves 15, 23, 31, 39, 47, 55

//             Right += APCVal[15] = TComRdCost::HadAPC((int)piOrg[15], (int)piCur[47], dist4) + TComRdCost::HadAPC((int)piOrg[15], (int)piCur[31], dist2);
//             Right += APCVal[23] = TComRdCost::HadAPC((int)piOrg[23], (int)piCur[55], dist4) + TComRdCost::HadAPC((int)piOrg[23], (int)piCur[31], dist1);
//             Right += APCVal[31] = TComRdCost::HadAPC((int)piOrg[31], (int)piCur[63], dist4);
//             Right += APCVal[39] = TComRdCost::HadAPC((int)piOrg[39], (int)piCur[55], dist2) + TComRdCost::HadAPC((int)piOrg[23], (int)piCur[47], dist1);
//             Right += APCVal[47] = TComRdCost::HadAPC((int)piOrg[47], (int)piCur[63], dist2);
//             Right += APCVal[55] = TComRdCost::HadAPC((int)piOrg[55], (int)piCur[63], dist1);


//          //---------
//          // Top, Bottom, Left and Right contain APC socre , no need to divide result by  2, to get APC/2, APC_NegAndPos_1D is APC/2 as standard
//          // Note: this is done without corner information, which will be done later with the inner square/block.
//          // This approach without corners avoids duplication of values and ensures the test is simple.
//          // Testing on random sample vector observations of 30k which contained pixel and APC info, 10k were selected, similar to the approach with corners, 11k, 2/3 reduction.
//          // This means that a simple test can then decide if a more complex process should occur, which is only needed 1/3 of the time.
//          // This is dependent on video source/content and encoding settings, but it indicates that the encoding will dynamically change, hence be adaptive.

//          // Step 2) Calc whether abs(abs(T-B)-abs(L-R)) is greater than the threshold.

//          UInt AbsAsymCost = abs(abs(Top-Bottom)-abs(Left-Right));

//          //if (AbsAsymCost > 28)
//          //{
//          //  //================================================
//          //  //Log Threshold by CU and Frame number

//          //  //    ofstream CalcValues;

//          //  //    CalcValues.open ("CalcValues_At_Pred_HAD8x8.txt", ios::out | ios::app);

//          //   ofstream ThreshLog;
//          //   ThreshLog.open ("ThresholdLog_Dec_PreAssess_HAD8x8.txt", ios::out | ios::app);
//          //
//          //   UInt MaxCUx = width >> 6;
//          //   UInt MaxCUy = height >> 6;
//          //   UInt CUx = x >> 6;
//          //   UInt CUy = y >> 6;

//          //   ThreshLog << poc << " ," << MaxCUx << ", " << MaxCUy << ", " << CUx << ", " << CUy << ", " << width << ", " << height << ", " << x << ", " << y << ", " << AbsAsymCost << endl;

//          //   ThreshLog.close();

//          //  //================================================
//          //}

//          // Test - Conditional
//          // When Always False  (as in perform Had Only) it is the fastest (least additional processing required.
//          //bool ProceedwAPC = AbsAsymCost > 64? true : false; // Currently
//          //bool ProceedwAPC = AbsAsymCost > 0? true : false;  // Control - yes it does make it the same as HadwAPC (w/o PreAssess)
//          //bool ProceedwAPC = AbsAsymCost > 2? true : false;  // Tested out 4, 8, 16, 32, (2 is like 4)

//          // Sun 23rd Nov 2014
//          // Having analysed log calculated values the median value for AbsAsymCost was 48 for APC Multiscale (used in Had and RC Had).
//          // This was based upon a 3 frame test under Random Access configuration for CrowdRun HD video sequence.
//          // Over 48 million observations were logged, which represented 8.7 million unique records.
//          //UInt Threshold = 28; // Does a threshold of 28 sufficient as 16?
//          UInt Threshold = 48; // Does a threshold of 28 sufficient as 16?

//          ProceedwAPC = AbsAsymCost > Threshold ? true : false;  // 16 Found to be highest point to at which most APC features are retained

//          //---------
//          // Depending if the condition is met, different levels of processing is applied.
//          // False means Had only. (existing)
//          // True means Had with APC (proposed).

//          // Step 3) Use a case statement on the bool of the threshold.
//          //         For false, use existing method of SAD only on the inner block.
//          //         For true, apply proposed method on inner block.
//          // This means that processing load adapts dynamically to the conditions of the content.

//          // reset piCur and piOrg
//          piCur = myCur;
//          piOrg = myOrg;

//          // create pointer to an array and set it in ProceedwAPC.
//          // Set the pointer to point to the HadDiff or HadwAPCDiff.
//          // Refer to the pointer in the Hadamard Calculation.

//          Int *ptrDiff;

//          switch(ProceedwAPC)
//          {
//          case false:
//              {
//                  // Top corners first (Top Left and Top Right), then inner square.
//                  HadDiff[0] = piOrg[0] - piCur[0];
//                  HadDiff[7] = piOrg[7] - piCur[7];

//                  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
//                  {

//                      // Remember start from the second row, since the first row  has already been done
//                      piCur += iStrideCur;
//                      piOrg += iStrideOrg;

//                      //The inner square
//                      // No Zero
//                      HadDiff[k+1] = piOrg[1] - piCur[1];
//                      HadDiff[k+2] = piOrg[2] - piCur[2];
//                      HadDiff[k+3] = piOrg[3] - piCur[3];
//                      HadDiff[k+4] = piOrg[4] - piCur[4];
//                      HadDiff[k+5] = piOrg[5] - piCur[5];
//                      HadDiff[k+6] = piOrg[6] - piCur[6];
//                      // No Seven
//                  }

//                  // Bottom Corners
//                  piCur += iStrideCur;
//                  piOrg += iStrideOrg;

//                  HadDiff[56] = piOrg[0] - piCur[0];
//                  HadDiff[63] = piOrg[7] - piCur[7];

//                  // Assign ptr to Hadamard difference
//                  ptrDiff = HadAllZero64; // Array of Zeros
//              }
//              break;

//          case true:
//              {

//                  // Top corners first (Top Left and Top Right), then inner square.
//                  HadDiff[0] = iTemp = piOrg[0] - piCur[0];
				  
//                  APCVal[0] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) +
//                              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) +
//                              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[1], dist1) +
//                              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[32], dist4) +
//                              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[16], dist2) +
//                              TComRdCost::HadAPC((int)piOrg[0], (int)piCur[8], dist1);
				  
//                  HadDiff[7] = iTemp = piOrg[7] - piCur[7];
				  
//                  APCVal[7] = TComRdCost::HadAPC((int)piOrg[7], (int)piCur[39], dist4) +
//                              TComRdCost::HadAPC((int)piOrg[7], (int)piCur[23], dist2) +
//                              TComRdCost::HadAPC((int)piOrg[7], (int)piCur[15], dist1);

//                  for( k = 8; k < 56; k += 8 ) // Just the remaining inner square, between the edge rows and columns
//                  {
//                      // Remember start from the second row, since the first row  has already been done
//                      piCur += iStrideCur;
//                      piOrg += iStrideOrg;

//                      //The inner square
//                      // No Zero
//                      HadDiff[k+1] = iTemp = piOrg[1] - piCur[1];
//                      APCVal[k+1] = TComRdCost::HadAPC((int)piOrg[1], (int)piCur[5], dist4) + TComRdCost::HadAPC((int)piOrg[1], (int)piCur[3], dist2);

//                      HadDiff[k+2] = iTemp = piOrg[2] - piCur[2];
//                      APCVal[k+2] = TComRdCost::HadAPC((int)piOrg[2], (int)piCur[6], dist4) + TComRdCost::HadAPC((int)piOrg[2], (int)piCur[3], dist1);

//                      HadDiff[k+3] = iTemp = piOrg[3] - piCur[3];
//                      APCVal[k+3] = TComRdCost::HadAPC((int)piOrg[3], (int)piCur[7], dist4);

//                      HadDiff[k+4] = iTemp = piOrg[4] - piCur[4];
//                      APCVal[k+4] = TComRdCost::HadAPC((int)piOrg[4], (int)piCur[6], dist2) + TComRdCost::HadAPC((int)piOrg[4], (int)piCur[5], dist1);

//                      HadDiff[k+5] = iTemp = piOrg[5] - piCur[5];
//                      APCVal[k+5] = TComRdCost::HadAPC((int)piOrg[5], (int)piCur[7], dist2);

//                      HadDiff[k+6] = iTemp = piOrg[6] - piCur[6];
//                      APCVal[k+6] = TComRdCost::HadAPC((int)piOrg[6], (int)piCur[7], dist1);
//                      // No Seven
//                  }

//                  // Bottom Corners
//                  piCur += iStrideCur;
//                  piOrg += iStrideOrg;

//                  HadDiff[56] = iTemp = piOrg[0] - piCur[0];
//                  APCVal[56] = TComRdCost::HadAPC((int)piOrg[0], (int)piCur[4], dist4) + TComRdCost::HadAPC((int)piOrg[0], (int)piCur[2], dist2) + TComRdCost ::HadAPC((int)piOrg[0], (int)piCur[1], dist1);
				  
//                  HadDiff[63] = iTemp = piOrg[7] - piCur[7];
//                  APCVal[63] = 0; //TComRdCost ::HadAPC((int)piOrg[7], (int)piCur[7], 0);

//                // Rotate 90 degrees to perform vertical stage

//                for( k = 1; k < 7; k ++ ) // Just the remaining inner square, between the edge rows and columns
//                {
//                    // Remember start from the second row, since the first row  has already been done

//                    //The inner square
//                    // No Zero

//                    // Ignore Corner, this leaves 8, 16, 24, 32, 40, 48

//                    APCVal[k+ 8] +=   TComRdCost::HadAPC((int)piOrg[k + 8], (int)piCur[k + 40], dist4) + TComRdCost::HadAPC((int)piOrg[k + 8], (int)piCur[k + 24], dist2);
//                    APCVal[k+ 16] +=  TComRdCost::HadAPC((int)piOrg[k + 16], (int)piCur[k + 48], dist4) + TComRdCost::HadAPC((int)piOrg[k + 16], (int)piCur[k + 24], dist1);
//                    APCVal[k+ 24] +=  TComRdCost::HadAPC((int)piOrg[k + 3], (int)piCur[k + 7], dist4);
//                    APCVal[k+ 32] +=  TComRdCost::HadAPC((int)piOrg[k + 4], (int)piCur[k + 6], dist2) + TComRdCost::HadAPC((int)piOrg[k + 4], (int)piCur[k + 5], dist1);
//                    APCVal[k+ 40] +=  TComRdCost::HadAPC((int)piOrg[k + 5], (int)piCur[k + 7], dist2);
//                    APCVal[k+ 48] +=  TComRdCost::HadAPC((int)piOrg[k + 6], (int)piCur[k + 7], dist1);
//                }
//                  ptrDiff = APCVal;
//              }
//              break;
//          }

//        ////----------------------------



//            //int i, j, jj;//, k;


//            // End of Multi-Scale APC
//            //=============================
//            // Beginning of Hadamard with APC

//            //Now to add/subtract to the Hadamard Diff.
//            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
//            //int APCscale = 0;

//            //iSumHad =0;

//            //horizontal
//            for (j=0; j < 8; j++)
//            {
//              jj = j << 3;
//              //---------------------
//              // Changed to support Had with Integrated APC subject to meeting threshold.

//              // Additional Pixel Cost (APC) - Add APC to the difference
////			  m2[j][0] = (HadDiff[jj  ] + ptrDiff[jj  ]) + (HadDiff[jj+4] + ptrDiff[jj+4]);
////			  m2[j][1] = (HadDiff[jj+1] + ptrDiff[jj+1]) + (HadDiff[jj+5] + ptrDiff[jj+5]);
////			  m2[j][2] = (HadDiff[jj+2] + ptrDiff[jj+2]) + (HadDiff[jj+6] + ptrDiff[jj+6]);
////			  m2[j][3] = (HadDiff[jj+3] + ptrDiff[jj+3]) + (HadDiff[jj+7] + ptrDiff[jj+7]);
////			  m2[j][4] = (HadDiff[jj  ] + ptrDiff[jj  ]) - (HadDiff[jj+4] + ptrDiff[jj+4]);
////			  m2[j][5] = (HadDiff[jj+1] + ptrDiff[jj+1]) - (HadDiff[jj+5] + ptrDiff[jj+5]);
////			  m2[j][6] = (HadDiff[jj+2] + ptrDiff[jj+2]) - (HadDiff[jj+6] + ptrDiff[jj+6]);
////			  m2[j][7] = (HadDiff[jj+3] + ptrDiff[jj+3]) - (HadDiff[jj+7] + ptrDiff[jj+7]);

//              m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
//              m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
//              m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
//              m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
//              m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
//              m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
//              m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
//              m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];

//              m1[j][0] = m2[j][0] + m2[j][2];
//              m1[j][1] = m2[j][1] + m2[j][3];
//              m1[j][2] = m2[j][0] - m2[j][2];
//              m1[j][3] = m2[j][1] - m2[j][3];
//              m1[j][4] = m2[j][4] + m2[j][6];
//              m1[j][5] = m2[j][5] + m2[j][7];
//              m1[j][6] = m2[j][4] - m2[j][6];
//              m1[j][7] = m2[j][5] - m2[j][7];

//              m2[j][0] = m1[j][0] + m1[j][1];
//              m2[j][1] = m1[j][0] - m1[j][1];
//              m2[j][2] = m1[j][2] + m1[j][3];
//              m2[j][3] = m1[j][2] - m1[j][3];
//              m2[j][4] = m1[j][4] + m1[j][5];
//              m2[j][5] = m1[j][4] - m1[j][5];
//              m2[j][6] = m1[j][6] + m1[j][7];
//              m2[j][7] = m1[j][6] - m1[j][7];

//              //---------------------
//              // Now for Had on APC
//              switch(ProceedwAPC)
//              {
//              case true:
//                      {
//                          // Changed to support Had with Integrated APC subject to meeting threshold.
//                          m2APC[j][0] = (ptrDiff[jj  ] ) + (ptrDiff[jj+4] );
//                          m2APC[j][1] = (ptrDiff[jj+1] ) + (ptrDiff[jj+5] );
//                          m2APC[j][2] = (ptrDiff[jj+2] ) + (ptrDiff[jj+6] );
//                          m2APC[j][3] = (ptrDiff[jj+3] ) + (ptrDiff[jj+7] );
//                          m2APC[j][4] = (ptrDiff[jj  ] ) - (ptrDiff[jj+4] );
//                          m2APC[j][5] = (ptrDiff[jj+1] ) - (ptrDiff[jj+5] );
//                          m2APC[j][6] = (ptrDiff[jj+2] ) - (ptrDiff[jj+6] );
//                          m2APC[j][7] = (ptrDiff[jj+3] ) - (ptrDiff[jj+7] );

//                          m1APC[j][0] = m2APC[j][0] + m2APC[j][2];
//                          m1APC[j][1] = m2APC[j][1] + m2APC[j][3];
//                          m1APC[j][2] = m2APC[j][0] - m2APC[j][2];
//                          m1APC[j][3] = m2APC[j][1] - m2APC[j][3];
//                          m1APC[j][4] = m2APC[j][4] + m2APC[j][6];
//                          m1APC[j][5] = m2APC[j][5] + m2APC[j][7];
//                          m1APC[j][6] = m2APC[j][4] - m2APC[j][6];
//                          m1APC[j][7] = m2APC[j][5] - m2APC[j][7];

//                          m2APC[j][0] = m1APC[j][0] + m1APC[j][1];
//                          m2APC[j][1] = m1APC[j][0] - m1APC[j][1];
//                          m2APC[j][2] = m1APC[j][2] + m1APC[j][3];
//                          m2APC[j][3] = m1APC[j][2] - m1APC[j][3];
//                          m2APC[j][4] = m1APC[j][4] + m1APC[j][5];
//                          m2APC[j][5] = m1APC[j][4] - m1APC[j][5];
//                          m2APC[j][6] = m1APC[j][6] + m1APC[j][7];
//                          m2APC[j][7] = m1APC[j][6] - m1APC[j][7];
//                      }
//              }

//            }

//            //vertical
//            for (i=0; i < 8; i++)
//            {
//              m3[0][i] = m2[0][i] + m2[4][i];
//              m3[1][i] = m2[1][i] + m2[5][i];
//              m3[2][i] = m2[2][i] + m2[6][i];
//              m3[3][i] = m2[3][i] + m2[7][i];
//              m3[4][i] = m2[0][i] - m2[4][i];
//              m3[5][i] = m2[1][i] - m2[5][i];
//              m3[6][i] = m2[2][i] - m2[6][i];
//              m3[7][i] = m2[3][i] - m2[7][i];

//              m1[0][i] = m3[0][i] + m3[2][i];
//              m1[1][i] = m3[1][i] + m3[3][i];
//              m1[2][i] = m3[0][i] - m3[2][i];
//              m1[3][i] = m3[1][i] - m3[3][i];
//              m1[4][i] = m3[4][i] + m3[6][i];
//              m1[5][i] = m3[5][i] + m3[7][i];
//              m1[6][i] = m3[4][i] - m3[6][i];
//              m1[7][i] = m3[5][i] - m3[7][i];

//              m2[0][i] = m1[0][i] + m1[1][i];
//              m2[1][i] = m1[0][i] - m1[1][i];
//              m2[2][i] = m1[2][i] + m1[3][i];
//              m2[3][i] = m1[2][i] - m1[3][i];
//              m2[4][i] = m1[4][i] + m1[5][i];
//              m2[5][i] = m1[4][i] - m1[5][i];
//              m2[6][i] = m1[6][i] + m1[7][i];
//              m2[7][i] = m1[6][i] - m1[7][i];

//              //---------------------
//              // Now for Had on APC
//              switch(ProceedwAPC)
//              {
//              case true:
//                      {
//                          m3APC[0][i] = m2APC[0][i] + m2APC[4][i];
//                          m3APC[1][i] = m2APC[1][i] + m2APC[5][i];
//                          m3APC[2][i] = m2APC[2][i] + m2APC[6][i];
//                          m3APC[3][i] = m2APC[3][i] + m2APC[7][i];
//                          m3APC[4][i] = m2APC[0][i] - m2APC[4][i];
//                          m3APC[5][i] = m2APC[1][i] - m2APC[5][i];
//                          m3APC[6][i] = m2APC[2][i] - m2APC[6][i];
//                          m3APC[7][i] = m2APC[3][i] - m2APC[7][i];

//                          m1APC[0][i] = m3APC[0][i] + m3APC[2][i];
//                          m1APC[1][i] = m3APC[1][i] + m3APC[3][i];
//                          m1APC[2][i] = m3APC[0][i] - m3APC[2][i];
//                          m1APC[3][i] = m3APC[1][i] - m3APC[3][i];
//                          m1APC[4][i] = m3APC[4][i] + m3APC[6][i];
//                          m1APC[5][i] = m3APC[5][i] + m3APC[7][i];
//                          m1APC[6][i] = m3APC[4][i] - m3APC[6][i];
//                          m1APC[7][i] = m3APC[5][i] - m3APC[7][i];

//                          m2APC[0][i] = m1APC[0][i] + m1APC[1][i];
//                          m2APC[1][i] = m1APC[0][i] - m1APC[1][i];
//                          m2APC[2][i] = m1APC[2][i] + m1APC[3][i];
//                          m2APC[3][i] = m1APC[2][i] - m1APC[3][i];
//                          m2APC[4][i] = m1APC[4][i] + m1APC[5][i];
//                          m2APC[5][i] = m1APC[4][i] - m1APC[5][i];
//                          m2APC[6][i] = m1APC[6][i] + m1APC[7][i];
//                          m2APC[7][i] = m1APC[6][i] - m1APC[7][i];
//                      }
//              }

//            }

//            for (i = 0; i < 8; i++)
//            {
//              for (j = 0; j < 8; j++)
//              {
//                iSumHad += abs(m2[i][j]);
//                sadAPC += ProceedwAPC == true? abs(m2APC[i][j]) : 0;
//              }
//            }

//            iSumHad=((iSumHad+2)>>2);
//            sadAPC=((sadAPC+2)>>2);

//        }

//        yInt = yInt_Rec;

////        // Convert YUV to RGB

//        int r=0, g=0, b=0;


//        //if (HadRegion == true)
//        if (ProceedwAPC == true)
//        {

////			int blkwidth = 8;

//            //------------------

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = 0; //(int)log2((double)blkwidth) - 3;
            
//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//            iSumHad += ProceedwAPC == true? (sadAPC >> 5) : 0;

//            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

////            int val = dist < (halfMaxThreshold >> 2) ? 0
////                : dist < (halfMaxThreshold >> 1) ? 1
////                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;
									
//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("Pre Assess Had8x8w-APC is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);
						
//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            // YGJ 15th March 2015
//            // Use 1/2 max based normalised value
//            // Based on normJND

//            normHad = normHad > 1.0? 1.0 : normHad;

//            int val =  normHad < 0.25? 0 :
//                       normHad < 0.5? 1 :
//                       normHad < 0.75? 2 : 3;
			
//            //------------------

//            //switch (val)
//            //{
//            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//            //		break;
//            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//            //		break;
//            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //}

//            //------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//            switch (val)
//            {
//                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//                    break;
//                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//                    break;
//                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//                    break;
//                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//                    break;
//            }
//            //------------------

//        }
//        else
//        {
//            r = g = b = yInt;
//        }

//        // Rec - Org
//        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//        // Partitioning -- Not Working?
//        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//        {
//          r = 0; //yInt_RmO;
//          g = 0; //yInt_RmO;
//          b = 0; //yInt_RmO;
//        }



//        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//      }
//      //piY += YStride;
//      piY_Org += YStride;
//      piY_Rec += YStrideRec;
//      piY_Part += YStrideRec;


//    }


//    free(ptrY_Org8x8);
//    free(ptrY_Rec8x8);

//    free(ptrY_Org);

//    free(ptrY_Rec);

//    free(ptrY_Part);


//    //-----------------------

//    if(m_outputSSIMHeatmaps)
//    {
//      std::vector<unsigned char> png;

//      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//      //if there's an error, display it
//      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//    }

//   //-----------------------

//}

////// Needs to convert from YUV 420/422/444 to RGB 444 before saving a 24bit PNG (8 bits per channel)
////// YGJ 15th Sept 2014

////// Like saveFrameAsPNG_RCHadw_MS_APC, but here the reconstructed video is used.
////// Note that since the Had technique is slightly different therefore so is the range of scores and so the scaling must be adjusted.

//////=========================================
//////=========================================
////// Existing Methods shown as Heatmaps
//////=========================================
//////=========================================

Void TAppDecTop::saveFrameAsPNG_Hadamard(TComPic* pcPic)
{


  unsigned height = m_iSourceHeight;
  unsigned width = m_iSourceWidth;
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Recon Minus Orig
  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    // YGJ 16th March 2015 - Block size can vary in SSE version.

    Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");


   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  char strFactor[8];


  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  strcat(SSIMHeatmap, "DecFrm_HadamardDistortionHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;  // unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
    //Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

//int prevCloc = 0; // Previous cloc

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;

        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
        int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


        bool HadRegion = false;
        Distortion iSumHad =0;

        //if ((y < (height-8)) && (x < (width-8)))

        // YGJ 16th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          HadRegion = true;

          int HadDiff[64];
          //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
          //Int OrgPx[64], RecPx[64];


            for ( unsigned n = 0; n < 8; n++ )
            {
                for ( unsigned m = 0; m < 8; m++ )
                {
                    // y*width + x
                    unsigned yloc8x8 = n*8+m;

                    Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
                    Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);


                    ////------------------
                    //// YGJ 12th July 2014
                    //// Please note here the encoder assumes current/reconstructed block is `all zero block'
                    //// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
                    //// a -- set up and initialise variables

                    ////------------------
                    HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
                    ////-------------------

                }
            }

            int j, jj, i;

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;

              m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
              m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
              m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
              m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
              m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
              m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
              m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
              m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];

              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];
            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];
            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
              }
            }

            iSumHad=((iSumHad+2)>>2);

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;

        }
        else if ((y%8 != 0) || (x%8 != 0))
        {
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Use previous values

//            iSumHad = PrevHad;
//            iSumHadAPC = PrevAPCms;
//            PerformMsAPC = PrevBoolPerformAPCms;

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            HadRegion = true;
        }

        yInt = yInt_Rec;


        int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
        int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
        int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

        if (HadRegion == true)
        {
            int blkwidth = 8;

            //------------------

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

            Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

            //int val = dist < (halfMaxThreshold >> 2) ? 0 : dist < (halfMaxThreshold >> 1) ? 1 : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

            //------------------

            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("Had is greater than halfMaxThreshold (%d), iSumHad is %d, will be set to %d \n",
                halfMaxThreshold, iSumHad, halfMaxThreshold);


            // Normalise Had against assumed max.
            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

            //switch (val)
            //{
            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
            //		break;
            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
            //		break;
            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //}

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }

        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }

        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;


    }

    free(ptrY_Org8x8);
    free(ptrY_Rec8x8);

    free(ptrY_Org);

    free(ptrY_Rec);

    free(ptrY_Part);


    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}

//Void TAppDecTop::saveFrameAsPNG_Hadamard4x4(TComPic* pcPic)
//{


//  unsigned height = m_iSourceHeight;
//  unsigned width = m_iSourceWidth;
//  unsigned FrameRes = (height*width);

//  // Used to produce SSIM Heatmaps
//  TComPicYuv* imageOrg = m_pcPicYuvOrg;
//  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
//  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

//  int poc = pcPic->getPOC();

//  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

//  Pel*  piY_Rec   = imageRec->getAddr(COMPONENT_Y);

//  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

//  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

//  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

//  // Allocate memory for output frame

//  // Orig
//  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

//  // Recon Minus Orig
//  Pel *ptrY_Rec;   ptrY_Rec = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Rec == NULL)   printf("calloc failed\n");

//  // Partitioning
//  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

//	Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//	Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

//   // To Do:

//  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

//  //unsigned poc = ;
//  char strpoc[6];
//  char strRange[8];
//  char strFactor[8];


//  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
//  #if _MSC_VER
//  #define snprintf _snprintf
//  #endif

//  // Set up file names

//  if (poc < 10)
//	  snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
//  else if (poc < 100)
//	  snprintf(strpoc, sizeof(strpoc), "0%d", poc);

//  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
//  snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

//  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
//  strcat(SSIMHeatmap, "DecFrm_Hadamard4x4_DistortionHeatMap_");
//  strcat(SSIMHeatmap, strpoc);
//  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
//  strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
//  strcat(SSIMHeatmap, ".png");

//  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

//  unsigned MaxValue = (1<<g_bitDepth[0])-1;  // unsigned HalfMaxValue = (MaxValue-1) >> 1;
//	Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;
//	//Int   shiftc = g_bitDepth[1]-8;    Int   offsetc = (shiftc>0)?(1<<(shiftc-1)):0;

////int prevCloc = 0; // Previous cloc

//	for ( unsigned y = 0; y < height; y++ )
//	{
//	  for ( unsigned x = 0; x < width; x++ )
//	  {
//		unsigned yloc = y*width+x;

//		// allocate YUV value
//		int yInt = 0; //, uInt = 0, vInt = 0;

//		ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//		ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
//		ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

//		int yInt_Org = (int)ptrY_Org[yloc];// int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//		int yInt_Rec = (int)ptrY_Rec[yloc];  //int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
//		int yInt_Part = (int)ptrY_Part[yloc]; // int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

//		// seems fine here
//		if (yInt_Org > 255 || yInt_Org < 0  || yInt_Rec > 255 || yInt_Rec < 0)
//			printf("Out of range pixel value, yInt_Org, %d, yInt_Rec, %d \n", yInt_Org, yInt_Rec);


//		bool HadRegion = false;
//		Distortion iSumHad =0;

//		if ((y < (height-4)) && (x < (width-4)))
//		{
//		  HadRegion = true;
                              
//          Int k;
//          Distortion satd = 0;
//          TCoeff diff[16], m[16], d[16];

//			for ( unsigned n = 0; n < 4; n++ )
//			{
//                for ( unsigned q = 0; q < 4; q++ )
//				{
//					// y*width + x
//                    unsigned yloc4x4 = n*4+q;

//                    Distortion y_Org = ptrY_Org8x8[yloc4x4] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + q + (YStride*n)] +offset))>>shift);
//                    Distortion y_Rec = ptrY_Rec8x8[yloc4x4] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + q + (YStrideRec*n)] +offset))>>shift);


//					////------------------
//					//// YGJ 12th July 2014
//					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
//					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
//					//// a -- set up and initialise variables

//					////------------------
//					diff[yloc4x4] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
//					////-------------------

//				}
//			}



//          //assert( iStep == 1 );
//          //for( k = 0; k < 16; k+=4 )
//          //{
//          //  diff[k+0] = piOrg[0] - piCur[0];
//          //  diff[k+1] = piOrg[1] - piCur[1];
//          //  diff[k+2] = piOrg[2] - piCur[2];
//          //  diff[k+3] = piOrg[3] - piCur[3];

//          //  piCur += iStrideCur;
//          //  piOrg += iStrideOrg;
//          //}

//          /*===== hadamard transform =====*/
//          m[ 0] = diff[ 0] + diff[12];
//          m[ 1] = diff[ 1] + diff[13];
//          m[ 2] = diff[ 2] + diff[14];
//          m[ 3] = diff[ 3] + diff[15];
//          m[ 4] = diff[ 4] + diff[ 8];
//          m[ 5] = diff[ 5] + diff[ 9];
//          m[ 6] = diff[ 6] + diff[10];
//          m[ 7] = diff[ 7] + diff[11];
//          m[ 8] = diff[ 4] - diff[ 8];
//          m[ 9] = diff[ 5] - diff[ 9];
//          m[10] = diff[ 6] - diff[10];
//          m[11] = diff[ 7] - diff[11];
//          m[12] = diff[ 0] - diff[12];
//          m[13] = diff[ 1] - diff[13];
//          m[14] = diff[ 2] - diff[14];
//          m[15] = diff[ 3] - diff[15];

//          d[ 0] = m[ 0] + m[ 4];
//          d[ 1] = m[ 1] + m[ 5];
//          d[ 2] = m[ 2] + m[ 6];
//          d[ 3] = m[ 3] + m[ 7];
//          d[ 4] = m[ 8] + m[12];
//          d[ 5] = m[ 9] + m[13];
//          d[ 6] = m[10] + m[14];
//          d[ 7] = m[11] + m[15];
//          d[ 8] = m[ 0] - m[ 4];
//          d[ 9] = m[ 1] - m[ 5];
//          d[10] = m[ 2] - m[ 6];
//          d[11] = m[ 3] - m[ 7];
//          d[12] = m[12] - m[ 8];
//          d[13] = m[13] - m[ 9];
//          d[14] = m[14] - m[10];
//          d[15] = m[15] - m[11];

//          m[ 0] = d[ 0] + d[ 3];
//          m[ 1] = d[ 1] + d[ 2];
//          m[ 2] = d[ 1] - d[ 2];
//          m[ 3] = d[ 0] - d[ 3];
//          m[ 4] = d[ 4] + d[ 7];
//          m[ 5] = d[ 5] + d[ 6];
//          m[ 6] = d[ 5] - d[ 6];
//          m[ 7] = d[ 4] - d[ 7];
//          m[ 8] = d[ 8] + d[11];
//          m[ 9] = d[ 9] + d[10];
//          m[10] = d[ 9] - d[10];
//          m[11] = d[ 8] - d[11];
//          m[12] = d[12] + d[15];
//          m[13] = d[13] + d[14];
//          m[14] = d[13] - d[14];
//          m[15] = d[12] - d[15];

//          d[ 0] = m[ 0] + m[ 1];
//          d[ 1] = m[ 0] - m[ 1];
//          d[ 2] = m[ 2] + m[ 3];
//          d[ 3] = m[ 3] - m[ 2];
//          d[ 4] = m[ 4] + m[ 5];
//          d[ 5] = m[ 4] - m[ 5];
//          d[ 6] = m[ 6] + m[ 7];
//          d[ 7] = m[ 7] - m[ 6];
//          d[ 8] = m[ 8] + m[ 9];
//          d[ 9] = m[ 8] - m[ 9];
//          d[10] = m[10] + m[11];
//          d[11] = m[11] - m[10];
//          d[12] = m[12] + m[13];
//          d[13] = m[12] - m[13];
//          d[14] = m[14] + m[15];
//          d[15] = m[15] - m[14];

//          for (k=0; k<16; ++k)
//          {
//            satd += abs(d[k]);
//          }
//          iSumHad = satd = ((satd+1)>>1);


////		  int HadDiff[16];
////		  //TCoeff m2[8][8]; //, m3[8][8]; //, iSumHad = 0;
////		  //TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;
//////          Int multiscaleAPC[64]; // Multi-scale APC - Like Hadamard Horizontal and Vertical process with pixels of 4, 2 and 1 spacing.
////		  //Int OrgPx[64], RecPx[64];
////
////
////			for ( unsigned n = 0; n < 8; n++ )
////			{
////				for ( unsigned m = 0; m < 8; m++ )
////				{
////					// y*width + x
////					unsigned yloc8x8 = n*8+m;
////
////					Distortion y_Org = ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);
////					Distortion y_Rec = ptrY_Rec8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Rec[x + m + (YStrideRec*n)] +offset))>>shift);
////
////
////					////------------------
////					//// YGJ 12th July 2014
////					//// Please note here the encoder assumes current/reconstructed block is `all zero block'
////					//// Since this is a relative pixel solution , then instead of using the differences of difference, use original and the adjacent pixel
////					//// a -- set up and initialise variables
////
////					////------------------
////					HadDiff[yloc8x8] = y_Org - y_Rec; //difference; // Setting Diff to Zero, SATD is still reporting extremely high values(?)
////					////-------------------
////
////				}
////			}
////
////			int j, jj, i;
////
////			//horizontal
////			for (j=0; j < 8; j++)
////			{
////			  jj = j << 3;
////
////			  m2[j][0] = HadDiff[jj  ] + HadDiff[jj+4];
////			  m2[j][1] = HadDiff[jj+1] + HadDiff[jj+5];
////			  m2[j][2] = HadDiff[jj+2] + HadDiff[jj+6];
////			  m2[j][3] = HadDiff[jj+3] + HadDiff[jj+7];
////			  m2[j][4] = HadDiff[jj  ] - HadDiff[jj+4];
////			  m2[j][5] = HadDiff[jj+1] - HadDiff[jj+5];
////			  m2[j][6] = HadDiff[jj+2] - HadDiff[jj+6];
////			  m2[j][7] = HadDiff[jj+3] - HadDiff[jj+7];
////
////			  m1[j][0] = m2[j][0] + m2[j][2];
////			  m1[j][1] = m2[j][1] + m2[j][3];
////			  m1[j][2] = m2[j][0] - m2[j][2];
////			  m1[j][3] = m2[j][1] - m2[j][3];
////			  m1[j][4] = m2[j][4] + m2[j][6];
////			  m1[j][5] = m2[j][5] + m2[j][7];
////			  m1[j][6] = m2[j][4] - m2[j][6];
////			  m1[j][7] = m2[j][5] - m2[j][7];
////
////			  m2[j][0] = m1[j][0] + m1[j][1];
////			  m2[j][1] = m1[j][0] - m1[j][1];
////			  m2[j][2] = m1[j][2] + m1[j][3];
////			  m2[j][3] = m1[j][2] - m1[j][3];
////			  m2[j][4] = m1[j][4] + m1[j][5];
////			  m2[j][5] = m1[j][4] - m1[j][5];
////			  m2[j][6] = m1[j][6] + m1[j][7];
////			  m2[j][7] = m1[j][6] - m1[j][7];
////			}
////
////			//vertical
////			for (i=0; i < 8; i++)
////			{
////			  m3[0][i] = m2[0][i] + m2[4][i];
////			  m3[1][i] = m2[1][i] + m2[5][i];
////			  m3[2][i] = m2[2][i] + m2[6][i];
////			  m3[3][i] = m2[3][i] + m2[7][i];
////			  m3[4][i] = m2[0][i] - m2[4][i];
////			  m3[5][i] = m2[1][i] - m2[5][i];
////			  m3[6][i] = m2[2][i] - m2[6][i];
////			  m3[7][i] = m2[3][i] - m2[7][i];
////
////			  m1[0][i] = m3[0][i] + m3[2][i];
////			  m1[1][i] = m3[1][i] + m3[3][i];
////			  m1[2][i] = m3[0][i] - m3[2][i];
////			  m1[3][i] = m3[1][i] - m3[3][i];
////			  m1[4][i] = m3[4][i] + m3[6][i];
////			  m1[5][i] = m3[5][i] + m3[7][i];
////			  m1[6][i] = m3[4][i] - m3[6][i];
////			  m1[7][i] = m3[5][i] - m3[7][i];
////
////			  m2[0][i] = m1[0][i] + m1[1][i];
////			  m2[1][i] = m1[0][i] - m1[1][i];
////			  m2[2][i] = m1[2][i] + m1[3][i];
////			  m2[3][i] = m1[2][i] - m1[3][i];
////			  m2[4][i] = m1[4][i] + m1[5][i];
////			  m2[5][i] = m1[4][i] - m1[5][i];
////			  m2[6][i] = m1[6][i] + m1[7][i];
////			  m2[7][i] = m1[6][i] - m1[7][i];
////			}
////
////			for (i = 0; i < 8; i++)
////			{
////			  for (j = 0; j < 8; j++)
////			  {
////				iSumHad += abs(m2[i][j]);
////			  }
////			}
////
////			iSumHad=((iSumHad+2)>>2);

//		}

//		yInt = yInt_Rec;


//		int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
//		int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
//		int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

//		if (HadRegion == true)
//		{
//			int blkwidth = 8; // Leave for now, will just divide score by 1/4.

//			//------------------

//			// Using arrays as look up tables to ensure values set are consistent
//			int loc = (int)log2((double)blkwidth) - 3;
//            // 1/4 of 8x8 => 1/4 of 16 = 4k;
//			int maxUnscaled = ((maxLimitSAD_k[loc] >> 2) * NormDist_OneMin10k[m_distRange]);
//			float maxScaled = (float)((float)maxUnscaled * (0.1024));
//			float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor));

//			Distortion halfMaxThreshold = (Distortion)maxCommonFactor;

//			Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//			int val = dist < (halfMaxThreshold >> 2) ? 0 : dist < (halfMaxThreshold >> 1) ? 1 : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

//			//------------------

//			if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//				printf("Had4x4 is greater than halfMaxThreshold (%d), iSumHad is %d, will be set to %d \n",
//				halfMaxThreshold, iSumHad, halfMaxThreshold);


//			// Normalise Had against assumed max.
//			float normHad = ((float)dist)/((float)halfMaxThreshold);

//			//switch (val)
//			//{
//			//	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//			//		break;
//			//	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//			//		break;
//			//	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//			//		break;
//			//}

//			//------------------
//            // YGJ 27th Oct 2014
//            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
//            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
//			switch (val)
//			{
//				case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt_Rec); b = min(yInt_Rec << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
//					break;
//				case 1 :  r = 0; g= yInt_Rec; b = (int)(yInt_Rec-((normHad-0.25)/(float)0.25)*yInt_Rec); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
//					break;
//				case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt_Rec); g= yInt_Rec; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
//					break;
//				default : r = min(yInt_Rec << 1, 255) ;g= (int)(yInt_Rec-((normHad-0.75)/(float)0.25)*yInt_Rec); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
//					break;
//			}
//            //------------------

//		}
//        else
//        {
//            r = g = b = yInt;
//        }

//		// Rec - Org
//		r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
//		g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
//		b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


//		// Partitioning -- Not Working?
//		if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
//		{
//		  r = 0; //yInt_RmO;
//		  g = 0; //yInt_RmO;
//		  b = 0; //yInt_RmO;
//		}

//		imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
//		imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
//		imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
//		imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

//	  }
//	  //piY += YStride;
//	  piY_Org += YStride;
//	  piY_Rec += YStrideRec;
//	  piY_Part += YStrideRec;


//	}

//	free(ptrY_Org8x8);
//	free(ptrY_Rec8x8);

//	free(ptrY_Org);

//	free(ptrY_Rec);

//	free(ptrY_Part);


//	//-----------------------

//	if(m_outputSSIMHeatmaps)
//	{
//	  std::vector<unsigned char> png;

//	  unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

//	  if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

//	  //if there's an error, display it
//	  if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
//	}

//   //-----------------------

//}


Void TAppDecTop::saveFrameAsPNG_RateControlHad(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight;
  unsigned width = m_iSourceWidth;
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");


    // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
    // YGJ 5th Jan 2014 - Save Had Distortion, Frame size / 8x8
    // Store values for when at the start of 8x8 and recalled for when within 8x8 block
    Distortion *ptrDist_Had;   ptrDist_Had = (Distortion *)calloc((FrameRes >> 6), sizeof(Distortion));    if (ptrDist_Had == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  //char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);
  
  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  strcat(SSIMHeatmap, "DecFrm_RateCtrlHadActivityHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


 //double frmAverageSSIM = 0.0;
 //int OverlappingSSIMcount =0;

 //float PxAve_SSIM_distortion = 0.0;
// unsigned long long FrmTotal_SSE_distortion = 0;

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;


        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);



        bool HadRegion = false;
        Distortion iSumHad =0;

        //if ((y < (height-8)) && (x < (width-8)))

        // YGJ 15th March 2015 - Taken from saveFrameAsPNG_RCHadPreAssess_wEdgeScaledMS_APC
        // YGJ 5th Jan 2014 - Every 8x8 block
        if ((y < (height-8)) && (x < (width-8)) && ((y % 8 == 0) && (x % 8 == 0)))
        {
          HadRegion = true;
          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;

            for ( unsigned n = 0; n < 8; n++ )
            {
                for ( unsigned m = 0; m < 8; m++ )
                {
                    unsigned yloc8x8 = n*m+m;

                    ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

                }
            }

            //-------------------------
            //-----

            int i, j, jj; //, k;


            // End of Multi-Scale APC
            //=============================
            // Beginning of Hadamard with APC

            //Now to add/subtract to the Hadamard Diff.
            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
            //int APCscale = 0;

            //horizontal
            for (j=0; j < 8; j++)
            {
              jj = j << 3;

              m2[j][0] = ptrY_Org8x8[jj  ] + ptrY_Org8x8[jj+4];// + multiscaleAPC[jj  ];
              m2[j][1] = ptrY_Org8x8[jj+1] + ptrY_Org8x8[jj+5];// + multiscaleAPC[jj+1];
              m2[j][2] = ptrY_Org8x8[jj+2] + ptrY_Org8x8[jj+6];// + multiscaleAPC[jj+2];
              m2[j][3] = ptrY_Org8x8[jj+3] + ptrY_Org8x8[jj+7];// + multiscaleAPC[jj+3];
              m2[j][4] = ptrY_Org8x8[jj  ] - ptrY_Org8x8[jj+4];// - multiscaleAPC[jj+4];
              m2[j][5] = ptrY_Org8x8[jj+1] - ptrY_Org8x8[jj+5];// - multiscaleAPC[jj+5];
              m2[j][6] = ptrY_Org8x8[jj+2] - ptrY_Org8x8[jj+6];// - multiscaleAPC[jj+6];
              m2[j][7] = ptrY_Org8x8[jj+3] - ptrY_Org8x8[jj+7];// - multiscaleAPC[jj+7];

              m1[j][0] = m2[j][0] + m2[j][2];
              m1[j][1] = m2[j][1] + m2[j][3];
              m1[j][2] = m2[j][0] - m2[j][2];
              m1[j][3] = m2[j][1] - m2[j][3];
              m1[j][4] = m2[j][4] + m2[j][6];
              m1[j][5] = m2[j][5] + m2[j][7];
              m1[j][6] = m2[j][4] - m2[j][6];
              m1[j][7] = m2[j][5] - m2[j][7];

              m2[j][0] = m1[j][0] + m1[j][1];
              m2[j][1] = m1[j][0] - m1[j][1];
              m2[j][2] = m1[j][2] + m1[j][3];
              m2[j][3] = m1[j][2] - m1[j][3];
              m2[j][4] = m1[j][4] + m1[j][5];
              m2[j][5] = m1[j][4] - m1[j][5];
              m2[j][6] = m1[j][6] + m1[j][7];
              m2[j][7] = m1[j][6] - m1[j][7];
            }

            //vertical
            for (i=0; i < 8; i++)
            {
              m3[0][i] = m2[0][i] + m2[4][i];
              m3[1][i] = m2[1][i] + m2[5][i];
              m3[2][i] = m2[2][i] + m2[6][i];
              m3[3][i] = m2[3][i] + m2[7][i];
              m3[4][i] = m2[0][i] - m2[4][i];
              m3[5][i] = m2[1][i] - m2[5][i];
              m3[6][i] = m2[2][i] - m2[6][i];
              m3[7][i] = m2[3][i] - m2[7][i];

              m1[0][i] = m3[0][i] + m3[2][i];
              m1[1][i] = m3[1][i] + m3[3][i];
              m1[2][i] = m3[0][i] - m3[2][i];
              m1[3][i] = m3[1][i] - m3[3][i];
              m1[4][i] = m3[4][i] + m3[6][i];
              m1[5][i] = m3[5][i] + m3[7][i];
              m1[6][i] = m3[4][i] - m3[6][i];
              m1[7][i] = m3[5][i] - m3[7][i];

              m2[0][i] = m1[0][i] + m1[1][i];
              m2[1][i] = m1[0][i] - m1[1][i];
              m2[2][i] = m1[2][i] + m1[3][i];
              m2[3][i] = m1[2][i] - m1[3][i];
              m2[4][i] = m1[4][i] + m1[5][i];
              m2[5][i] = m1[4][i] - m1[5][i];
              m2[6][i] = m1[6][i] + m1[7][i];
              m2[7][i] = m1[6][i] - m1[7][i];
            }

            for (i = 0; i < 8; i++)
            {
              for (j = 0; j < 8; j++)
              {
                iSumHad += abs(m2[i][j]);
              }
            }
            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
            iSumHad =(iSumHad+2)>>2;

            ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)] = iSumHad;


        }
        else if ((y < (height-8)) && (x < (width-8)))  //if ((y%8 != 0) || (x%8 != 0))
        {
            HadRegion = true;
            //////////////////////////
            // YGJ 5th Jan 2015
            // Non-Overlapping 8x8, to be more like Rate Control
            // Use previous values

//            iSumHad = PrevHad;
//            iSumHadAPC = PrevAPCms;
//            PerformMsAPC = PrevBoolPerformAPCms;

            iSumHad = ptrDist_Had[(x >> 3) + (y >> 3)*(width>>3)];
            //iSumHadAPC = ptrDist_APCms[(x >> 3) + (y >> 3)*(width>>3)];
            //PerformMsAPC = ptrbool_perfAPCms[(x >> 3) + (y >> 3)*(width>>3)];
        }

        yInt = yInt_Org;


        int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
        int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
        int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

        if (HadRegion == true)
        {

            //------------------

            int blkwidth = 8;

            // Using arrays as look up tables to ensure values set are consistent
            int loc = (int)log2((double)blkwidth) - 3;

            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
            float maxScaled = (float)((float)maxUnscaled * (0.1024));
            //float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); // Not applicable

            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

            // For Rate-Control
            halfMaxThreshold <<= 1; // Double

            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;
								   
            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
                printf("RateControl Had is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
                halfMaxThreshold, iSumHad, halfMaxThreshold);

//            int val = dist < (halfMaxThreshold >> 2) ? 0
//                : dist < (halfMaxThreshold >> 1) ? 1
//                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

            float normHad = ((float)dist)/((float)halfMaxThreshold);

            // YGJ 15th March 2015
            // Use 1/2 max based normalised value
            // Based on normJND

            normHad = normHad > 1.0? 1.0 : normHad;

            int val =  normHad < 0.25? 0 :
                       normHad < 0.5? 1 :
                       normHad < 0.75? 2 : 3;

            //------------------

            //switch (val)
            //{
            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
            //		break;
            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
            //		break;
            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
            //		break;
            //}

            //------------------
            // YGJ 27th Oct 2014
            // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
            // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
            switch (val)
            {
                case 0 :  r = 0; g = (int)((normHad/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                    break;
                case 1 :  r = 0; g= yInt; b = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                    break;
                case 2 :  r = (int)(((normHad-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                    break;
                default : r = min(yInt << 1, 255) ;g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                    break;
            }
            //------------------

        }
        else
        {
            r = g = b = yInt;
        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
//      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);

    free(ptrY_Org);

    free(ptrY_Part);

    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}



Void TAppDecTop::saveFrameAsPNG_RateControlJND(TComPic* pcPic)
{

  unsigned height = m_iSourceHeight;
  unsigned width = m_iSourceWidth;
  unsigned FrameRes = (height*width);

  // Used to produce SSIM Heatmaps
  TComPicYuv* imageOrg = m_pcPicYuvOrg;
  TComPicYuv* imageRec =  pcPic->getPicYuvRec();
  TComPicYuv* imageRecPart = pcPic->getPicYuvWPart();

  int poc = pcPic->getPOC();

  Pel*  piY_Org   = imageOrg->getAddr(COMPONENT_Y);

  Pel*  piY_Part   = imageRecPart->getAddr(COMPONENT_Y);

  unsigned YStride = imageOrg->getStride(COMPONENT_Y);

  unsigned YStrideRec = imageRec->getStride(COMPONENT_Y);

  // Allocate memory for output frame

  // Orig
  Pel *ptrY_Org;   ptrY_Org = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Org == NULL)   printf("calloc failed\n");

  // Partitioning
  Pel *ptrY_Part;   ptrY_Part = (Pel *)calloc(FrameRes, sizeof(Pel));    if (ptrY_Part == NULL)   printf("calloc failed\n");

    Pel *ptrY_Org8x8;   ptrY_Org8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Org8x8 == NULL)   printf("calloc failed\n");
//    Pel *ptrY_Rec8x8;   ptrY_Rec8x8 = (Pel *)calloc(64, sizeof(Pel));    if (ptrY_Rec8x8 == NULL)   printf("calloc failed\n");

   // To Do:

  // Need to make another TComPicYuv which stores the reconstructed modified with partitioning.

  //unsigned poc = ;
  char strpoc[6];
  char strRange[8];
  //char strFactor[8];

  // http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
  #if _MSC_VER
  #define snprintf _snprintf
  #endif

  // Set up file names

  if (poc < 10)
      snprintf(strpoc, sizeof(strpoc), "00%d", poc); // add leading zeros, makes it easier to sort by name
  else if (poc < 100)
      snprintf(strpoc, sizeof(strpoc), "0%d", poc);
  else
      snprintf(strpoc, sizeof(strpoc), "%d", poc);

  snprintf(strRange, sizeof(strRange), "%d", m_distRange);
  //snprintf(strFactor, sizeof(strFactor), "%d", m_SADFactor);

  //char SSIMHeatmap[80];  strcpy(SSIMHeatmap, "DecFrm_SSIMHeatMap_");    strcat(SSIMHeatmap, strpoc);        strcat(SSIMHeatmap, ".png");
  char SSIMHeatmap[255];  strcpy(SSIMHeatmap, m_pchSSIMLogAndImageFile);
  strcat(SSIMHeatmap, "DecFrm_RateCtrlJNDActivityHeatMap_");
  strcat(SSIMHeatmap, strpoc);
  strcat(SSIMHeatmap, "_Range");  strcat(SSIMHeatmap, strRange);
  //strcat(SSIMHeatmap, "_Factor");  strcat(SSIMHeatmap, strFactor);
  strcat(SSIMHeatmap, ".png");

  std::vector<unsigned char> imgSSIMHeatMap; imgSSIMHeatMap.resize(width * height * 4);

  unsigned MaxValue = (1<<g_bitDepth[0])-1;   //unsigned HalfMaxValue = (MaxValue-1) >> 1;
    Int   shift = g_bitDepth[0]-8;     Int   offset = (shift>0)?(1<<(shift-1)):0;


 //double frmAverageSSIM = 0.0;
 //int OverlappingSSIMcount =0;

 //float PxAve_SSIM_distortion = 0.0;
// unsigned long long FrmTotal_SSE_distortion = 0;

    for ( unsigned y = 0; y < height; y++ )
    {
      for ( unsigned x = 0; x < width; x++ )
      {
        unsigned yloc = y*width+x;


        // allocate YUV value
        int yInt = 0; //, uInt = 0, vInt = 0;

        ptrY_Org[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Org[x]+offset)>>shift);
//        ptrY_Rec[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Rec[x]+offset)>>shift);
        ptrY_Part[yloc]  = Clip3<Pel>(0, MaxValue, (piY_Part[x]+offset)>>shift);

        int yInt_Org = (int)ptrY_Org[yloc]; //int  uInt_Org = (int)ptrU_Org[cloc]; int  vInt_Org = (int)ptrV_Org[cloc];
//        int yInt_Rec = (int)ptrY_Rec[yloc];  int  uInt_Rec = (int)ptrU_Rec[cloc]; int  vInt_Rec = (int)ptrV_Rec[cloc];
        int yInt_Part = (int)ptrY_Part[yloc];  //int  uInt_Part = (int)ptrU_Part[cloc]; int  vInt_Part = (int)ptrV_Part[cloc];

        // seems fine here
        if (yInt_Org > 255 || yInt_Org < 0) // || yInt_Rec > 255 || yInt_Rec < 0)
            printf("Out of range pixel value, yInt_Org, %d \n", yInt_Org); //, yInt_Rec);



//        bool HadRegion = false;
//        Distortion iSumHad =0;

        //if ((y < (height-8)) && (x < (width-8)))
//        {
////          HadRegion = true;
////          TCoeff m1[8][8], m2[8][8], m3[8][8]; //, iSumHad = 0;

////            for ( unsigned n = 0; n < 8; n++ )
////            {
////                for ( unsigned m = 0; m < 8; m++ )
////                {
////                    unsigned yloc8x8 = n*m+m;

////                    ptrY_Org8x8[yloc8x8] = Clip3<Pel>(0, MaxValue, ((piY_Org[x + m + (YStride*n)] +offset))>>shift);

////                }
////            }

//            //-------------------------
//            //-----

//            int i, j, jj; //, k;


//            // End of Multi-Scale APC
//            //=============================
//            // Beginning of Hadamard with APC

//            //Now to add/subtract to the Hadamard Diff.
//            //Remember to divide accumulated multi-scale APC by 8 before adding to Diff. -- Not performed. Dampens the extended range by Multi-Scale
//            //int APCscale = 0;

//            //horizontal
//            for (j=0; j < 8; j++)
//            {
//              jj = j << 3;

//              m2[j][0] = ptrY_Org8x8[jj  ] + ptrY_Org8x8[jj+4];// + multiscaleAPC[jj  ];
//              m2[j][1] = ptrY_Org8x8[jj+1] + ptrY_Org8x8[jj+5];// + multiscaleAPC[jj+1];
//              m2[j][2] = ptrY_Org8x8[jj+2] + ptrY_Org8x8[jj+6];// + multiscaleAPC[jj+2];
//              m2[j][3] = ptrY_Org8x8[jj+3] + ptrY_Org8x8[jj+7];// + multiscaleAPC[jj+3];
//              m2[j][4] = ptrY_Org8x8[jj  ] - ptrY_Org8x8[jj+4];// - multiscaleAPC[jj+4];
//              m2[j][5] = ptrY_Org8x8[jj+1] - ptrY_Org8x8[jj+5];// - multiscaleAPC[jj+5];
//              m2[j][6] = ptrY_Org8x8[jj+2] - ptrY_Org8x8[jj+6];// - multiscaleAPC[jj+6];
//              m2[j][7] = ptrY_Org8x8[jj+3] - ptrY_Org8x8[jj+7];// - multiscaleAPC[jj+7];

//              m1[j][0] = m2[j][0] + m2[j][2];
//              m1[j][1] = m2[j][1] + m2[j][3];
//              m1[j][2] = m2[j][0] - m2[j][2];
//              m1[j][3] = m2[j][1] - m2[j][3];
//              m1[j][4] = m2[j][4] + m2[j][6];
//              m1[j][5] = m2[j][5] + m2[j][7];
//              m1[j][6] = m2[j][4] - m2[j][6];
//              m1[j][7] = m2[j][5] - m2[j][7];

//              m2[j][0] = m1[j][0] + m1[j][1];
//              m2[j][1] = m1[j][0] - m1[j][1];
//              m2[j][2] = m1[j][2] + m1[j][3];
//              m2[j][3] = m1[j][2] - m1[j][3];
//              m2[j][4] = m1[j][4] + m1[j][5];
//              m2[j][5] = m1[j][4] - m1[j][5];
//              m2[j][6] = m1[j][6] + m1[j][7];
//              m2[j][7] = m1[j][6] - m1[j][7];
//            }

//            //vertical
//            for (i=0; i < 8; i++)
//            {
//              m3[0][i] = m2[0][i] + m2[4][i];
//              m3[1][i] = m2[1][i] + m2[5][i];
//              m3[2][i] = m2[2][i] + m2[6][i];
//              m3[3][i] = m2[3][i] + m2[7][i];
//              m3[4][i] = m2[0][i] - m2[4][i];
//              m3[5][i] = m2[1][i] - m2[5][i];
//              m3[6][i] = m2[2][i] - m2[6][i];
//              m3[7][i] = m2[3][i] - m2[7][i];

//              m1[0][i] = m3[0][i] + m3[2][i];
//              m1[1][i] = m3[1][i] + m3[3][i];
//              m1[2][i] = m3[0][i] - m3[2][i];
//              m1[3][i] = m3[1][i] - m3[3][i];
//              m1[4][i] = m3[4][i] + m3[6][i];
//              m1[5][i] = m3[5][i] + m3[7][i];
//              m1[6][i] = m3[4][i] - m3[6][i];
//              m1[7][i] = m3[5][i] - m3[7][i];

//              m2[0][i] = m1[0][i] + m1[1][i];
//              m2[1][i] = m1[0][i] - m1[1][i];
//              m2[2][i] = m1[2][i] + m1[3][i];
//              m2[3][i] = m1[2][i] - m1[3][i];
//              m2[4][i] = m1[4][i] + m1[5][i];
//              m2[5][i] = m1[4][i] - m1[5][i];
//              m2[6][i] = m1[6][i] + m1[7][i];
//              m2[7][i] = m1[6][i] - m1[7][i];
//            }

//            for (i = 0; i < 8; i++)
//            {
//              for (j = 0; j < 8; j++)
//              {
//                iSumHad += abs(m2[i][j]);
//              }
//            }
//            iSumHad -= abs(m2[0][0]); // Applies only to Activity (Rate Control version of) Had.
//            iSumHad =(iSumHad+2)>>2;


//        }

        yInt = yInt_Org;


        int r = 0; //yInt + v_MinHalfMaxVal + ((13 * v_MinHalfMaxVal) >> 5);
        int g = 0; //yInt - ((11 * u_MinHalfMaxVal) >> 5) - ((23 * v_MinHalfMaxVal) >> 5);
        int b = 0; //yInt + u_MinHalfMaxVal + ((99 * u_MinHalfMaxVal) >> 7);

//        if (HadRegion == true)
        {

//            //------------------

//            int blkwidth = 8;

//            // Using arrays as look up tables to ensure values set are consistent
//            int loc = (int)log2((double)blkwidth) - 3;

//            int maxUnscaled = (maxLimitSAD_k[loc] * NormDist_OneMin10k[m_distRange]);
//            float maxScaled = (float)((float)maxUnscaled * (0.1024));
//            //float maxCommonFactor = maxScaled / ((float)(1 << m_SADFactor)); // Not applicable

//            Distortion halfMaxThreshold = (Distortion)maxScaled; //maxCommonFactor;

//            // For Rate-Control
//            halfMaxThreshold <<= 1; // Double

//            Distortion dist  = iSumHad > halfMaxThreshold? halfMaxThreshold : iSumHad;

//            if ( (iSumHad >> 1) > halfMaxThreshold) // Since halfMaxThreshold) will be a 1/2 of max possible range or less
//                printf("RateControl Had is greater than halfMaxThreshold of %d, distortion is %d, will be set to %d \n",
//                halfMaxThreshold, iSumHad, halfMaxThreshold);

//            int val = dist < (halfMaxThreshold >> 2) ? 0
//                : dist < (halfMaxThreshold >> 1) ? 1
//                : dist < ((halfMaxThreshold >> 1) + ( halfMaxThreshold >> 2)) ? 2 : 3;

//            float normHad = ((float)dist)/((float)halfMaxThreshold);

//            //------------------

//            //switch (val)
//            //{
//            //	case 0 :  r = yInt; g = (int)((normHad/(float)0.25)*yInt); b = 0;   // Going from Red to Yellow : fixed red (255), increasing green as 1-SSIM increases, fix blue (0)
//            //		break;
//            //	case 1 :  r = (int)(yInt-((normHad-0.25)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Yellow to Green: decreasing red as 1-SSIM moves from 0.5 to 1. fix green (255). fix blue (0)
//            //		break;
//            //	case 2 :  r = 0; g= yInt; b = (int)(((normHad-0.50)/(float)0.25)*yInt); // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //	default :  r = 0; g= (int)(yInt-((normHad-0.75)/(float)0.25)*yInt); b = yInt; // Going from Green to Cyan: increasing blue as 1-SSIM moves from 1 to 1.5. Fixed green (255) and fix red (0)
//            //		break;
//            //}


            /// YGJ 15th March 2015
            ///
            /// Calc JND
            ///
            /// Uisng formula:
            /// if pixel < 127 then calc: 17 * (1-( pixel/127)^0.5) + 3
            /// else ( for pixel > 126): 3/128 * pixel/127 + 3
            ///
            /// For pixel = 254, JND = 3+3/64 (3.046875)
            /// For pixel = 0, JND = 20.
            ///
            /// Then scale up to range supported by visual heatmap
            /// JND score as int = JND*50
            /// Tested with spreadsheet

            double JND = 0.0;

            if (yInt < 127)
                JND = 17*(1-(pow((double)yInt/127,0.5))) + 3;
            else
                JND = 3/128 * yInt/127 +3;

//            int JNDScaledUp = JND * 50;

//            /// First cap JNDScaledUp to 1024
//            /// Then to find which quadrant JNDScaledUp fits in
//            /// Then set the relative value

//            JNDScaledUp = JNDScaledUp > 1023 ? 1023 : JNDScaledUp;

//            int val = JNDScaledUp < 256? 0 :
//                  JNDScaledUp < 512? 1 :
//                  JNDScaledUp < 768? 2 : 3;

            if (JND < 10)
            {

            //float normHad = ((float)dist)/((float)halfMaxThreshold);
            float JNDMax = 20.0;
            //float normJND = 1-((float)JND)/((float)JNDMax); // Because JND score high is for low intensities, JND low is for high intensities
            float normJND = ((float)JND)/(JNDMax*0.5);
            normJND = normJND > 1.0? 1.0 : normJND;

//            int val =  normJND < 0.25? 0 :
//                       normJND < 0.5? 1 :
//                       normJND < 0.75? 2 : 3;

            int val =  normJND > 0.75? 0 :
                       normJND > 0.5? 1 :
                       normJND > 0.25? 2 : 3;


                //------------------
                // YGJ 27th Oct 2014
                // Blue is low (bottom 25%, first quadrant), Cyan, Green Yellow,  Red (top 25%, last quadrant).
                // Double Luma for first and last quadrant as otherwise blue and red can be quite dark
                switch (val)
                {
                    case 0 : //yInt = JNDScaledUp;
                             r = 0; g = (int)((normJND/(float)0.25)*yInt); b = min(yInt << 1, 255);   // Going from Blue to Cyan: Red set to zero (0), Green variable (1/4 normalised distortion), Blue  set to Luma
                        break;
                    case 1 : //yInt = JNDScaledUp - 256;
                             r = 0; g= yInt; b = (int)(yInt-((normJND-0.25)/(float)0.25)*yInt); // Going from Cyan to Green: Red still at zero. Green set to Luma, Blue variable (2nd quadrant of normalised distortion)
                        break;
                    case 2 : //yInt = JNDScaledUp - 512;
                             r = (int)(((normJND-0.50)/(float)0.25)*yInt); g= yInt; b = 0; // Going from Green to Yellow: Red variable (3rd quadrant of normalised distortion), Green set to Luma,  Blue set to zero (0).
                        break;
                    default : //yInt = JNDScaledUp - 768;
                             r = min(yInt << 1, 255) ;g= (int)(yInt-((normJND-0.75)/(float)0.25)*yInt); b = 0; // Going from Yellow to Red:  Red set to Luma, Green variable (4th quadrant of normalised distortion), Blue still at zero.
                        break;
                }
            }
            else
            {
                r = g = b = yInt;
            }
            //------------------

        }
//        else
//        {
//            r = g = b = yInt;
//        }


        // Rec - Org
        r =  r > MaxValue ? MaxValue : r < 0 ? 0 : r;
        g =  g > MaxValue ? MaxValue : g < 0 ? 0 : g;
        b =  b > MaxValue ? MaxValue : b < 0 ? 0 : b;


        // Partitioning -- Not Working?
        if (yInt_Part == 0 && (x % 4 == 0 || y % 4 == 0))
        {
          r = 0; //yInt_RmO;
          g = 0; //yInt_RmO;
          b = 0; //yInt_RmO;
        }



        imgSSIMHeatMap[4 * width * y + 4 * x + 0] = r; //Red
        imgSSIMHeatMap[4 * width * y + 4 * x + 1] = g; //Green
        imgSSIMHeatMap[4 * width * y + 4 * x + 2] = b; //Blue
        imgSSIMHeatMap[4 * width * y + 4 * x + 3] = 255; //MaxValue; //Alpha Keep at 255 for now

      }
      //piY += YStride;
      piY_Org += YStride;
//      piY_Rec += YStrideRec;
      piY_Part += YStrideRec;

    }


    free(ptrY_Org8x8);

    free(ptrY_Org);

    free(ptrY_Part);

    //-----------------------

    if(m_outputSSIMHeatmaps)
    {
      std::vector<unsigned char> png;

      unsigned error_Heatmap = lodepng::encode(png, imgSSIMHeatMap, width, height);

      if(!error_Heatmap) lodepng::save_file(png, SSIMHeatmap);

      //if there's an error, display it
      if(error_Heatmap) std::cout << "encoder error " << error_Heatmap << ": "<< lodepng_error_text(error_Heatmap) << std::endl;
    }

   //-----------------------

}
