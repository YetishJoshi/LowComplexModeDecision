/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2014, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     TAppDecCfg.cpp
    \brief    Decoder configuration class
*/

#include <cstdio>
#include <cstring>
#include <string>
#include "TAppDecCfg.h"

#include "TLibCommon/CommonDef.h"

#include "TAppCommon/program_options_lite.h"
#include "TLibCommon/TComChromaFormat.h"
#ifdef WIN32
#define strdup _strdup
#endif

using namespace std;
namespace po = df::program_options_lite;

//! \ingroup TAppDecoder
//! \{

// ====================================================================================================================
// Public member functions
// ====================================================================================================================

/** \param argc number of arguments
    \param argv array of arguments
 */
Bool TAppDecCfg::parseCfg( Int argc, Char* argv[] )
{
  Bool do_help = false;
  string cfg_BitstreamFile;
  string cfg_ReconFile;
  string cfg_RefFile; ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
  string cfg_LogFile; ///< Log file - 5th Sept 2014
  string cfg_TargetDecLayerIdSetFile;
  string outputColourSpaceConvert;

  po::Options opts;
  opts.addOptions()


  ("help",                      do_help,                               false,      "this help text")
  ("c", po::parseConfigFile, "configuration file name")
  ("BitstreamFile,b",           cfg_BitstreamFile,                     string(""), "bitstream input file name")
  ("ReconFile,o",               cfg_ReconFile,                         string(""), "reconstructed YUV output file name\n"
                                                                                    "YUV writing is skipped if omitted")
  //-----------------------------------------------------------------------
  ("RefFile,r",     cfg_RefFile,     string(""), "Reference YUV input file name\n"
                                                 "Difference and SSIM Heatmaps are skipped if omitted") ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
  //-----------------------------------------------------------------------
  // Copied from TAppEnCfg
  ("SourceWidth,-wdt",      m_iSourceWidth,        0, "Source picture width")
  ("SourceHeight,-hgt",     m_iSourceHeight,       0, "Source picture height")
  ("FrameOutput,-fop",      m_frameoutput,         0, "Frame number to output as heatmaps under various meausres, 0 means all frames")
  ("DistWidthSize,-dist",   m_distWidthSize,       8, "Set the width size of the distortion measures, available options are 8, 16, 32, 64")
  ("DistRange,-range",   m_distRange,       8, "Set the range  of the distortion measures between 0 and 20, which reflect the range of norm distribution scale")
  ("SADFactor,-SADfactor",   m_SADFactor,       0, "Affects SAD and Had (not Had RC - activity) Set the factor to divide the max threshold range by, will be between 0 to 16. ")
  ("MaxCuSize,-CUsize",   m_maxCUsize,       2048, " Set the max size for a Coding Unit in terms of bits - part of heatmap")

  ("InputChromaFormat",     m_inputChromaFormat,   1, "CHROMA_400 = 0, CHROMA_420 = 1, CHROMA_422 = 2, CHROMA_444 = 3,")
  ("SSIMLogAndImageFile",   cfg_LogFile,  string(""), "The name of the location and file prefix for SSIM and SSE log as well as the frame image output without extension")
  ("OutputSSIMAndSSELog",   m_outputSSIMAndSSELog,  0, "Output SSIM and SSE scores for each frame, requires RefFile, (saves as .txt), 0 = false, 1 = true")
  ("OutputSSIMHeatmaps",    m_outputSSIMHeatmaps,  0, "Output SSIM Heatmaps for each frame, requires RefFile, (saves as .png), 0 = false, 1 = true")
  ("OutputFrmPartition",    m_outputFrmPartition,  0, "Output Frames with partitions, (saves as .png) 0 = false, 1 = true")  
  ("InputBitDepth",         m_inputBitDepthY,    8, "Bit-depth of input file")
  ("InputBitDepthC",        m_inputBitDepthC,    8, "As per InputBitDepth but for chroma component. (default:InputBitDepth)")
  ("InternalBitDepth",      m_internalBitDepth[CHANNEL_TYPE_LUMA], 8, "Bit-depth the codec operates at. (default:InputBitDepth)"
                                                       "If different to InputBitDepth, source data will be converted")
  ("InternalBitDepthC",     m_internalBitDepth[CHANNEL_TYPE_CHROMA], 8, "As per InternalBitDepth but for chroma component. (default:IntrenalBitDepth)")
  //("FrameAsHeatmap",        m_poc_heatmap,          0, "POC/frame to output as heatmaps under various measures ")
  //-----------------------------------------------------------------------                                                                                 "YUV writing is skipped if omitted")
  ("SkipFrames,s",              m_iSkipFrame,                          0,          "number of frames to skip before random access")
  ("OutputBitDepth,d",          m_outputBitDepth[CHANNEL_TYPE_LUMA],   0,          "bit depth of YUV output luma component (default: use 0 for native depth)")
  ("OutputBitDepthC,d",         m_outputBitDepth[CHANNEL_TYPE_CHROMA], 0,          "bit depth of YUV output chroma component (default: use 0 for native depth)")
  ("OutputColourSpaceConvert",  outputColourSpaceConvert,              string(""), "Colour space conversion to apply to input 444 video. Permitted values are (empty string=UNCHANGED) " + getListOfColourSpaceConverts(false))
  ("MaxTemporalLayer,t",        m_iMaxTemporalLayer,                   -1,         "Maximum Temporal Layer to be decoded. -1 to decode all layers")
  ("SEIDecodedPictureHash",     m_decodedPictureHashSEIEnabled,        1,          "Control handling of decoded picture hash SEI messages\n"
                                                                                   "\t1: check hash in SEI messages if available in the bitstream\n"
                                                                                   "\t0: ignore SEI message")
  ("SEIpictureDigest",          m_decodedPictureHashSEIEnabled,        1,          "deprecated alias for SEIDecodedPictureHash")
  ("SEINoDisplay",              m_decodedNoDisplaySEIEnabled,          true,       "Control handling of decoded no display SEI messages")
  ("TarDecLayerIdSetFile,l",    cfg_TargetDecLayerIdSetFile,           string(""), "targetDecLayerIdSet file name. The file should include white space separated LayerId values to be decoded. Omitting the option or a value of -1 in the file decodes all layers.")
  ("RespectDefDispWindow,w",    m_respectDefDispWindow,                0,          "Only output content inside the default display window\n")
#if RExt__O0043_BEST_EFFORT_DECODING
  ("ForceDecodeBitDepth",       m_forceDecodeBitDepth,                 0U,         "Force the decoder to operate at a particular bit-depth (best effort decoding)")
#endif
  ("OutputDecodedSEIMessagesFilename",  m_outputDecodedSEIMessagesFilename,    string(""), "When non empty, output decoded SEI messages to the indicated file. If file is '-', then output to stdout\n")
  ;

  po::setDefaults(opts);
  const list<const Char*>& argv_unhandled = po::scanArgv(opts, argc, (const Char**) argv);

  for (list<const Char*>::const_iterator it = argv_unhandled.begin(); it != argv_unhandled.end(); it++)
  {
    fprintf(stderr, "Unhandled argument ignored: `%s'\n", *it);
  }

  if (argc == 1 || do_help)
  {
    po::doHelp(cout, opts);
    return false;
  }

  m_outputColourSpaceConvert = stringToInputColourSpaceConvert(outputColourSpaceConvert, false);
  if (m_outputColourSpaceConvert>=NUMBER_INPUT_COLOUR_SPACE_CONVERSIONS)
  {
    fprintf(stderr, "Bad output colour space conversion string\n");
    return false;
  }

  /* convert std::string to c string for compatability */
  m_pchBitstreamFile = cfg_BitstreamFile.empty() ? NULL : strdup(cfg_BitstreamFile.c_str());
  m_pchReconFile = cfg_ReconFile.empty() ? NULL : strdup(cfg_ReconFile.c_str());
  m_pchRefFile = cfg_RefFile.empty() ? NULL : strdup(cfg_RefFile.c_str()); ///< Reference  file to compare Difference and SSIM Heatmaps from -  YGJ 17th July 2013
  m_pchSSIMLogAndImageFile = cfg_LogFile.empty() ? NULL : strdup(cfg_LogFile.c_str()); ///< RLocation and Name of the SSIMandSSE Log and SSIM/Partition Image file

  if (!m_pchBitstreamFile)
  {
    fprintf(stderr, "No input file specified, aborting\n");
    return false;
  }

  if ( !cfg_TargetDecLayerIdSetFile.empty() )
  {
    FILE* targetDecLayerIdSetFile = fopen ( cfg_TargetDecLayerIdSetFile.c_str(), "r" );
    if ( targetDecLayerIdSetFile )
    {
      Bool isLayerIdZeroIncluded = false;
      while ( !feof(targetDecLayerIdSetFile) )
      {
        Int layerIdParsed = 0;
        if ( fscanf( targetDecLayerIdSetFile, "%d ", &layerIdParsed ) != 1 )
        {
          if ( m_targetDecLayerIdSet.size() == 0 )
          {
            fprintf(stderr, "No LayerId could be parsed in file %s. Decoding all LayerIds as default.\n", cfg_TargetDecLayerIdSetFile.c_str() );
          }
          break;
        }
        if ( layerIdParsed  == -1 ) // The file includes a -1, which means all LayerIds are to be decoded.
        {
          m_targetDecLayerIdSet.clear(); // Empty set means decoding all layers.
          break;
        }
        if ( layerIdParsed < 0 || layerIdParsed >= MAX_NUM_LAYER_IDS )
        {
          fprintf(stderr, "Warning! Parsed LayerId %d is not within allowed range [0,%d]. Ignoring this value.\n", layerIdParsed, MAX_NUM_LAYER_IDS-1 );
        }
        else
        {
          isLayerIdZeroIncluded = layerIdParsed == 0 ? true : isLayerIdZeroIncluded;
          m_targetDecLayerIdSet.push_back ( layerIdParsed );
        }
      }
      fclose (targetDecLayerIdSetFile);
      if ( m_targetDecLayerIdSet.size() > 0 && !isLayerIdZeroIncluded )
      {
        fprintf(stderr, "TargetDecLayerIdSet must contain LayerId=0, aborting" );
        return false;
      }
    }
    else
    {
      fprintf(stderr, "File %s could not be opened. Using all LayerIds as default.\n", cfg_TargetDecLayerIdSetFile.c_str() );
    }
  }

  return true;
}

//! \}
